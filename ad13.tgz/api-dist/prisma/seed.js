"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const bcryptjs_1 = require("bcryptjs");
const prisma = new client_1.PrismaClient();
const DEFAULT_PASSWORD = "oasis2026";
const storeInputs = [
    { code: "SJZ", name: "绿洲剧本杀（石家庄总店）", city: "石家庄", address: "待甲方补充详细地址", staff: ["白泽", "KK", "大美", "八戒", "小树", "泡芙", "平安", "橘子"], rooms: ["中式", "日式", "欧式", "民国", "新中式", "古风", "仿古"] },
    { code: "BD", name: "绿洲剧本杀（保定店）", city: "保定", address: "待甲方补充详细地址", staff: ["老五", "老吴", "老郑", "曲奇", "仲河", "皮皮"], rooms: ["中式", "日式", "欧式", "民国", "古风", "仿古"] },
    { code: "HD", name: "绿洲剧本杀（邯郸店）", city: "邯郸", address: "待甲方补充详细地址", staff: ["龙龙", "宸风", "小譞", "黄淮", "老曹", "旧城", "陈夏"], rooms: ["中式", "日式", "欧式", "民国", "新中式", "古风", "仿古"] },
    { code: "HS", name: "绿洲剧本杀（呼市店）", city: "呼和浩特", address: "待甲方补充详细地址", staff: [], rooms: ["中式", "日式", "欧式", "民国"] },
    { code: "ZZ", name: "绿洲剧本杀（郑州店）", city: "郑州", address: "待甲方补充详细地址", staff: [], rooms: ["中式", "日式", "欧式", "民国"] },
    { code: "JN", name: "绿洲剧本杀（济南店）", city: "济南", address: "待甲方补充详细地址", staff: [], rooms: ["中式", "日式", "欧式", "民国"] },
    { code: "LY", name: "绿洲剧本杀（洛阳店）", city: "洛阳", address: "待甲方补充详细地址", staff: [], rooms: ["中式", "日式", "欧式", "民国"] },
    { code: "TY", name: "绿洲剧本杀（太原店）", city: "太原", address: "待甲方补充详细地址", staff: [], rooms: ["中式", "日式", "欧式", "民国"] },
];
const scripts = ["病娇男孩的精分日记", "雪乡连环杀人事件", "崇山乐园", "祝福", "琳琅", "离婚吧赶紧的"];
const requiredMaterialLabels = JSON.stringify(["桌面全景照片", "垃圾桶照片", "空调关闭照片", "剧本线索整理照片", "剧本入库照片", "遥控器归位照片", "房间关灯照片", "门牌或门灯还原照片"]);
const activityTypes = [
    { name: "大学生活动", defaultDiscountCents: 1000, sortOrder: 10 },
    { name: "夜场活动", defaultDiscountCents: 1000, sortOrder: 20 },
    { name: "好评活动", defaultDiscountCents: 0, sortOrder: 30 },
    { name: "早鸟票", defaultDiscountCents: 0, sortOrder: 40 },
    { name: "其它", defaultDiscountCents: 0, sortOrder: 50 },
];
const vipRules = [
    ["SJZ", "SINGLE", 30000, 35500, null, null, 0.84, 1, "尊贵绿洲探员VIP"],
    ["SJZ", "DOUBLE", 100000, 122800, null, null, 0.82, 2, "尊贵绿洲探员VIP"],
    ["SJZ", "MULTI", 200000, 252800, null, null, 0.79, null, "尊贵绿洲探员VIP"],
    ["BD", "SINGLE", 30000, 35500, null, null, 0.84, 1, "尊贵绿洲探员VIP"],
    ["BD", "DOUBLE", 100000, 126600, null, null, 0.79, 2, "尊贵绿洲探员VIP"],
    ["BD", "MULTI", 200000, 266600, null, null, 0.76, null, "尊贵绿洲探员VIP"],
    ["HD", "SINGLE", 30000, 25000, null, null, null, 1, "尊贵综合探员VIP"],
    ["HD", "DOUBLE", 100000, 117600, null, null, null, 2, "尊贵综合探员VIP"],
    ["HD", "MULTI", 200000, 238600, null, null, null, null, "尊贵综合探员VIP"],
    ["HS", "SINGLE", 30000, 36000, null, null, 0.83, 1, "尊贵绿洲探员VIP"],
    ["HS", "DOUBLE", 100000, 126600, null, null, 0.79, 2, "尊贵绿洲探员VIP"],
    ["HS", "MULTI", 200000, 266600, null, null, 0.75, null, "尊贵绿洲探员VIP"],
    ["ZZ", "SINGLE", 30000, 30000, 0.76, 0.91, null, 1, "尊贵绿洲探员VIP"],
    ["ZZ", "DOUBLE", 100000, 100000, 0.76, 0.84, null, 2, "尊贵绿洲探员VIP"],
    ["ZZ", "MULTI", 200000, 200000, 0.72, 0.8, null, null, "尊贵绿洲探员VIP"],
    ["JN", "SINGLE", 30000, 30000, 0.85, 0.89, null, 1, "尊贵绿洲探员VIP"],
    ["JN", "DOUBLE", 100000, 100000, 0.82, 0.87, null, 2, "尊贵绿洲探员VIP"],
    ["JN", "MULTI", 200000, 200000, 0.79, 0.85, null, null, "尊贵绿洲探员VIP"],
    ["LY", "SINGLE", 30000, 37600, null, null, 0.8, 1, "尊贵绿洲探员VIP"],
    ["LY", "DOUBLE", 50000, 66600, null, null, 0.75, 2, "尊贵绿洲探员VIP"],
    ["LY", "MULTI", 100000, 142600, null, null, 0.7, null, "尊贵绿洲探员VIP"],
    ["TY", "SINGLE", 30000, 35500, null, null, 0.84, 1, "尊贵绿洲探员VIP"],
    ["TY", "DOUBLE", 100000, 122800, null, null, 0.82, 2, "尊贵绿洲探员VIP"],
    ["TY", "MULTI", 200000, 252800, null, null, 0.79, null, "尊贵绿洲探员VIP"],
];
async function clearDatabase() {
    await prisma.auditLog.deleteMany();
    await prisma.taskEvidence.deleteMany();
    await prisma.taskSubmission.deleteMany();
    await prisma.sessionDesignation.deleteMany();
    await prisma.scriptQualification.deleteMany();
    await prisma.violationRecord.deleteMany();
    await prisma.periodicReport.deleteMany();
    await prisma.businessGoalRule.deleteMany();
    await prisma.reimbursementRule.deleteMany();
    await prisma.scheduleRequest.deleteMany();
    await prisma.workShift.deleteMany();
    await prisma.sessionStaffFee.deleteMany();
    await prisma.employeeTransfer.deleteMany();
    await prisma.operationTask.deleteMany();
    await prisma.closeChecklist.deleteMany();
    await prisma.dailyReport.deleteMany();
    await prisma.businessTarget.deleteMany();
    await prisma.reimbursement.deleteMany();
    await prisma.attendance.deleteMany();
    await prisma.memberLedger.deleteMany();
    await prisma.member.deleteMany();
    await prisma.sessionMaterial.deleteMany();
    await prisma.sessionPlayerAdjustment.deleteMany();
    await prisma.sessionStaffAssignment.deleteMany();
    await prisma.sessionPlayer.deleteMany();
    await prisma.gameSession.deleteMany();
    await prisma.activityType.deleteMany();
    await prisma.vipCardRule.deleteMany();
    await prisma.script.deleteMany();
    await prisma.room.deleteMany();
    await prisma.user.deleteMany();
    await prisma.store.deleteMany();
}
async function main() {
    await clearDatabase();
    const passwordHash = await (0, bcryptjs_1.hash)(DEFAULT_PASSWORD, 10);
    const stores = new Map();
    for (const input of storeInputs) {
        const store = await prisma.store.create({ data: { code: input.code, name: input.name, city: input.city, address: input.address } });
        stores.set(input.code, store);
        await prisma.room.createMany({ data: input.rooms.map((name) => ({ name, capacity: 10, storeId: store.id })) });
        await prisma.script.createMany({ data: scripts.map((name, index) => ({ name, category: "BOX", theme: ["HORROR", "EMOTION", "REASONING", "JOY_MECHANISM"][index % 4], playerCount: 6, priceCents: 0, durationMinutes: 240, sessionFactor: 1, requiredPreparationLabels: "[]", requiredMaterialLabels, storeId: store.id })) });
        if (input.staff.length)
            await prisma.user.createMany({ data: input.staff.map((name, index) => ({ username: `staff_${input.code.toLowerCase()}_${index + 1}`, passwordHash, name, role: "STAFF", storeId: store.id })) });
        await prisma.activityType.createMany({ data: activityTypes.map((activity) => ({ ...activity, storeId: store.id })) });
    }
    await prisma.vipCardRule.createMany({
        data: vipRules.map(([storeCode, cardType, rechargeCents, receiveCents, boxDiscount, cityDiscount, unifiedDiscount, maxUsers, cardTitle]) => {
            const store = stores.get(storeCode);
            if (!store)
                throw new Error(`${storeCode} 门店初始化失败`);
            return { storeId: store.id, cardType, rechargeCents, receiveCents, boxDiscount, cityDiscount, unifiedDiscount, maxUsers, cardTitle };
        }),
    });
    const sjz = stores.get("SJZ");
    if (!sjz)
        throw new Error("石家庄总店初始化失败");
    await prisma.user.create({ data: { username: "Br3197rr", passwordHash, name: "甲方店长", phone: "17332936413", role: "MANAGER", storeId: sjz.id, mustChangePassword: false } });
    await prisma.user.create({ data: { username: "reny6666666", passwordHash, name: "甲方管理员", phone: "13931113391", role: "HEADQUARTERS", mustChangePassword: false } });
    await prisma.user.create({ data: { username: "shuiguobabaxxxx", passwordHash, name: "甲方主持人", phone: "18630107662", role: "DM", storeId: sjz.id, mustChangePassword: false } });
    await prisma.user.create({ data: { username: "lvzhoujiameng", passwordHash, name: "甲方客服", phone: "19930768915", role: "CUSTOMER_SERVICE", storeId: sjz.id, mustChangePassword: false } });
    await prisma.user.create({ data: { username: "FJ7907-", passwordHash, name: "甲方财务", phone: "13323282792", role: "FINANCE", mustChangePassword: false } });
    console.log(JSON.stringify({ company: "石家庄绿洲市场营销策划有限公司", defaultPassword: DEFAULT_PASSWORD, stores: storeInputs.map((item) => ({ name: item.name, employees: item.staff.length, rooms: item.rooms.length, scripts: scripts.length })), experienceAccounts: 5 }, null, 2));
}
main().then(() => prisma.$disconnect()).catch(async (error) => { console.error(error); await prisma.$disconnect(); process.exit(1); });
//# sourceMappingURL=seed.js.map