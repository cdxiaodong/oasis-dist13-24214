export declare class UploadsModule {
}
