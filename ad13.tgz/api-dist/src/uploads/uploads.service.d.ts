import { ConfigService } from "@nestjs/config";
export declare class UploadsService {
    private readonly config;
    constructor(config: ConfigService);
    saveImage(dataUrl: string, originalName?: string): Promise<{
        url: string;
        filename: string;
        originalName: string | null;
        size: number;
    }>;
    readImage(filename: string): Promise<NonSharedBuffer>;
}
