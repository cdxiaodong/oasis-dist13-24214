"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const uploads_service_1 = require("./uploads.service");
class ImageUploadDto {
    dataUrl;
    filename;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ImageUploadDto.prototype, "dataUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ImageUploadDto.prototype, "filename", void 0);
let UploadsController = class UploadsController {
    uploads;
    constructor(uploads) {
        this.uploads = uploads;
    }
    image(dto) {
        return this.uploads.saveImage(dto.dataUrl, dto.filename);
    }
    async file(filename) {
        return new common_1.StreamableFile(await this.uploads.readImage(filename), { type: filename.endsWith(".png") ? "image/png" : filename.endsWith(".webp") ? "image/webp" : "image/jpeg" });
    }
};
exports.UploadsController = UploadsController;
__decorate([
    (0, common_1.Post)("images"),
    (0, swagger_1.ApiOperation)({ summary: "上传图片并返回可访问地址" }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ImageUploadDto]),
    __metadata("design:returntype", void 0)
], UploadsController.prototype, "image", null);
__decorate([
    (0, common_1.Get)("files/:filename"),
    (0, common_1.Header)("Cache-Control", "private, max-age=300"),
    __param(0, (0, common_1.Param)("filename")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "file", null);
exports.UploadsController = UploadsController = __decorate([
    (0, swagger_1.ApiTags)("文件"),
    (0, common_1.Controller)("uploads"),
    __metadata("design:paramtypes", [uploads_service_1.UploadsService])
], UploadsController);
//# sourceMappingURL=uploads.controller.js.map