import type { UserSession } from "../common/user-session";
import { CustomerServiceService } from "./customer-service.service";
declare class ReviewQueryDto {
    storeId?: string;
    source?: string;
    premium?: string;
    from?: string;
    to?: string;
}
declare class CreateReviewDto {
    storeId?: string;
    source: string;
    channel?: string;
    reviewerName?: string;
    content?: string;
    rating?: number;
    isPremium?: boolean;
    isQuality?: boolean;
    proofUrl?: string;
    sessionId?: string;
    reviewedAt: string;
}
declare class UpdateReviewDto {
    channel?: string;
    reviewerName?: string;
    content?: string;
    rating?: number;
    isPremium?: boolean;
    isQuality?: boolean;
    proofUrl?: string;
    reviewedAt?: string;
}
declare class FollowUpQueryDto {
    storeId?: string;
    result?: string;
    from?: string;
    to?: string;
}
declare class CreateFollowUpDto {
    storeId?: string;
    customerName: string;
    contact?: string;
    contactType?: string;
    result?: string;
    content: string;
    sessionId?: string;
    contactedAt: string;
    nextFollowUpAt?: string;
}
declare class UpdateFollowUpDto {
    customerName?: string;
    contact?: string;
    contactType?: string;
    result?: string;
    content?: string;
    nextFollowUpAt?: string;
}
export declare class CustomerServiceController {
    private readonly cs;
    constructor(cs: CustomerServiceService);
    reviews(user: UserSession, query: ReviewQueryDto): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            name: string;
        };
        handledBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        proofUrl: string | null;
        sessionId: string | null;
        reviewedAt: Date;
        source: string;
        isPremium: boolean;
        isQuality: boolean;
        channel: string | null;
        reviewerName: string | null;
        content: string | null;
        rating: number;
        handledById: string;
    })[]>;
    reviewStats(user: UserSession, query: ReviewQueryDto): Promise<{
        platform: number;
        client: number;
        customerService: number;
        premium: number;
        quality: number;
        total: number;
    }>;
    createReview(user: UserSession, dto: CreateReviewDto): Promise<{
        store: {
            id: string;
            name: string;
        };
        handledBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        proofUrl: string | null;
        sessionId: string | null;
        reviewedAt: Date;
        source: string;
        isPremium: boolean;
        isQuality: boolean;
        channel: string | null;
        reviewerName: string | null;
        content: string | null;
        rating: number;
        handledById: string;
    }>;
    updateReview(user: UserSession, id: string, dto: UpdateReviewDto): Promise<{
        store: {
            id: string;
            name: string;
        };
        handledBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        proofUrl: string | null;
        sessionId: string | null;
        reviewedAt: Date;
        source: string;
        isPremium: boolean;
        isQuality: boolean;
        channel: string | null;
        reviewerName: string | null;
        content: string | null;
        rating: number;
        handledById: string;
    }>;
    deleteReview(user: UserSession, id: string): Promise<{
        ok: boolean;
    }>;
    followUps(user: UserSession, query: FollowUpQueryDto): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            name: string;
        };
        handledBy: {
            id: string;
            name: string;
        };
    } & {
        result: string;
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        sessionId: string | null;
        content: string;
        handledById: string;
        contactedAt: Date;
        customerName: string;
        contact: string | null;
        contactType: string;
        nextFollowUpAt: Date | null;
    })[]>;
    createFollowUp(user: UserSession, dto: CreateFollowUpDto): Promise<{
        store: {
            id: string;
            name: string;
        };
        handledBy: {
            id: string;
            name: string;
        };
    } & {
        result: string;
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        sessionId: string | null;
        content: string;
        handledById: string;
        contactedAt: Date;
        customerName: string;
        contact: string | null;
        contactType: string;
        nextFollowUpAt: Date | null;
    }>;
    updateFollowUp(user: UserSession, id: string, dto: UpdateFollowUpDto): Promise<{
        store: {
            id: string;
            name: string;
        };
        handledBy: {
            id: string;
            name: string;
        };
    } & {
        result: string;
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        sessionId: string | null;
        content: string;
        handledById: string;
        contactedAt: Date;
        customerName: string;
        contact: string | null;
        contactType: string;
        nextFollowUpAt: Date | null;
    }>;
    deleteFollowUp(user: UserSession, id: string): Promise<{
        ok: boolean;
    }>;
    sessions(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<{
        id: string;
        state: string;
        startAt: Date;
        script: {
            id: string;
            name: string;
        };
        host: {
            id: string;
            name: string;
        };
    }[]>;
}
export {};
