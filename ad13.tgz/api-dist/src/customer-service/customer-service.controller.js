"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerServiceController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const customer_service_service_1 = require("./customer-service.service");
class ReviewQueryDto {
    storeId;
    source;
    premium;
    from;
    to;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReviewQueryDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReviewQueryDto.prototype, "source", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReviewQueryDto.prototype, "premium", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReviewQueryDto.prototype, "from", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReviewQueryDto.prototype, "to", void 0);
class CreateReviewDto {
    storeId;
    source;
    channel;
    reviewerName;
    content;
    rating;
    isPremium;
    isQuality;
    proofUrl;
    sessionId;
    reviewedAt;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["PLATFORM", "CLIENT", "CUSTOMER_SERVICE"]),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "source", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "channel", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "reviewerName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "content", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(5),
    __metadata("design:type", Number)
], CreateReviewDto.prototype, "rating", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateReviewDto.prototype, "isPremium", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateReviewDto.prototype, "isQuality", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "proofUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "sessionId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateReviewDto.prototype, "reviewedAt", void 0);
class UpdateReviewDto {
    channel;
    reviewerName;
    content;
    rating;
    isPremium;
    isQuality;
    proofUrl;
    reviewedAt;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateReviewDto.prototype, "channel", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateReviewDto.prototype, "reviewerName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateReviewDto.prototype, "content", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    (0, class_validator_1.Max)(5),
    __metadata("design:type", Number)
], UpdateReviewDto.prototype, "rating", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateReviewDto.prototype, "isPremium", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateReviewDto.prototype, "isQuality", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateReviewDto.prototype, "proofUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateReviewDto.prototype, "reviewedAt", void 0);
class FollowUpQueryDto {
    storeId;
    result;
    from;
    to;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], FollowUpQueryDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], FollowUpQueryDto.prototype, "result", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], FollowUpQueryDto.prototype, "from", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], FollowUpQueryDto.prototype, "to", void 0);
class CreateFollowUpDto {
    storeId;
    customerName;
    contact;
    contactType;
    result;
    content;
    sessionId;
    contactedAt;
    nextFollowUpAt;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "customerName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "contact", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["PHONE", "WECHAT", "INSTORE"]),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "contactType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["SATISFIED", "DISSATISFIED", "PENDING"]),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "result", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "content", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "sessionId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "contactedAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFollowUpDto.prototype, "nextFollowUpAt", void 0);
class UpdateFollowUpDto {
    customerName;
    contact;
    contactType;
    result;
    content;
    nextFollowUpAt;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateFollowUpDto.prototype, "customerName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateFollowUpDto.prototype, "contact", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["PHONE", "WECHAT", "INSTORE"]),
    __metadata("design:type", String)
], UpdateFollowUpDto.prototype, "contactType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["SATISFIED", "DISSATISFIED", "PENDING"]),
    __metadata("design:type", String)
], UpdateFollowUpDto.prototype, "result", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateFollowUpDto.prototype, "content", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateFollowUpDto.prototype, "nextFollowUpAt", void 0);
let CustomerServiceController = class CustomerServiceController {
    cs;
    constructor(cs) {
        this.cs = cs;
    }
    reviews(user, query) {
        return this.cs.reviews(user, query);
    }
    reviewStats(user, query) {
        return this.cs.reviewStats(user, query);
    }
    createReview(user, dto) {
        return this.cs.createReview(user, dto);
    }
    updateReview(user, id, dto) {
        return this.cs.updateReview(user, id, dto);
    }
    deleteReview(user, id) {
        return this.cs.deleteReview(user, id);
    }
    followUps(user, query) {
        return this.cs.followUps(user, query);
    }
    createFollowUp(user, dto) {
        return this.cs.createFollowUp(user, dto);
    }
    updateFollowUp(user, id, dto) {
        return this.cs.updateFollowUp(user, id, dto);
    }
    deleteFollowUp(user, id) {
        return this.cs.deleteFollowUp(user, id);
    }
    sessions(user, storeId) {
        return this.cs.recentSessions(user, storeId);
    }
};
exports.CustomerServiceController = CustomerServiceController;
__decorate([
    (0, common_1.Get)("reviews"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, ReviewQueryDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "reviews", null);
__decorate([
    (0, common_1.Get)("reviews/stats"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, ReviewQueryDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "reviewStats", null);
__decorate([
    (0, common_1.Post)("reviews"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateReviewDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "createReview", null);
__decorate([
    (0, common_1.Patch)("reviews/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateReviewDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "updateReview", null);
__decorate([
    (0, common_1.Delete)("reviews/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "deleteReview", null);
__decorate([
    (0, common_1.Get)("follow-ups"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, FollowUpQueryDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "followUps", null);
__decorate([
    (0, common_1.Post)("follow-ups"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateFollowUpDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "createFollowUp", null);
__decorate([
    (0, common_1.Patch)("follow-ups/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateFollowUpDto]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "updateFollowUp", null);
__decorate([
    (0, common_1.Delete)("follow-ups/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "deleteFollowUp", null);
__decorate([
    (0, common_1.Get)("sessions"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CustomerServiceController.prototype, "sessions", null);
exports.CustomerServiceController = CustomerServiceController = __decorate([
    (0, swagger_1.ApiTags)("客服工作台"),
    (0, common_1.Controller)("customer-service"),
    __metadata("design:paramtypes", [customer_service_service_1.CustomerServiceService])
], CustomerServiceController);
//# sourceMappingURL=customer-service.controller.js.map