export declare class StaffDevelopmentModule {
}
