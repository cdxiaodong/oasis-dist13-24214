"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffDevelopmentController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const staff_development_service_1 = require("./staff-development.service");
class QualificationDto {
    userId;
    scriptId;
    status;
    score;
    note;
    expiresAt;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], QualificationDto.prototype, "userId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], QualificationDto.prototype, "scriptId", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["LEARNING", "TRIAL", "PASSED", "SUSPENDED"]),
    __metadata("design:type", String)
], QualificationDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    (0, class_validator_1.Max)(100),
    __metadata("design:type", Number)
], QualificationDto.prototype, "score", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], QualificationDto.prototype, "note", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], QualificationDto.prototype, "expiresAt", void 0);
class ViolationDto {
    employeeId;
    category;
    severity;
    description;
    occurredAt;
    evidenceUrl;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ViolationDto.prototype, "employeeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ViolationDto.prototype, "category", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["LOW", "MEDIUM", "HIGH", "CRITICAL"]),
    __metadata("design:type", String)
], ViolationDto.prototype, "severity", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ViolationDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], ViolationDto.prototype, "occurredAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ViolationDto.prototype, "evidenceUrl", void 0);
class ViolationActionDto {
    action;
    comment;
}
__decorate([
    (0, class_validator_1.IsIn)(["APPROVE", "REJECT", "APPEAL", "UPHOLD", "DISMISS"]),
    __metadata("design:type", String)
], ViolationActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ViolationActionDto.prototype, "comment", void 0);
let StaffDevelopmentController = class StaffDevelopmentController {
    service;
    constructor(service) {
        this.service = service;
    }
    qualifications(user, storeId) { return this.service.qualifications(user, storeId); }
    saveQualification(user, dto) { return this.service.saveQualification(user, dto); }
    violations(user, storeId) { return this.service.violations(user, storeId); }
    createViolation(user, dto) { return this.service.createViolation(user, dto); }
    actionViolation(user, id, dto) { return this.service.actionViolation(user, id, dto.action, dto.comment); }
};
exports.StaffDevelopmentController = StaffDevelopmentController;
__decorate([
    (0, common_1.Get)("qualifications"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], StaffDevelopmentController.prototype, "qualifications", null);
__decorate([
    (0, common_1.Post)("qualifications"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, QualificationDto]),
    __metadata("design:returntype", void 0)
], StaffDevelopmentController.prototype, "saveQualification", null);
__decorate([
    (0, common_1.Get)("violations"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], StaffDevelopmentController.prototype, "violations", null);
__decorate([
    (0, common_1.Post)("violations"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, ViolationDto]),
    __metadata("design:returntype", void 0)
], StaffDevelopmentController.prototype, "createViolation", null);
__decorate([
    (0, common_1.Post)("violations/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, ViolationActionDto]),
    __metadata("design:returntype", void 0)
], StaffDevelopmentController.prototype, "actionViolation", null);
exports.StaffDevelopmentController = StaffDevelopmentController = __decorate([
    (0, common_1.Controller)("staff-development"),
    __metadata("design:paramtypes", [staff_development_service_1.StaffDevelopmentService])
], StaffDevelopmentController);
//# sourceMappingURL=staff-development.controller.js.map