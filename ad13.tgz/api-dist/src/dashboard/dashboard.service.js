"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardService = void 0;
const common_1 = require("@nestjs/common");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
let DashboardService = class DashboardService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async summary(user, requestedStoreId) {
        if (!["HEADQUARTERS", "FINANCE", "MANAGER"].includes(user.role))
            throw new common_1.ForbiddenException("当前岗位无权访问经营看板");
        let storeId = requestedStoreId;
        if (!user_session_1.GLOBAL_ROLES.has(user.role)) {
            if (!user.storeId)
                throw new common_1.ForbiddenException("账号未绑定门店");
            if (requestedStoreId && requestedStoreId !== user.storeId)
                throw new common_1.ForbiddenException("无权访问其他门店");
            storeId = user.storeId;
        }
        if (!storeId) {
            const firstStore = await this.prisma.store.findFirst({ where: { active: true }, orderBy: { code: "asc" }, select: { id: true } });
            storeId = firstStore?.id;
        }
        if (!storeId)
            throw new common_1.ForbiddenException("暂无可查看的门店");
        const selectedStore = await this.prisma.store.findUnique({ where: { id: storeId }, select: { id: true, name: true } });
        if (!selectedStore)
            throw new common_1.ForbiddenException("门店不存在或不可访问");
        const chinaNow = new Date(Date.now() + 8 * 60 * 60_000);
        const month = `${chinaNow.getUTCFullYear()}-${String(chinaNow.getUTCMonth() + 1).padStart(2, "0")}`;
        const monthStart = new Date(`${month}-01T00:00:00+08:00`);
        const nextMonth = new Date(monthStart);
        nextMonth.setUTCMonth(nextMonth.getUTCMonth() + 1);
        const where = storeId ? { storeId } : {};
        const sessions = await this.prisma.gameSession.findMany({
            where: { ...where, startAt: { gte: monthStart, lt: nextMonth } },
            include: { players: true, script: true, room: true, host: { select: { name: true } }, store: true },
            orderBy: { startAt: "desc" },
        });
        const activeSessions = sessions.filter((session) => session.state !== "CANCELLED");
        const revenueCents = activeSessions
            .flatMap((session) => session.players)
            .reduce((sum, player) => sum + player.amountCents - player.refundedCents, 0);
        const completed = sessions.filter((session) => session.state === "COMPLETED");
        const pendingApproval = sessions.filter((session) => session.state === "PENDING_APPROVAL").length;
        const memberStats = await this.prisma.member.aggregate({ where, _count: true, _sum: { balanceCents: true } });
        const reimbursements = await this.prisma.reimbursement.aggregate({
            where: { ...where, status: { in: ["PENDING_MANAGER", "PENDING_FINANCE"] } },
            _count: true,
            _sum: { amountCents: true },
        });
        return {
            month,
            storeId: selectedStore.id,
            storeName: selectedStore.name,
            revenueCents,
            sessionCount: activeSessions.length,
            completedCount: completed.length,
            pendingApproval,
            playerCount: activeSessions.reduce((sum, session) => sum + session.players.filter((player) => player.status === "ACTIVE").length, 0),
            memberCount: memberStats._count,
            memberBalanceCents: memberStats._sum.balanceCents ?? 0,
            pendingReimbursementCount: reimbursements._count,
            pendingReimbursementCents: reimbursements._sum.amountCents ?? 0,
            recentSessions: sessions.slice(0, 8),
        };
    }
};
exports.DashboardService = DashboardService;
exports.DashboardService = DashboardService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], DashboardService);
//# sourceMappingURL=dashboard.service.js.map