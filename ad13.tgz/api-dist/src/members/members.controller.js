"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MembersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const members_service_1 = require("./members.service");
class CreateMemberDto {
    storeId;
    name;
    phone;
    initialAmountCents;
    paymentProofUrl;
    source;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateMemberDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateMemberDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateMemberDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateMemberDto.prototype, "initialAmountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateMemberDto.prototype, "paymentProofUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateMemberDto.prototype, "source", void 0);
class TierDto {
    tier;
}
__decorate([
    (0, class_validator_1.IsIn)(["SINGLE", "DOUBLE", "MULTI"]),
    __metadata("design:type", String)
], TierDto.prototype, "tier", void 0);
class ConsumeDto {
    amountCents;
    note;
}
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ConsumeDto.prototype, "amountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ConsumeDto.prototype, "note", void 0);
class AdjustDto {
    type;
    amountCents;
    note;
}
__decorate([
    (0, class_validator_1.IsIn)(["RECHARGE", "REFUND", "ADJUST_INCREASE", "ADJUST_DECREASE"]),
    __metadata("design:type", String)
], AdjustDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], AdjustDto.prototype, "amountCents", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AdjustDto.prototype, "note", void 0);
let MembersController = class MembersController {
    members;
    constructor(members) {
        this.members = members;
    }
    list(user, storeId, search) {
        return this.members.list(user, storeId, search);
    }
    create(user, dto) {
        return this.members.create(user, dto);
    }
    approve(user, id) {
        return this.members.approve(user, id);
    }
    consume(user, id, dto) {
        return this.members.consume(user, id, dto.amountCents, dto.note);
    }
    adjust(user, id, dto) {
        return this.members.adjust(user, id, dto.type, dto.amountCents, dto.note);
    }
    tier(user, id, dto) { return this.members.updateTier(user, id, dto.tier); }
    rankings(user, storeId, from, to) { return this.members.rankings(user, { storeId, from, to }); }
};
exports.MembersController = MembersController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("search")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "list", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateMemberDto]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "create", null);
__decorate([
    (0, common_1.Post)(":id/approve"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "approve", null);
__decorate([
    (0, common_1.Post)(":id/consume"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, ConsumeDto]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "consume", null);
__decorate([
    (0, common_1.Post)(":id/adjust"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, AdjustDto]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "adjust", null);
__decorate([
    (0, common_1.Post)(":id/tier"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, TierDto]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "tier", null);
__decorate([
    (0, common_1.Get)("stats/rankings"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("from")),
    __param(3, (0, common_1.Query)("to")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], MembersController.prototype, "rankings", null);
exports.MembersController = MembersController = __decorate([
    (0, swagger_1.ApiTags)("会员"),
    (0, common_1.Controller)("members"),
    __metadata("design:paramtypes", [members_service_1.MembersService])
], MembersController);
//# sourceMappingURL=members.controller.js.map