import type { UserSession } from "../common/user-session";
import { MembersService } from "./members.service";
declare class CreateMemberDto {
    storeId: string;
    name: string;
    phone: string;
    initialAmountCents: number;
    paymentProofUrl?: string;
    source?: string;
}
declare class TierDto {
    tier: string;
}
declare class ConsumeDto {
    amountCents: number;
    note?: string;
}
declare class AdjustDto {
    type: string;
    amountCents: number;
    note: string;
}
export declare class MembersController {
    private readonly members;
    constructor(members: MembersService);
    list(user: UserSession, storeId?: string, search?: string): Promise<{
        phone: string;
        ledgers: never[];
        id: string;
        storeId: string;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        name: string;
        status: string;
        balanceCents: number;
        tier: string;
    }[]> | import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        openedBy: {
            id: string;
            name: string;
        } | null;
        ledgers: ({
            operator: {
                id: string;
                name: string;
            } | null;
        } & {
            id: string;
            type: string;
            note: string | null;
            createdAt: Date;
            amountCents: number;
            memberId: string;
            balanceAfterCents: number;
            operatorId: string | null;
        })[];
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
    })[]>;
    create(user: UserSession, dto: CreateMemberDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        ledgers: {
            id: string;
            type: string;
            note: string | null;
            createdAt: Date;
            amountCents: number;
            memberId: string;
            balanceAfterCents: number;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
    }>;
    approve(user: UserSession, id: string): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        ledgers: {
            id: string;
            type: string;
            note: string | null;
            createdAt: Date;
            amountCents: number;
            memberId: string;
            balanceAfterCents: number;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
    }>;
    consume(user: UserSession, id: string, dto: ConsumeDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        ledgers: {
            id: string;
            type: string;
            note: string | null;
            createdAt: Date;
            amountCents: number;
            memberId: string;
            balanceAfterCents: number;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
    }>;
    adjust(user: UserSession, id: string, dto: AdjustDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        ledgers: ({
            operator: {
                id: string;
                name: string;
            } | null;
        } & {
            id: string;
            type: string;
            note: string | null;
            createdAt: Date;
            amountCents: number;
            memberId: string;
            balanceAfterCents: number;
            operatorId: string | null;
        })[];
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
    }>;
    tier(user: UserSession, id: string, dto: TierDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        openedBy: {
            id: string;
            name: string;
        } | null;
        ledgers: {
            id: string;
            type: string;
            note: string | null;
            createdAt: Date;
            amountCents: number;
            memberId: string;
            balanceAfterCents: number;
            operatorId: string | null;
        }[];
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string;
        status: string;
        balanceCents: number;
        pendingCreditCents: number;
        paymentProofUrl: string | null;
        tier: string;
        source: string | null;
        openedById: string | null;
    }>;
    rankings(user: UserSession, storeId?: string, from?: string, to?: string): Promise<{
        rechargeRanking: {
            userId: string;
            name: string;
            amountCents: number;
            count: number;
        }[];
        openerRanking: {
            userId: string;
            name: string;
            count: number;
        }[];
    }>;
}
export {};
