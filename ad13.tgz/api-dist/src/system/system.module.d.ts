export declare class SystemModule {
}
