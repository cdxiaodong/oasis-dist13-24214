import type { UserSession } from "../common/user-session";
import { SystemService } from "./system.service";
declare class TransferDto {
    storeId: string;
    reason?: string;
}
declare class ResetPasswordDto {
    newPassword: string;
}
declare class PermissionItemDto {
    role: string;
    permission: string;
    allowed: boolean;
}
declare class PermissionsDto {
    items: PermissionItemDto[];
}
export declare const PERMISSION_KEYS: readonly ["dashboard", "revenue-details", "sessions", "create-session", "members", "my-attendance", "portal", "catalog", "operations", "business", "workforce", "staff-development", "customer-service", "system"];
export declare const PERMISSION_ROLES: readonly ["FINANCE", "MANAGER", "CUSTOMER_SERVICE", "DM", "ASSISTANT", "NPC", "STAFF"];
export declare class SystemController {
    private readonly system;
    constructor(system: SystemService);
    status(user: UserSession): Promise<{
        status: string;
        database: string;
        environment: string;
        startedAt: string;
        uptimeSeconds: number;
        counts: {
            stores: number;
            users: number;
            sessions: number;
            auditLogs: number;
        };
    }>;
    logs(user: UserSession, action?: string): import("@prisma/client").Prisma.PrismaPromise<({
        user: {
            id: string;
            storeId: string | null;
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
            name: string;
            role: string;
        };
    } & {
        id: string;
        createdAt: Date;
        action: string;
        entityType: string;
        entityId: string;
        payload: string | null;
        userId: string;
    })[]>;
    permissions(user: UserSession): Promise<Record<string, string | boolean>[]>;
    savePermissions(user: UserSession, dto: PermissionsDto): Promise<{
        success: boolean;
    }>;
    transfers(user: UserSession): import("@prisma/client").Prisma.PrismaPromise<({
        user: {
            id: string;
            username: string;
            name: string;
        };
        operator: {
            id: string;
            name: string;
        };
        fromStore: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        toStore: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        operatorId: string;
        userId: string;
        reason: string | null;
        fromStoreId: string | null;
        toStoreId: string | null;
    })[]>;
    transfer(user: UserSession, id: string, dto: TransferDto): Promise<{
        user: {
            id: string;
            storeId: string | null;
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
            username: string;
            name: string;
            role: string;
        };
        transfer: {
            fromStore: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
            toStore: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            } | null;
        } & {
            id: string;
            createdAt: Date;
            operatorId: string;
            userId: string;
            reason: string | null;
            fromStoreId: string | null;
            toStoreId: string | null;
        };
    }>;
    resetPassword(user: UserSession, id: string, dto: ResetPasswordDto): Promise<{
        success: boolean;
    }>;
}
export {};
