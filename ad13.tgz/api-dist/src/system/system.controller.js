"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemController = exports.PERMISSION_ROLES = exports.PERMISSION_KEYS = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const system_service_1 = require("./system.service");
class TransferDto {
    storeId;
    reason;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransferDto.prototype, "reason", void 0);
class ResetPasswordDto {
    newPassword;
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(6, { message: "新密码至少 6 位" }),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "newPassword", void 0);
class PermissionItemDto {
    role;
    permission;
    allowed;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PermissionItemDto.prototype, "role", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PermissionItemDto.prototype, "permission", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], PermissionItemDto.prototype, "allowed", void 0);
class PermissionsDto {
    items;
}
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => PermissionItemDto),
    __metadata("design:type", Array)
], PermissionsDto.prototype, "items", void 0);
exports.PERMISSION_KEYS = ["dashboard", "revenue-details", "sessions", "create-session", "members", "my-attendance", "portal", "catalog", "operations", "business", "workforce", "staff-development", "customer-service", "system"];
exports.PERMISSION_ROLES = ["FINANCE", "MANAGER", "CUSTOMER_SERVICE", "DM", "ASSISTANT", "NPC", "STAFF"];
let SystemController = class SystemController {
    system;
    constructor(system) {
        this.system = system;
    }
    status(user) {
        return this.system.status(user);
    }
    logs(user, action) {
        return this.system.auditLogs(user, action);
    }
    permissions(user) {
        return this.system.permissions(user);
    }
    savePermissions(user, dto) {
        return this.system.savePermissions(user, dto.items.map((item) => ({ role: item.role, permission: item.permission, allowed: item.allowed })));
    }
    transfers(user) {
        return this.system.transfers(user);
    }
    transfer(user, id, dto) {
        return this.system.transferUser(user, id, dto.storeId, dto.reason);
    }
    resetPassword(user, id, dto) {
        return this.system.resetPassword(user, id, dto.newPassword);
    }
};
exports.SystemController = SystemController;
__decorate([
    (0, common_1.Get)("status"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "status", null);
__decorate([
    (0, common_1.Get)("audit-logs"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("action")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "logs", null);
__decorate([
    (0, common_1.Get)("permissions"),
    (0, swagger_1.ApiOperation)({ summary: "角色权限矩阵（含默认值与覆盖）" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "permissions", null);
__decorate([
    (0, common_1.Put)("permissions"),
    (0, swagger_1.ApiOperation)({ summary: "保存角色权限（仅总部）" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, PermissionsDto]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "savePermissions", null);
__decorate([
    (0, common_1.Get)("transfers"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "transfers", null);
__decorate([
    (0, common_1.Post)("users/:id/transfer"),
    (0, swagger_1.ApiOperation)({ summary: "员工调店" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, TransferDto]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "transfer", null);
__decorate([
    (0, common_1.Post)("users/:id/reset-password"),
    (0, swagger_1.ApiOperation)({ summary: "管理员重置员工密码" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, ResetPasswordDto]),
    __metadata("design:returntype", void 0)
], SystemController.prototype, "resetPassword", null);
exports.SystemController = SystemController = __decorate([
    (0, swagger_1.ApiTags)("系统管理"),
    (0, common_1.Controller)("system"),
    __metadata("design:paramtypes", [system_service_1.SystemService])
], SystemController);
//# sourceMappingURL=system.controller.js.map