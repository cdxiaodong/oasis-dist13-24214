import { StreamableFile } from "@nestjs/common";
import type { UserSession } from "../common/user-session";
import { BusinessService } from "./business.service";
declare class TargetDto {
    storeId: string;
    type: string;
    periodStart: string;
    revenueTargetCents: number;
    sessionTarget: number;
    playerTarget?: number;
    electricityBudgetCents?: number;
    promotionBudgetCents?: number;
    smartPlacementBudgetCents?: number;
    goodReviewTarget?: number;
    note?: string;
}
declare class DailyReportDto {
    storeId: string;
    reportDate: string;
    reviewCount: number;
    goodReviewCount: number;
    kdbReviewCount?: number;
    kdbPremiumCount?: number;
    clientPremiumCount?: number;
    meituanTicketCount?: number;
    scanTicketCount?: number;
    premiumReviewCount?: number;
    qualifiedReviewCount?: number;
    clientReviewCount?: number;
    csQualityReviewCount?: number;
    electricityCostCents?: number;
    electricityUnits?: number;
    promotionCostCents?: number;
    smartPlacementCostCents?: number;
    notes?: string;
}
declare class ChecklistItemDto {
    label: string;
    checked: boolean;
    note?: string;
    imageUrl?: string;
}
declare class CloseChecklistActionDto {
    action: string;
    comment?: string;
}
declare class CloseChecklistDto {
    storeId: string;
    checklistDate: string;
    items: ChecklistItemDto[];
    note?: string;
    submit?: boolean;
}
declare class CreateTaskDto {
    storeId: string;
    title: string;
    description?: string;
    priority?: string;
    dueAt?: string;
    penaltyAmountCents?: number;
    assigneeId?: string;
    taskType?: string;
    evidenceRequired?: boolean;
    evidenceLabels?: string[];
}
declare class TaskEvidenceItemDto {
    label: string;
    imageUrl: string;
    note?: string;
}
declare class TaskSubmissionDto {
    note?: string;
    completedAt?: string;
    evidences: TaskEvidenceItemDto[];
}
declare class SubmissionActionDto {
    action: string;
    comment?: string;
}
declare class GoalRuleDto {
    storeId: string;
    dayType: string;
    revenueTargetCents: number;
    sessionTarget: number;
    playerTarget?: number;
    active?: boolean;
    note?: string;
}
declare class UpdateTaskDto {
    title?: string;
    description?: string;
    priority?: string;
    status?: string;
    dueAt?: string;
    penaltyAmountCents?: number;
    assigneeId?: string;
}
export declare class BusinessController {
    private readonly business;
    constructor(business: BusinessService);
    overview(user: UserSession, storeId?: string): Promise<{
        openTasks: number;
        pendingSessions: number;
        pendingReimbursements: number;
        missingDailyReports: number;
        missingCloseChecks: number;
        month: string;
        storeMetrics: {
            storeId: string;
            storeName: string;
            revenueCents: number;
            memberCount: number;
            sessionCount: number;
            operationStats: {
                cardIssueCount: number;
                cardIssueAmountCents: number;
                designatedSessionCount: number;
                cityLimitedSessionCount: number;
                cityLimitedByTheme: {
                    theme: string;
                    themeLabel: string;
                    sessionCount: number;
                }[];
            };
            revenueProgress: number;
            metrics: {
                electricity: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
                promotion: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
                smartPlacement: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
                goodReviews: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
            };
        }[];
    }>;
    targets(user: UserSession, storeId?: string): Promise<{
        actualRevenueCents: number;
        actualSessionCount: number;
        actualPlayerCount: number;
        revenueProgress: number;
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
        storeId: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        type: string;
        periodStart: Date;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        electricityBudgetCents: number;
        promotionBudgetCents: number;
        smartPlacementBudgetCents: number;
        goodReviewTarget: number;
        note: string | null;
        createdById: string;
    }[]>;
    goalRules(user: UserSession, storeId?: string): never[] | import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
    } & {
        storeId: string;
        active: boolean;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        note: string | null;
        dayType: string;
    })[]>;
    saveGoalRule(user: UserSession, dto: GoalRuleDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
    } & {
        storeId: string;
        active: boolean;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        note: string | null;
        dayType: string;
    }>;
    saveTarget(user: UserSession, dto: TargetDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        storeId: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        type: string;
        periodStart: Date;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        electricityBudgetCents: number;
        promotionBudgetCents: number;
        smartPlacementBudgetCents: number;
        goodReviewTarget: number;
        note: string | null;
        createdById: string;
    }>;
    reports(user: UserSession, storeId?: string): never[] | import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        storeId: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        createdById: string;
        reportDate: Date;
        reviewCount: number;
        goodReviewCount: number;
        premiumReviewCount: number;
        qualifiedReviewCount: number;
        clientReviewCount: number;
        csQualityReviewCount: number;
        kdbReviewCount: number;
        kdbPremiumCount: number;
        clientPremiumCount: number;
        meituanTicketCount: number;
        scanTicketCount: number;
        electricityCostCents: number;
        electricityUnits: number;
        promotionCostCents: number;
        smartPlacementCostCents: number;
        promotionLeads: number;
        refundCount: number;
        refundCents: number;
        notes: string | null;
    })[]>;
    saveReport(user: UserSession, dto: DailyReportDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        storeId: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        createdById: string;
        reportDate: Date;
        reviewCount: number;
        goodReviewCount: number;
        premiumReviewCount: number;
        qualifiedReviewCount: number;
        clientReviewCount: number;
        csQualityReviewCount: number;
        kdbReviewCount: number;
        kdbPremiumCount: number;
        clientPremiumCount: number;
        meituanTicketCount: number;
        scanTicketCount: number;
        electricityCostCents: number;
        electricityUnits: number;
        promotionCostCents: number;
        smartPlacementCostCents: number;
        promotionLeads: number;
        refundCount: number;
        refundCents: number;
        notes: string | null;
    }>;
    closeChecks(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        storeId: string;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        note: string | null;
        checklistDate: Date;
        items: string;
        submittedById: string;
        submittedAt: Date | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
    })[]>;
    saveCloseCheck(user: UserSession, dto: CloseChecklistDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        storeId: string;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        note: string | null;
        checklistDate: Date;
        items: string;
        submittedById: string;
        submittedAt: Date | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
    }>;
    reviewCloseCheck(user: UserSession, id: string, dto: CloseChecklistActionDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        storeId: string;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        note: string | null;
        checklistDate: Date;
        items: string;
        submittedById: string;
        submittedAt: Date | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
    }>;
    tasks(user: UserSession, storeId?: string, status?: string): never[] | import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
        submissions: ({
            submittedBy: {
                id: string;
                name: string;
            };
            reviewedBy: {
                id: string;
                name: string;
            } | null;
            evidences: {
                id: string;
                createdAt: Date;
                note: string | null;
                imageUrl: string;
                label: string;
                submissionId: string;
            }[];
        } & {
            status: string;
            id: string;
            createdAt: Date;
            note: string | null;
            submittedById: string;
            submittedAt: Date;
            reviewComment: string | null;
            reviewedById: string | null;
            reviewedAt: Date | null;
            completedAt: Date | null;
            taskId: string;
        })[];
    } & {
        storeId: string;
        assigneeId: string | null;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        createdById: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        completedAt: Date | null;
    })[]>;
    createTask(user: UserSession, dto: CreateTaskDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
        submissions: {
            status: string;
            id: string;
            createdAt: Date;
            note: string | null;
            submittedById: string;
            submittedAt: Date;
            reviewComment: string | null;
            reviewedById: string | null;
            reviewedAt: Date | null;
            completedAt: Date | null;
            taskId: string;
        }[];
    } & {
        storeId: string;
        assigneeId: string | null;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        createdById: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        completedAt: Date | null;
    }>;
    updateTask(user: UserSession, id: string, dto: UpdateTaskDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
    } & {
        storeId: string;
        assigneeId: string | null;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        createdById: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        completedAt: Date | null;
    }>;
    updateTaskFromMiniProgram(user: UserSession, id: string, dto: UpdateTaskDto): Promise<{
        store: {
            active: boolean;
            id: string;
            code: string;
            name: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
    } & {
        storeId: string;
        assigneeId: string | null;
        status: string;
        id: string;
        createdAt: Date;
        updatedAt: Date;
        createdById: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        completedAt: Date | null;
    }>;
    submitTask(user: UserSession, id: string, dto: TaskSubmissionDto): Promise<{
        submittedBy: {
            id: string;
            name: string;
        };
        evidences: {
            id: string;
            createdAt: Date;
            note: string | null;
            imageUrl: string;
            label: string;
            submissionId: string;
        }[];
    } & {
        status: string;
        id: string;
        createdAt: Date;
        note: string | null;
        submittedById: string;
        submittedAt: Date;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        completedAt: Date | null;
        taskId: string;
    }>;
    reviewTask(user: UserSession, id: string, submissionId: string, dto: SubmissionActionDto): Promise<{
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        evidences: {
            id: string;
            createdAt: Date;
            note: string | null;
            imageUrl: string;
            label: string;
            submissionId: string;
        }[];
    } & {
        status: string;
        id: string;
        createdAt: Date;
        note: string | null;
        submittedById: string;
        submittedAt: Date;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        completedAt: Date | null;
        taskId: string;
    }>;
    analytics(user: UserSession, storeId?: string, from?: string, to?: string): Promise<{
        range: {
            from: string;
            to: string;
        };
        summary: {
            revenueCents: number;
            sessionCount: number;
            playerCount: number;
            averageRevenueCents: number;
            refundCents: number;
            promotionCostCents: number;
            reviewCount: number;
            goodReviewCount: number;
            meituanTicketCount: number;
            electricityCostCents: number;
            smartPlacementCostCents: number;
            refundCount: number;
            cardIssueCount: number;
            cardIssueAmountCents: number;
            designatedSessionCount: number;
            cityLimitedSessionCount: number;
        };
        byStore: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byScript: {
            weightedSessions: number;
            category: string;
            sessionFactor: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
        }[];
        byHost: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byAssistant: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byNpc: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byDay: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        trend: {
            meituanTicketCount: number;
            refundCount: number;
            refundCents: number;
            reviewCount: number;
            goodReviewCount: number;
            refundRate: number;
            goodReviewRate: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
        }[];
        weeklyTrend: {
            refundRate: number;
            goodReviewRate: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
            meituanTicketCount: number;
            refundCount: number;
            refundCents: number;
            reviewCount: number;
            goodReviewCount: number;
        }[];
        monthlyTrend: {
            refundRate: number;
            goodReviewRate: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
            meituanTicketCount: number;
            refundCount: number;
            refundCents: number;
            reviewCount: number;
            goodReviewCount: number;
        }[];
        paymentChannels: {
            method: string;
            count: number;
            amountCents: number;
        }[];
        dailyReports: ({
            store: {
                active: boolean;
                id: string;
                code: string;
                name: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
                createdAt: Date;
                updatedAt: Date;
            };
        } & {
            storeId: string;
            id: string;
            createdAt: Date;
            updatedAt: Date;
            createdById: string;
            reportDate: Date;
            reviewCount: number;
            goodReviewCount: number;
            premiumReviewCount: number;
            qualifiedReviewCount: number;
            clientReviewCount: number;
            csQualityReviewCount: number;
            kdbReviewCount: number;
            kdbPremiumCount: number;
            clientPremiumCount: number;
            meituanTicketCount: number;
            scanTicketCount: number;
            electricityCostCents: number;
            electricityUnits: number;
            promotionCostCents: number;
            smartPlacementCostCents: number;
            promotionLeads: number;
            refundCount: number;
            refundCents: number;
            notes: string | null;
        })[];
        byCardType: {
            cardType: string;
            cardTypeLabel: string;
            count: number;
            amountCents: number;
        }[];
        byCityLimitedTheme: {
            theme: string;
            themeLabel: string;
            sessionCount: number;
            revenueCents: number;
        }[];
    }>;
    revenueDetails(user: UserSession, storeId?: string, from?: string, to?: string, paymentMethod?: string, scriptId?: string, hostId?: string, activity?: string, refundStatus?: string, keyword?: string, page?: string, pageSize?: string): Promise<{
        range: {
            from: string;
            to: string;
        };
        summary: {
            recordCount: number;
            sessionCount: number;
            originalAmountCents: number;
            amountCents: number;
            discountCents: number;
            refundCents: number;
            netAmountCents: number;
        };
        items: {
            id: string;
            playerName: string;
            phone: string | null;
            playerType: string;
            playerStatus: string;
            paymentMethod: string | null;
            activity: string | null;
            remark: string | null;
            amountCents: number;
            discountCents: number;
            refundedCents: number;
            netAmountCents: number;
            originalAmountCents: number;
            member: {
                id: string;
                name: string;
                tier: string;
            } | null;
            session: {
                id: string;
                code: string;
                state: string;
                startAt: Date;
                store: {
                    id: string;
                    name: string;
                };
                script: {
                    id: string;
                    name: string;
                    category: string;
                };
                host: {
                    id: string;
                    name: string;
                };
            };
        }[];
        filters: {
            stores: {
                id: string;
                name: string;
            }[];
            scripts: {
                id: string;
                name: string;
            }[];
            hosts: {
                id: string;
                name: string;
            }[];
            paymentMethods: string[];
            activities: string[];
        };
        pagination: {
            page: number;
            pageSize: number;
            total: number;
            totalPages: number;
        };
    }>;
    export(user: UserSession, storeId?: string, from?: string, to?: string): Promise<StreamableFile>;
}
export {};
