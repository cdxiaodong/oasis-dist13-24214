"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BusinessService = void 0;
const common_1 = require("@nestjs/common");
const exceljs_1 = __importDefault(require("exceljs"));
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
const assets_1 = require("../common/assets");
const SCRIPT_THEME_LABELS = {
    HORROR: "恐怖",
    EMOTION: "情感",
    REASONING: "推理",
    JOY_MECHANISM: "欢乐机制",
};
const CARD_TYPE_LABELS = { SINGLE: "单人卡", DOUBLE: "双人卡", MULTI: "多人卡" };
let BusinessService = class BusinessService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scope(user, storeId) {
        if (user.role === "CUSTOMER_SERVICE")
            throw new common_1.ForbiddenException("客服账号无权访问经营数据");
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return storeId;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (storeId && storeId !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    requiredStore(user, storeId) {
        const scoped = this.scope(user, storeId);
        if (!scoped)
            throw new common_1.BadRequestException("请选择门店");
        return scoped;
    }
    dateOnly(value) {
        const date = new Date(`${value.slice(0, 10)}T00:00:00.000+08:00`);
        if (Number.isNaN(date.getTime()))
            throw new common_1.BadRequestException("日期格式不正确");
        return date;
    }
    range(query) {
        const now = new Date();
        const from = query.from ? this.dateOnly(query.from) : new Date(now.getFullYear(), now.getMonth(), 1);
        const toStart = query.to ? this.dateOnly(query.to) : new Date(now.getFullYear(), now.getMonth() + 1, 0);
        const to = new Date(toStart.getTime() + 24 * 60 * 60 * 1000);
        if (from >= to)
            throw new common_1.BadRequestException("开始日期必须早于结束日期");
        return { from, to };
    }
    chinaDateKey(date) {
        const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
        const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
        return `${values.year}-${values.month}-${values.day}`;
    }
    async targets(user, storeId) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            return [];
        const scoped = this.scope(user, storeId);
        const targets = await this.prisma.businessTarget.findMany({
            where: scoped ? { storeId: scoped } : {},
            include: { store: true, createdBy: { select: { id: true, name: true } } },
            orderBy: { periodStart: "desc" },
            take: 100,
        });
        return Promise.all(targets.map(async (target) => {
            const periodEnd = new Date(target.periodStart);
            if (target.type === "MONTHLY")
                periodEnd.setUTCMonth(periodEnd.getUTCMonth() + 1);
            else
                periodEnd.setUTCDate(periodEnd.getUTCDate() + 1);
            const sessions = await this.prisma.gameSession.findMany({
                where: { storeId: target.storeId, startAt: { gte: target.periodStart, lt: periodEnd }, state: { not: "CANCELLED" } },
                include: { players: true },
            });
            const actualRevenueCents = sessions.flatMap((session) => session.players).reduce((sum, player) => sum + player.amountCents - player.refundedCents, 0);
            const actualPlayerCount = sessions.reduce((sum, session) => sum + session.players.filter((player) => player.status === "ACTIVE").length, 0);
            return {
                ...target, actualRevenueCents, actualSessionCount: sessions.length, actualPlayerCount,
                revenueProgress: target.revenueTargetCents ? Math.round(actualRevenueCents / target.revenueTargetCents * 100) : 0,
            };
        }));
    }
    goalRules(user, storeId) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            return [];
        const scoped = this.scope(user, storeId);
        return this.prisma.businessGoalRule.findMany({ where: scoped ? { storeId: scoped } : {}, include: { store: true }, orderBy: [{ store: { name: "asc" } }, { dayType: "asc" }] });
    }
    async saveGoalRule(user, data) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以设置目标模板");
        const storeId = this.requiredStore(user, data.storeId);
        const saved = await this.prisma.businessGoalRule.upsert({
            where: { storeId_dayType: { storeId, dayType: data.dayType } },
            create: { ...data, storeId }, update: { revenueTargetCents: data.revenueTargetCents, sessionTarget: data.sessionTarget, playerTarget: data.playerTarget, active: data.active, note: data.note }, include: { store: true },
        });
        await this.audit(user, "SAVE_GOAL_RULE", "BusinessGoalRule", saved.id, data);
        return saved;
    }
    async saveTarget(user, data) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以设置经营目标");
        const storeId = this.requiredStore(user, data.storeId);
        const periodStart = this.dateOnly(data.periodStart);
        const saved = await this.prisma.businessTarget.upsert({
            where: { storeId_type_periodStart: { storeId, type: data.type, periodStart } },
            create: { ...data, storeId, periodStart, createdById: user.id },
            update: { revenueTargetCents: data.revenueTargetCents, sessionTarget: data.sessionTarget, playerTarget: data.playerTarget, electricityBudgetCents: data.electricityBudgetCents, promotionBudgetCents: data.promotionBudgetCents, smartPlacementBudgetCents: data.smartPlacementBudgetCents, goodReviewTarget: data.goodReviewTarget, note: data.note },
            include: { store: true, createdBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "SAVE_BUSINESS_TARGET", "BusinessTarget", saved.id, { storeId, type: data.type, periodStart });
        return saved;
    }
    dailyReports(user, storeId) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            return [];
        const scoped = this.scope(user, storeId);
        return this.prisma.dailyReport.findMany({
            where: scoped ? { storeId: scoped } : {},
            include: { store: true, createdBy: { select: { id: true, name: true } } },
            orderBy: { reportDate: "desc" },
            take: 100,
        });
    }
    async saveDailyReport(user, data) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以填报经营日报");
        const storeId = this.requiredStore(user, data.storeId);
        const reportDate = this.dateOnly(data.reportDate);
        const categorizedGoodReviews = (data.premiumReviewCount ?? 0) + (data.qualifiedReviewCount ?? 0) + (data.clientReviewCount ?? 0);
        const goodReviewCount = categorizedGoodReviews || data.goodReviewCount;
        const values = { ...data, goodReviewCount, storeId, reportDate };
        const saved = await this.prisma.dailyReport.upsert({
            where: { storeId_reportDate: { storeId, reportDate } },
            create: { ...values, createdById: user.id },
            update: values,
            include: { store: true, createdBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "SAVE_DAILY_REPORT", "DailyReport", saved.id, { storeId, reportDate });
        return saved;
    }
    closeChecklists(user, storeId) {
        const scoped = this.scope(user, storeId);
        const ownOnly = !["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role);
        return this.prisma.closeChecklist.findMany({
            where: { ...(scoped ? { storeId: scoped } : {}), ...(ownOnly ? { submittedById: user.id } : {}) },
            include: { store: true, submittedBy: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } } },
            orderBy: { checklistDate: "desc" },
            take: 100,
        });
    }
    async saveCloseChecklist(user, data) {
        if (!["DM", "MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有值班主持人、店长或总部可以提交闭店检查");
        const storeId = this.requiredStore(user, data.storeId);
        const checklistDate = this.dateOnly(data.checklistDate);
        if (!data.items.length)
            throw new common_1.BadRequestException("闭店检查项不能为空");
        if (data.submit && data.items.some((item) => !item.checked))
            throw new common_1.BadRequestException("仍有未完成的闭店检查项");
        if (data.submit && data.items.some((item) => !item.imageUrl))
            throw new common_1.BadRequestException("每个闭店检查项都必须拍摄现场照片");
        const items = data.items.map((item) => ({ ...item, ...(item.imageUrl ? { imageUrl: (0, assets_1.protectedImageUrl)(item.imageUrl, "闭店照片") } : {}) }));
        const status = data.submit ? "SUBMITTED" : "DRAFT";
        const reviewStatus = data.submit ? "PENDING" : "NOT_SUBMITTED";
        const saved = await this.prisma.closeChecklist.upsert({
            where: { storeId_checklistDate: { storeId, checklistDate } },
            create: { storeId, checklistDate, items: JSON.stringify(items), note: data.note, status, reviewStatus, submittedById: user.id, submittedAt: data.submit ? new Date() : null },
            update: { items: JSON.stringify(items), note: data.note, status, reviewStatus, reviewComment: null, reviewedById: null, reviewedAt: null, submittedById: user.id, submittedAt: data.submit ? new Date() : null },
            include: { store: true, submittedBy: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, data.submit ? "SUBMIT_CLOSE_CHECK" : "SAVE_CLOSE_CHECK", "CloseChecklist", saved.id, { storeId, checklistDate });
        return saved;
    }
    async reviewCloseChecklist(user, id, action, comment) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以审核闭店记录");
        const item = await this.prisma.closeChecklist.findUnique({ where: { id } });
        if (!item)
            throw new common_1.NotFoundException("闭店记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, item.storeId))
            throw new common_1.ForbiddenException("无权审核其他门店闭店记录");
        if (item.reviewStatus !== "PENDING")
            throw new common_1.BadRequestException("闭店记录不在待审核状态");
        if (action === "REJECT" && !comment?.trim())
            throw new common_1.BadRequestException("打回时必须填写原因");
        const updated = await this.prisma.closeChecklist.update({
            where: { id },
            data: { reviewStatus: action === "APPROVE" ? "APPROVED" : "REJECTED", reviewComment: comment?.trim(), reviewedById: user.id, reviewedAt: new Date(), status: action === "APPROVE" ? "APPROVED" : "REJECTED" },
            include: { store: true, submittedBy: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, `CLOSE_CHECK_${action}`, "CloseChecklist", id, { comment });
        return updated;
    }
    tasks(user, query) {
        const scoped = this.scope(user, query.storeId);
        if (user.role === "FINANCE")
            return [];
        const ownOnly = !["MANAGER", "HEADQUARTERS"].includes(user.role);
        return this.prisma.operationTask.findMany({
            where: { ...(scoped ? { storeId: scoped } : {}), ...(ownOnly ? { assigneeId: user.id } : {}), ...(query.status ? { status: query.status } : {}) },
            include: { store: true, assignee: { select: { id: true, name: true } }, createdBy: { select: { id: true, name: true } }, submissions: { include: { submittedBy: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } }, evidences: true }, orderBy: { submittedAt: "desc" }, take: 5 } },
            orderBy: [{ status: "asc" }, { priority: "desc" }, { dueAt: "asc" }, { createdAt: "desc" }],
            take: 200,
        });
    }
    async createTask(user, data) {
        if (user.role !== "HEADQUARTERS")
            throw new common_1.ForbiddenException("只有管理员可以向店长下发代办");
        const storeId = this.requiredStore(user, data.storeId);
        await this.validateAssignee(storeId, data.assigneeId);
        const task = await this.prisma.operationTask.create({
            data: { ...data, evidenceLabels: JSON.stringify(data.evidenceLabels ?? []), storeId, priority: data.priority ?? "MEDIUM", dueAt: data.dueAt ? new Date(data.dueAt) : undefined, createdById: user.id },
            include: { store: true, assignee: { select: { id: true, name: true } }, createdBy: { select: { id: true, name: true } }, submissions: true },
        });
        await this.audit(user, "CREATE_OPERATION_TASK", "OperationTask", task.id, { storeId, assigneeId: data.assigneeId });
        return task;
    }
    async updateTask(user, id, data) {
        const task = await this.prisma.operationTask.findUnique({ where: { id } });
        if (!task)
            throw new common_1.NotFoundException("待办不存在");
        if (!(0, user_session_1.canAccessStore)(user, task.storeId))
            throw new common_1.ForbiddenException("无权处理该待办");
        const canManage = ["MANAGER", "HEADQUARTERS"].includes(user.role) || task.createdById === user.id;
        if (!canManage && task.assigneeId !== user.id)
            throw new common_1.ForbiddenException("只有负责人或创建人可以更新待办");
        if (!canManage && Object.entries(data).some(([key, value]) => value !== undefined && key !== "status"))
            throw new common_1.ForbiddenException("负责人只能更新待办状态");
        if (data.status === "DONE" && task.evidenceRequired) {
            const approved = await this.prisma.taskSubmission.count({ where: { taskId: id, status: "APPROVED" } });
            if (!approved)
                throw new common_1.BadRequestException("该任务要求图片证据，审核通过后才能完成");
        }
        await this.validateAssignee(task.storeId, data.assigneeId);
        const updated = await this.prisma.operationTask.update({
            where: { id },
            data: { ...data, dueAt: data.dueAt ? new Date(data.dueAt) : undefined, completedAt: data.status === "DONE" ? new Date() : data.status ? null : undefined },
            include: { store: true, assignee: { select: { id: true, name: true } }, createdBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "UPDATE_OPERATION_TASK", "OperationTask", id, data);
        return updated;
    }
    async submitTask(user, taskId, data) {
        const task = await this.prisma.operationTask.findUnique({ where: { id: taskId } });
        if (!task)
            throw new common_1.NotFoundException("待办不存在");
        if (!(0, user_session_1.canAccessStore)(user, task.storeId))
            throw new common_1.ForbiddenException("无权提交该待办");
        if (task.assigneeId !== user.id && !["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有负责人可以提交任务证据");
        if (["DONE", "CANCELLED"].includes(task.status))
            throw new common_1.BadRequestException("该任务已经结束");
        const required = JSON.parse(task.evidenceLabels || "[]");
        const evidences = data.evidences.map((item) => ({ ...item, imageUrl: (0, assets_1.protectedImageUrl)(item.imageUrl, "任务证据") }));
        const submitted = new Set(evidences.map((item) => item.label));
        const missing = required.filter((label) => !submitted.has(label));
        if (task.evidenceRequired && missing.length)
            throw new common_1.BadRequestException(`缺少任务证据：${missing.join("、")}`);
        const submission = await this.prisma.$transaction(async (tx) => {
            const completedAt = data.completedAt ? new Date(data.completedAt) : new Date();
            if (Number.isNaN(completedAt.getTime()))
                throw new common_1.BadRequestException("完成时间格式不正确");
            const created = await tx.taskSubmission.create({ data: { taskId, submittedById: user.id, note: data.note, completedAt, evidences: { create: evidences } }, include: { evidences: true, submittedBy: { select: { id: true, name: true } } } });
            await tx.operationTask.update({ where: { id: taskId }, data: { status: "IN_PROGRESS" } });
            return created;
        });
        await this.audit(user, "SUBMIT_TASK_EVIDENCE", "TaskSubmission", submission.id, { taskId, evidenceCount: data.evidences.length });
        return submission;
    }
    async reviewTaskSubmission(user, taskId, submissionId, action, comment) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以审核任务证据");
        const submission = await this.prisma.taskSubmission.findFirst({ where: { id: submissionId, taskId }, include: { task: true } });
        if (!submission)
            throw new common_1.NotFoundException("任务提交记录不存在");
        if (!(0, user_session_1.canAccessStore)(user, submission.task.storeId))
            throw new common_1.ForbiddenException("无权审核该门店任务");
        if (submission.status !== "PENDING")
            throw new common_1.BadRequestException("该提交已经审核");
        const updated = await this.prisma.$transaction(async (tx) => {
            const result = await tx.taskSubmission.update({ where: { id: submissionId }, data: { status: action === "APPROVE" ? "APPROVED" : "REJECTED", reviewComment: comment, reviewedById: user.id, reviewedAt: new Date() }, include: { evidences: true, submittedBy: { select: { id: true, name: true } }, reviewedBy: { select: { id: true, name: true } } } });
            await tx.operationTask.update({ where: { id: taskId }, data: { status: action === "APPROVE" ? "DONE" : "IN_PROGRESS", completedAt: action === "APPROVE" ? new Date() : null } });
            return result;
        });
        await this.audit(user, `TASK_EVIDENCE_${action}`, "TaskSubmission", submissionId, { taskId, comment });
        return updated;
    }
    periodicReports(user, storeId) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            return [];
        const scoped = this.scope(user, storeId);
        return this.prisma.periodicReport.findMany({ where: scoped ? { storeId: scoped } : {}, include: { store: true, createdBy: { select: { id: true, name: true } } }, orderBy: { periodStart: "desc" }, take: 100 });
    }
    async savePeriodicReport(user, data) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以填报周期报告");
        const storeId = this.requiredStore(user, data.storeId);
        const periodStart = this.dateOnly(data.periodStart);
        const saved = await this.prisma.periodicReport.upsert({
            where: { storeId_type_periodStart: { storeId, type: data.type, periodStart } },
            create: { storeId, type: data.type, periodStart, metrics: JSON.stringify(data.metrics), notes: data.notes, createdById: user.id },
            update: { metrics: JSON.stringify(data.metrics), notes: data.notes, createdById: user.id, submittedAt: new Date() },
            include: { store: true, createdBy: { select: { id: true, name: true } } },
        });
        await this.audit(user, "SAVE_PERIODIC_REPORT", "PeriodicReport", saved.id, { storeId, type: data.type, periodStart });
        return saved;
    }
    async reportReminders(user, storeId) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            return [];
        const scoped = this.scope(user, storeId);
        const stores = await this.prisma.store.findMany({ where: { active: true, ...(scoped ? { id: scoped } : {}) }, select: { id: true, name: true } });
        const todayKey = this.chinaDateKey(new Date());
        const today = this.dateOnly(todayKey);
        const [year, month, day] = todayKey.split("-").map(Number);
        const calendarDay = new Date(Date.UTC(year, month - 1, day));
        const weekday = (calendarDay.getUTCDay() + 6) % 7;
        calendarDay.setUTCDate(calendarDay.getUTCDate() - weekday);
        const weekStart = this.dateOnly(calendarDay.toISOString().slice(0, 10));
        const monthStart = this.dateOnly(`${year}-${String(month).padStart(2, "0")}-01`);
        const reminders = [];
        for (const store of stores) {
            const [daily, weekly, monthly] = await Promise.all([
                this.prisma.dailyReport.count({ where: { storeId: store.id, reportDate: today } }),
                this.prisma.periodicReport.count({ where: { storeId: store.id, type: "WEEKLY", periodStart: weekStart } }),
                this.prisma.periodicReport.count({ where: { storeId: store.id, type: "MONTHLY", periodStart: monthStart } }),
            ]);
            if (!daily)
                reminders.push({ storeId: store.id, storeName: store.name, type: "DAILY", periodStart: today, label: "今日经营日报未提交" });
            if (!weekly)
                reminders.push({ storeId: store.id, storeName: store.name, type: "WEEKLY", periodStart: weekStart, label: "本周周报未提交" });
            if (!monthly)
                reminders.push({ storeId: store.id, storeName: store.name, type: "MONTHLY", periodStart: monthStart, label: "本月月报未提交" });
        }
        return reminders;
    }
    async overview(user, storeId) {
        const scoped = this.scope(user, storeId);
        const today = this.dateOnly(this.chinaDateKey(new Date()));
        const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
        const where = scoped ? { storeId: scoped } : {};
        const ownOnly = !["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role);
        const [openTasks, pendingSessions, pendingReimbursements, todayReports, todayChecks] = await Promise.all([
            this.prisma.operationTask.count({ where: { ...where, ...(ownOnly ? { assigneeId: user.id } : {}), status: { in: ["OPEN", "IN_PROGRESS"] } } }),
            this.prisma.gameSession.count({ where: { ...where, state: "PENDING_APPROVAL" } }),
            this.prisma.reimbursement.count({ where: { ...where, status: { in: ["PENDING_MANAGER", "PENDING_FINANCE"] } } }),
            this.prisma.dailyReport.count({ where: { ...where, reportDate: { gte: today, lt: tomorrow } } }),
            this.prisma.closeChecklist.count({ where: { ...where, checklistDate: { gte: today, lt: tomorrow }, status: "SUBMITTED" } }),
        ]);
        const storeCount = scoped ? 1 : await this.prisma.store.count({ where: { active: true } });
        const monthKey = this.chinaDateKey(new Date()).slice(0, 7);
        const monthStart = this.dateOnly(`${monthKey}-01`);
        const nextMonth = new Date(monthStart);
        nextMonth.setUTCMonth(nextMonth.getUTCMonth() + 1);
        const daysInMonth = Math.round((nextMonth.getTime() - monthStart.getTime()) / 86_400_000);
        const elapsedDays = Math.min(daysInMonth, Math.max(1, Number(this.chinaDateKey(new Date()).slice(8, 10))));
        const stores = await this.prisma.store.findMany({ where: { active: true, ...(scoped ? { id: scoped } : {}) }, select: { id: true, name: true } });
        const storeMetrics = await Promise.all(stores.map(async (store) => {
            const [target, reports, sessions, memberCount] = await Promise.all([
                this.prisma.businessTarget.findUnique({ where: { storeId_type_periodStart: { storeId: store.id, type: "MONTHLY", periodStart: monthStart } } }),
                this.prisma.dailyReport.findMany({ where: { storeId: store.id, reportDate: { gte: monthStart, lt: nextMonth } } }),
                this.prisma.gameSession.findMany({ where: { storeId: store.id, startAt: { gte: monthStart, lt: nextMonth }, state: { not: "CANCELLED" } }, include: { script: true, designations: true, players: true } }),
                this.prisma.member.count({ where: { storeId: store.id, status: "ACTIVE" } }),
            ]);
            const cardLedgers = await this.prisma.memberLedger.findMany({
                where: { type: "RECHARGE", createdAt: { gte: monthStart, lt: nextMonth }, member: { storeId: store.id } },
                include: { member: { select: { tier: true } } },
            });
            const revenueCents = sessions.flatMap((item) => item.players).reduce((sum, player) => sum + player.amountCents - player.refundedCents, 0);
            const actual = {
                electricityCents: reports.reduce((sum, item) => sum + item.electricityCostCents, 0),
                promotionCents: reports.reduce((sum, item) => sum + item.promotionCostCents, 0),
                smartPlacementCents: reports.reduce((sum, item) => sum + item.smartPlacementCostCents, 0),
                goodReviews: reports.reduce((sum, item) => sum + item.goodReviewCount, 0),
            };
            const metric = (budget, value, reverse = false) => {
                const expected = Math.round(budget * elapsedDays / daysInMonth);
                const variance = value - expected;
                return { budget, expected, actual: value, variance, status: reverse ? (variance >= 0 ? "GOOD" : "WARN") : (variance <= 0 ? "GOOD" : "WARN") };
            };
            return {
                storeId: store.id, storeName: store.name, revenueCents, memberCount, sessionCount: sessions.length,
                operationStats: {
                    cardIssueCount: cardLedgers.length,
                    cardIssueAmountCents: cardLedgers.reduce((sum, item) => sum + item.amountCents, 0),
                    designatedSessionCount: sessions.filter((item) => item.designationStatus === "DESIGNATED" || item.designations.length > 0).length,
                    cityLimitedSessionCount: sessions.filter((item) => item.script.category === "CITY_LIMIT").length,
                    cityLimitedByTheme: Object.keys(SCRIPT_THEME_LABELS).map((theme) => ({
                        theme, themeLabel: SCRIPT_THEME_LABELS[theme],
                        sessionCount: sessions.filter((item) => item.script.category === "CITY_LIMIT" && item.script.theme === theme).length,
                    })),
                },
                revenueProgress: target?.revenueTargetCents ? Math.round(revenueCents / target.revenueTargetCents * 100) : 0,
                metrics: {
                    electricity: metric(target?.electricityBudgetCents ?? 0, actual.electricityCents),
                    promotion: metric(target?.promotionBudgetCents ?? 0, actual.promotionCents),
                    smartPlacement: metric(target?.smartPlacementBudgetCents ?? 0, actual.smartPlacementCents),
                    goodReviews: metric(target?.goodReviewTarget ?? 0, actual.goodReviews, true),
                },
            };
        }));
        return {
            openTasks, pendingSessions, pendingReimbursements,
            missingDailyReports: ownOnly ? 0 : Math.max(0, storeCount - todayReports),
            missingCloseChecks: ownOnly ? 0 : Math.max(0, storeCount - todayChecks),
            month: monthKey,
            storeMetrics,
        };
    }
    async analytics(user, query) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("当前岗位无权查看经营分析");
        const storeId = this.scope(user, query.storeId);
        const { from, to } = this.range(query);
        const sessions = await this.prisma.gameSession.findMany({
            where: { ...(storeId ? { storeId } : {}), startAt: { gte: from, lt: to }, state: { not: "CANCELLED" } },
            include: {
                store: true,
                script: true,
                host: { select: { id: true, name: true } },
                assistant: { select: { id: true, name: true } },
                npc: { select: { id: true, name: true } },
                staffAssignments: { where: { status: { not: "DECLINED" } }, include: { user: { select: { id: true, name: true } } } },
                designations: true,
                players: true,
            },
            orderBy: { startAt: "asc" },
        });
        const reports = await this.prisma.dailyReport.findMany({
            where: { ...(storeId ? { storeId } : {}), reportDate: { gte: from, lt: to } },
            include: { store: true },
            orderBy: { reportDate: "asc" },
        });
        const cardLedgers = await this.prisma.memberLedger.findMany({
            where: { type: "RECHARGE", createdAt: { gte: from, lt: to }, ...(storeId ? { member: { storeId } } : {}) },
            include: { member: { select: { tier: true } } },
        });
        const map = () => new Map();
        const stores = map();
        const scripts = map();
        const hosts = map();
        const assistants = map();
        const npcs = map();
        const days = map();
        const scriptMeta = new Map();
        const meituanByDay = new Map();
        const paymentChannels = new Map();
        let revenueCents = 0;
        let playerCount = 0;
        let designatedSessionCount = 0;
        let cityLimitedSessionCount = 0;
        const cityLimitedThemes = new Map();
        const add = (bucket, key, name, players, revenue) => {
            const item = bucket.get(key) ?? { key, name, sessions: 0, players: 0, revenueCents: 0 };
            item.sessions += 1;
            item.players += players;
            item.revenueCents += revenue;
            bucket.set(key, item);
        };
        for (const session of sessions) {
            const activePlayers = session.players.filter((player) => player.status === "ACTIVE");
            const players = activePlayers.length;
            const revenue = session.players.reduce((sum, player) => sum + player.amountCents - player.refundedCents, 0);
            const day = this.chinaDateKey(session.startAt);
            revenueCents += revenue;
            playerCount += players;
            designatedSessionCount += session.designationStatus === "DESIGNATED" || session.designations.length > 0 ? 1 : 0;
            if (session.script.category === "CITY_LIMIT") {
                cityLimitedSessionCount += 1;
                const theme = session.script.theme;
                const row = cityLimitedThemes.get(theme) ?? { theme, themeLabel: SCRIPT_THEME_LABELS[theme] || theme, sessionCount: 0, revenueCents: 0 };
                row.sessionCount += 1;
                row.revenueCents += revenue;
                cityLimitedThemes.set(theme, row);
            }
            add(stores, session.storeId, session.store.name, players, revenue);
            add(scripts, session.scriptId, session.script.name, players, revenue);
            add(hosts, session.hostId, session.host.name, players, revenue);
            const assistantAssignments = session.staffAssignments.filter((item) => item.role === "ASSISTANT");
            const npcAssignments = session.staffAssignments.filter((item) => item.role === "NPC");
            if (assistantAssignments.length)
                assistantAssignments.forEach((item) => add(assistants, item.userId, item.user.name, players, revenue));
            else if (session.assistant)
                add(assistants, session.assistantId, session.assistant.name, players, revenue);
            if (npcAssignments.length)
                npcAssignments.forEach((item) => add(npcs, item.userId, item.user.name, players, revenue));
            else if (session.npc)
                add(npcs, session.npcId, session.npc.name, players, revenue);
            add(days, day, day, players, revenue);
            scriptMeta.set(session.scriptId, { category: session.script.category, sessionFactor: session.script.sessionFactor });
            for (const player of activePlayers) {
                if (!player.paymentMethod)
                    continue;
                const net = player.amountCents - player.refundedCents;
                const channel = paymentChannels.get(player.paymentMethod) ?? { method: player.paymentMethod, count: 0, amountCents: 0 };
                channel.count += 1;
                channel.amountCents += net;
                paymentChannels.set(player.paymentMethod, channel);
                if (player.paymentMethod.startsWith("MEITUAN") && net > 0)
                    meituanByDay.set(day, (meituanByDay.get(day) ?? 0) + 1);
            }
        }
        for (const report of reports) {
            const day = this.chinaDateKey(report.reportDate);
            if (!days.has(day))
                days.set(day, { key: day, name: day, sessions: 0, players: 0, revenueCents: 0 });
        }
        const reportByDay = new Map();
        for (const report of reports) {
            const key = this.chinaDateKey(report.reportDate);
            const total = reportByDay.get(key) ?? { refundCount: 0, refundCents: 0, reviewCount: 0, goodReviewCount: 0 };
            total.refundCount += report.refundCount;
            total.refundCents += report.refundCents;
            total.reviewCount += report.reviewCount;
            total.goodReviewCount += report.goodReviewCount;
            reportByDay.set(key, total);
        }
        const trend = [...days.values()].sort((a, b) => a.key.localeCompare(b.key)).map((item) => {
            const report = reportByDay.get(item.key);
            const meituanTicketCount = meituanByDay.get(item.key) ?? 0;
            return { ...item, meituanTicketCount, refundCount: report?.refundCount ?? 0, refundCents: report?.refundCents ?? 0, reviewCount: report?.reviewCount ?? 0, goodReviewCount: report?.goodReviewCount ?? 0, refundRate: item.players ? Math.round((report?.refundCount ?? 0) / item.players * 1000) / 10 : 0, goodReviewRate: meituanTicketCount ? Math.round((report?.goodReviewCount ?? 0) / meituanTicketCount * 1000) / 10 : 0 };
        });
        const aggregateTrend = (period) => {
            const buckets = new Map();
            for (const item of trend) {
                let key = item.key.slice(0, 7);
                if (period === "WEEK") {
                    const [year, month, day] = item.key.split("-").map(Number);
                    const date = new Date(Date.UTC(year, month - 1, day));
                    date.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7));
                    key = date.toISOString().slice(0, 10);
                }
                const row = buckets.get(key) ?? { key, name: period === "WEEK" ? `${key} 当周` : key, sessions: 0, players: 0, revenueCents: 0, meituanTicketCount: 0, refundCount: 0, refundCents: 0, reviewCount: 0, goodReviewCount: 0 };
                row.sessions += item.sessions;
                row.players += item.players;
                row.revenueCents += item.revenueCents;
                row.meituanTicketCount += item.meituanTicketCount;
                row.refundCount += item.refundCount;
                row.refundCents += item.refundCents;
                row.reviewCount += item.reviewCount;
                row.goodReviewCount += item.goodReviewCount;
                buckets.set(key, row);
            }
            return [...buckets.values()].sort((a, b) => a.key.localeCompare(b.key)).map((item) => ({ ...item, refundRate: item.players ? Math.round(item.refundCount / item.players * 1000) / 10 : 0, goodReviewRate: item.meituanTicketCount ? Math.round(item.goodReviewCount / item.meituanTicketCount * 1000) / 10 : 0 }));
        };
        const scriptRows = [...scripts.values()].map((item) => { const meta = scriptMeta.get(item.key) ?? { category: "STANDARD", sessionFactor: 1 }; return { ...item, ...meta, weightedSessions: Math.round(item.sessions * meta.sessionFactor * 10) / 10 }; }).sort((a, b) => b.revenueCents - a.revenueCents);
        return {
            range: { from: from.toISOString(), to: new Date(to.getTime() - 1).toISOString() },
            summary: {
                revenueCents, sessionCount: sessions.length, playerCount,
                averageRevenueCents: sessions.length ? Math.round(revenueCents / sessions.length) : 0,
                refundCents: reports.reduce((sum, item) => sum + item.refundCents, 0),
                promotionCostCents: reports.reduce((sum, item) => sum + item.promotionCostCents, 0),
                reviewCount: reports.reduce((sum, item) => sum + item.reviewCount, 0),
                goodReviewCount: reports.reduce((sum, item) => sum + item.goodReviewCount, 0),
                meituanTicketCount: [...meituanByDay.values()].reduce((sum, item) => sum + item, 0),
                electricityCostCents: reports.reduce((sum, item) => sum + item.electricityCostCents, 0),
                smartPlacementCostCents: reports.reduce((sum, item) => sum + item.smartPlacementCostCents, 0),
                refundCount: reports.reduce((sum, item) => sum + item.refundCount, 0),
                cardIssueCount: cardLedgers.length,
                cardIssueAmountCents: cardLedgers.reduce((sum, item) => sum + item.amountCents, 0),
                designatedSessionCount,
                cityLimitedSessionCount,
            },
            byStore: [...stores.values()].sort((a, b) => b.revenueCents - a.revenueCents),
            byScript: scriptRows,
            byHost: [...hosts.values()].sort((a, b) => b.revenueCents - a.revenueCents),
            byAssistant: [...assistants.values()].sort((a, b) => b.revenueCents - a.revenueCents),
            byNpc: [...npcs.values()].sort((a, b) => b.revenueCents - a.revenueCents),
            byDay: [...days.values()],
            trend,
            weeklyTrend: aggregateTrend("WEEK"),
            monthlyTrend: aggregateTrend("MONTH"),
            paymentChannels: [...paymentChannels.values()].sort((a, b) => b.amountCents - a.amountCents),
            dailyReports: reports,
            byCardType: Object.keys(CARD_TYPE_LABELS).map((cardType) => {
                const rows = cardLedgers.filter((item) => item.member.tier === cardType);
                return { cardType, cardTypeLabel: CARD_TYPE_LABELS[cardType], count: rows.length, amountCents: rows.reduce((sum, item) => sum + item.amountCents, 0) };
            }),
            byCityLimitedTheme: [...cityLimitedThemes.values()].sort((a, b) => b.sessionCount - a.sessionCount),
        };
    }
    async revenueDetails(user, query) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("当前岗位无权查看营业明细");
        const storeId = this.scope(user, query.storeId);
        const { from, to } = this.range(query);
        const page = Math.max(1, Number(query.page) || 1);
        const pageSize = Math.min(100, Math.max(10, Number(query.pageSize) || 20));
        const keyword = query.keyword?.trim();
        const sessionWhere = {
            ...(storeId ? { storeId } : {}),
            startAt: { gte: from, lt: to },
            state: { not: "CANCELLED" },
        };
        const baseWhere = {
            session: sessionWhere,
            OR: [
                { paymentMethod: { not: null } },
                { amountCents: { not: 0 } },
                { discountCents: { not: 0 } },
                { refundedCents: { not: 0 } },
            ],
        };
        const where = {
            ...baseWhere,
            ...(query.paymentMethod ? { paymentMethod: query.paymentMethod } : {}),
            ...(query.activity ? { activity: query.activity } : {}),
            ...(query.refundStatus === "REFUNDED" ? { refundedCents: { gt: 0 } } : {}),
            ...(query.refundStatus === "NOT_REFUNDED" ? { refundedCents: 0 } : {}),
            ...(query.scriptId || query.hostId ? {
                session: { ...sessionWhere, ...(query.scriptId ? { scriptId: query.scriptId } : {}), ...(query.hostId ? { hostId: query.hostId } : {}) },
            } : {}),
            ...(keyword ? {
                AND: [{
                        OR: [
                            { name: { contains: keyword } }, { phone: { contains: keyword } }, { remark: { contains: keyword } },
                            { session: { code: { contains: keyword } } }, { session: { script: { name: { contains: keyword } } } },
                            { session: { host: { name: { contains: keyword } } } },
                        ],
                    }],
            } : {}),
        };
        const [total, items, totals, groupedSessions, filterSessions, filterPlayers] = await Promise.all([
            this.prisma.sessionPlayer.count({ where }),
            this.prisma.sessionPlayer.findMany({
                where,
                include: {
                    member: { select: { id: true, name: true, tier: true } },
                    session: {
                        include: {
                            store: { select: { id: true, name: true } },
                            script: { select: { id: true, name: true, category: true } },
                            host: { select: { id: true, name: true } },
                        },
                    },
                },
                orderBy: [{ session: { startAt: "desc" } }, { createdAt: "desc" }],
                skip: (page - 1) * pageSize,
                take: pageSize,
            }),
            this.prisma.sessionPlayer.aggregate({
                where,
                _sum: { amountCents: true, discountCents: true, refundedCents: true },
            }),
            this.prisma.sessionPlayer.groupBy({ by: ["sessionId"], where, _count: { _all: true } }),
            this.prisma.gameSession.findMany({
                where: sessionWhere,
                select: {
                    store: { select: { id: true, name: true } },
                    script: { select: { id: true, name: true } },
                    host: { select: { id: true, name: true } },
                },
            }),
            this.prisma.sessionPlayer.findMany({
                where: baseWhere,
                select: { paymentMethod: true, activity: true },
                distinct: ["paymentMethod", "activity"],
            }),
        ]);
        const amountCents = totals._sum.amountCents ?? 0;
        const discountCents = totals._sum.discountCents ?? 0;
        const refundCents = totals._sum.refundedCents ?? 0;
        const uniqueOptions = (values) => [...new Map(values.map((item) => [item.id, item])).values()].sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
        return {
            range: { from: this.chinaDateKey(from), to: this.chinaDateKey(new Date(to.getTime() - 1)) },
            summary: {
                recordCount: total,
                sessionCount: groupedSessions.length,
                originalAmountCents: amountCents + discountCents,
                amountCents,
                discountCents,
                refundCents,
                netAmountCents: amountCents - refundCents,
            },
            items: items.map((item) => ({
                id: item.id,
                playerName: item.name,
                phone: item.phone,
                playerType: item.type,
                playerStatus: item.status,
                paymentMethod: item.paymentMethod,
                activity: item.activity,
                remark: item.remark,
                amountCents: item.amountCents,
                discountCents: item.discountCents,
                refundedCents: item.refundedCents,
                netAmountCents: item.amountCents - item.refundedCents,
                originalAmountCents: item.amountCents + item.discountCents,
                member: item.member,
                session: {
                    id: item.session.id,
                    code: item.session.code,
                    state: item.session.state,
                    startAt: item.session.startAt,
                    store: item.session.store,
                    script: item.session.script,
                    host: item.session.host,
                },
            })),
            filters: {
                stores: uniqueOptions(filterSessions.map((item) => item.store)),
                scripts: uniqueOptions(filterSessions.map((item) => item.script)),
                hosts: uniqueOptions(filterSessions.map((item) => item.host)),
                paymentMethods: [...new Set(filterPlayers.map((item) => item.paymentMethod).filter((item) => Boolean(item)))].sort(),
                activities: [...new Set(filterPlayers.map((item) => item.activity).filter((item) => Boolean(item)))].sort((a, b) => a.localeCompare(b, "zh-CN")),
            },
            pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
        };
    }
    async exportWorkbook(user, query) {
        const data = await this.analytics(user, query);
        const workbook = new exceljs_1.default.Workbook();
        workbook.creator = "绿洲门店管理";
        const summary = workbook.addWorksheet("经营汇总");
        summary.addRows([
            ["指标", "数值"], ["营业额（元）", data.summary.revenueCents / 100], ["车次", data.summary.sessionCount],
            ["玩家人次", data.summary.playerCount], ["单车均收（元）", data.summary.averageRevenueCents / 100],
            ["美团过票数", data.summary.meituanTicketCount],
            ["退款（元）", data.summary.refundCents / 100], ["推广费用（元）", data.summary.promotionCostCents / 100],
            ["评价数", data.summary.reviewCount], ["好评数", data.summary.goodReviewCount],
        ]);
        const addBreakdown = (name, rows) => {
            const sheet = workbook.addWorksheet(name);
            sheet.addRow([name.replace("维度", ""), "车次", "玩家人次", "营业额（元）"]);
            rows.forEach((row) => sheet.addRow([row.name, row.sessions, row.players, row.revenueCents / 100]));
            sheet.columns = [{ width: 24 }, { width: 12 }, { width: 14 }, { width: 16 }];
            sheet.getRow(1).font = { bold: true };
        };
        addBreakdown("门店维度", data.byStore);
        addBreakdown("剧本维度", data.byScript);
        addBreakdown("DM维度", data.byHost);
        addBreakdown("日期维度", data.byDay);
        const paymentSheet = workbook.addWorksheet("支付渠道");
        paymentSheet.addRow(["支付方式", "人数/票数", "净实收（元）"]);
        data.paymentChannels.forEach((item) => paymentSheet.addRow([item.method, item.count, item.amountCents / 100]));
        const reportSheet = workbook.addWorksheet("经营日报");
        reportSheet.addRow(["日期", "门店", "优质好评", "符合要求好评", "客户端好评", "好评合计", "用电", "推广费（元）", "推广线索", "退款笔数", "退款（元）", "备注"]);
        data.dailyReports.forEach((item) => reportSheet.addRow([
            this.chinaDateKey(item.reportDate), item.store.name, item.premiumReviewCount, item.qualifiedReviewCount, item.clientReviewCount, item.goodReviewCount,
            item.electricityUnits, item.promotionCostCents / 100, item.promotionLeads, item.refundCount, item.refundCents / 100, item.notes ?? "",
        ]));
        for (const sheet of workbook.worksheets) {
            sheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
            sheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E6B55" } };
            sheet.views = [{ state: "frozen", ySplit: 1 }];
        }
        const output = await workbook.xlsx.writeBuffer();
        return Buffer.from(output);
    }
    async validateAssignee(storeId, assigneeId) {
        if (!assigneeId)
            return;
        const assignee = await this.prisma.user.findFirst({ where: { id: assigneeId, storeId, active: true } });
        if (!assignee)
            throw new common_1.BadRequestException("负责人不属于所选门店或已停用");
    }
    audit(user, action, entityType, entityId, payload) {
        return this.prisma.auditLog.create({
            data: { userId: user.id, action, entityType, entityId, payload: payload ? JSON.stringify(payload) : undefined },
        });
    }
};
exports.BusinessService = BusinessService;
exports.BusinessService = BusinessService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], BusinessService);
//# sourceMappingURL=business.service.js.map