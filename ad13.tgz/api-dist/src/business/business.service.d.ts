import type { Prisma } from "@prisma/client";
import ExcelJS from "exceljs";
import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
interface AnalyticsQuery {
    storeId?: string;
    from?: string;
    to?: string;
}
interface RevenueDetailsQuery extends AnalyticsQuery {
    paymentMethod?: string;
    scriptId?: string;
    hostId?: string;
    activity?: string;
    refundStatus?: string;
    keyword?: string;
    page?: string | number;
    pageSize?: string | number;
}
interface ChecklistItem {
    label: string;
    checked: boolean;
    note?: string;
    imageUrl?: string;
}
export declare class BusinessService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private scope;
    private requiredStore;
    private dateOnly;
    private range;
    private chinaDateKey;
    targets(user: UserSession, storeId?: string): Promise<{
        actualRevenueCents: number;
        actualSessionCount: number;
        actualPlayerCount: number;
        revenueProgress: number;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        id: string;
        type: string;
        periodStart: Date;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        electricityBudgetCents: number;
        promotionBudgetCents: number;
        smartPlacementBudgetCents: number;
        goodReviewTarget: number;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
    }[]>;
    goalRules(user: UserSession, storeId?: string): never[] | Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        dayType: string;
    })[]>;
    saveGoalRule(user: UserSession, data: {
        storeId: string;
        dayType: string;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        active?: boolean;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        dayType: string;
    }>;
    saveTarget(user: UserSession, data: {
        storeId: string;
        type: string;
        periodStart: string;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        electricityBudgetCents?: number;
        promotionBudgetCents?: number;
        smartPlacementBudgetCents?: number;
        goodReviewTarget?: number;
        note?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        type: string;
        periodStart: Date;
        revenueTargetCents: number;
        sessionTarget: number;
        playerTarget: number;
        electricityBudgetCents: number;
        promotionBudgetCents: number;
        smartPlacementBudgetCents: number;
        goodReviewTarget: number;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
    }>;
    dailyReports(user: UserSession, storeId?: string): never[] | Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        notes: string | null;
        reportDate: Date;
        reviewCount: number;
        goodReviewCount: number;
        premiumReviewCount: number;
        qualifiedReviewCount: number;
        clientReviewCount: number;
        csQualityReviewCount: number;
        kdbReviewCount: number;
        kdbPremiumCount: number;
        clientPremiumCount: number;
        meituanTicketCount: number;
        scanTicketCount: number;
        electricityCostCents: number;
        electricityUnits: number;
        promotionCostCents: number;
        smartPlacementCostCents: number;
        promotionLeads: number;
        refundCount: number;
        refundCents: number;
    })[]>;
    saveDailyReport(user: UserSession, data: {
        storeId: string;
        reportDate: string;
        reviewCount: number;
        goodReviewCount: number;
        electricityUnits?: number;
        premiumReviewCount?: number;
        qualifiedReviewCount?: number;
        clientReviewCount?: number;
        csQualityReviewCount?: number;
        kdbReviewCount?: number;
        kdbPremiumCount?: number;
        clientPremiumCount?: number;
        meituanTicketCount?: number;
        scanTicketCount?: number;
        electricityCostCents?: number;
        promotionCostCents?: number;
        smartPlacementCostCents?: number;
        notes?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        notes: string | null;
        reportDate: Date;
        reviewCount: number;
        goodReviewCount: number;
        premiumReviewCount: number;
        qualifiedReviewCount: number;
        clientReviewCount: number;
        csQualityReviewCount: number;
        kdbReviewCount: number;
        kdbPremiumCount: number;
        clientPremiumCount: number;
        meituanTicketCount: number;
        scanTicketCount: number;
        electricityCostCents: number;
        electricityUnits: number;
        promotionCostCents: number;
        smartPlacementCostCents: number;
        promotionLeads: number;
        refundCount: number;
        refundCents: number;
    }>;
    closeChecklists(user: UserSession, storeId?: string): Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        checklistDate: Date;
        items: string;
        submittedById: string;
        submittedAt: Date | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
    })[]>;
    saveCloseChecklist(user: UserSession, data: {
        storeId: string;
        checklistDate: string;
        items: ChecklistItem[];
        note?: string;
        submit?: boolean;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        checklistDate: Date;
        items: string;
        submittedById: string;
        submittedAt: Date | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
    }>;
    reviewCloseChecklist(user: UserSession, id: string, action: string, comment?: string): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        checklistDate: Date;
        items: string;
        submittedById: string;
        submittedAt: Date | null;
        reviewStatus: string;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
    }>;
    tasks(user: UserSession, query: {
        storeId?: string;
        status?: string;
    }): never[] | Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
        submissions: ({
            submittedBy: {
                id: string;
                name: string;
            };
            reviewedBy: {
                id: string;
                name: string;
            } | null;
            evidences: {
                id: string;
                note: string | null;
                createdAt: Date;
                imageUrl: string;
                label: string;
                submissionId: string;
            }[];
        } & {
            id: string;
            note: string | null;
            createdAt: Date;
            status: string;
            submittedById: string;
            submittedAt: Date;
            reviewComment: string | null;
            reviewedById: string | null;
            reviewedAt: Date | null;
            completedAt: Date | null;
            taskId: string;
        })[];
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        assigneeId: string | null;
        completedAt: Date | null;
    })[]>;
    createTask(user: UserSession, data: {
        storeId: string;
        title: string;
        description?: string;
        priority?: string;
        dueAt?: string;
        penaltyAmountCents?: number;
        assigneeId?: string;
        taskType?: string;
        evidenceRequired?: boolean;
        evidenceLabels?: string[];
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
        submissions: {
            id: string;
            note: string | null;
            createdAt: Date;
            status: string;
            submittedById: string;
            submittedAt: Date;
            reviewComment: string | null;
            reviewedById: string | null;
            reviewedAt: Date | null;
            completedAt: Date | null;
            taskId: string;
        }[];
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        assigneeId: string | null;
        completedAt: Date | null;
    }>;
    updateTask(user: UserSession, id: string, data: {
        title?: string;
        description?: string;
        priority?: string;
        status?: string;
        dueAt?: string;
        penaltyAmountCents?: number;
        assigneeId?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        assignee: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        title: string;
        description: string | null;
        priority: string;
        dueAt: Date | null;
        sourceType: string | null;
        sourceId: string | null;
        taskType: string;
        evidenceLabels: string;
        evidenceRequired: boolean;
        fineAmountCents: number | null;
        penaltyAmountCents: number;
        assigneeId: string | null;
        completedAt: Date | null;
    }>;
    submitTask(user: UserSession, taskId: string, data: {
        note?: string;
        completedAt?: string;
        evidences: Array<{
            label: string;
            imageUrl: string;
            note?: string;
        }>;
    }): Promise<{
        submittedBy: {
            id: string;
            name: string;
        };
        evidences: {
            id: string;
            note: string | null;
            createdAt: Date;
            imageUrl: string;
            label: string;
            submissionId: string;
        }[];
    } & {
        id: string;
        note: string | null;
        createdAt: Date;
        status: string;
        submittedById: string;
        submittedAt: Date;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        completedAt: Date | null;
        taskId: string;
    }>;
    reviewTaskSubmission(user: UserSession, taskId: string, submissionId: string, action: string, comment?: string): Promise<{
        submittedBy: {
            id: string;
            name: string;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        evidences: {
            id: string;
            note: string | null;
            createdAt: Date;
            imageUrl: string;
            label: string;
            submissionId: string;
        }[];
    } & {
        id: string;
        note: string | null;
        createdAt: Date;
        status: string;
        submittedById: string;
        submittedAt: Date;
        reviewComment: string | null;
        reviewedById: string | null;
        reviewedAt: Date | null;
        completedAt: Date | null;
        taskId: string;
    }>;
    periodicReports(user: UserSession, storeId?: string): never[] | Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        type: string;
        periodStart: Date;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        notes: string | null;
        submittedAt: Date;
        metrics: string;
    })[]>;
    savePeriodicReport(user: UserSession, data: {
        storeId: string;
        type: string;
        periodStart: string;
        metrics: Record<string, unknown>;
        notes?: string;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        type: string;
        periodStart: Date;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        notes: string | null;
        submittedAt: Date;
        metrics: string;
    }>;
    reportReminders(user: UserSession, storeId?: string): Promise<{
        storeId: string;
        storeName: string;
        type: string;
        periodStart: Date;
        label: string;
    }[]>;
    overview(user: UserSession, storeId?: string): Promise<{
        openTasks: number;
        pendingSessions: number;
        pendingReimbursements: number;
        missingDailyReports: number;
        missingCloseChecks: number;
        month: string;
        storeMetrics: {
            storeId: string;
            storeName: string;
            revenueCents: number;
            memberCount: number;
            sessionCount: number;
            operationStats: {
                cardIssueCount: number;
                cardIssueAmountCents: number;
                designatedSessionCount: number;
                cityLimitedSessionCount: number;
                cityLimitedByTheme: {
                    theme: string;
                    themeLabel: string;
                    sessionCount: number;
                }[];
            };
            revenueProgress: number;
            metrics: {
                electricity: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
                promotion: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
                smartPlacement: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
                goodReviews: {
                    budget: number;
                    expected: number;
                    actual: number;
                    variance: number;
                    status: string;
                };
            };
        }[];
    }>;
    analytics(user: UserSession, query: AnalyticsQuery): Promise<{
        range: {
            from: string;
            to: string;
        };
        summary: {
            revenueCents: number;
            sessionCount: number;
            playerCount: number;
            averageRevenueCents: number;
            refundCents: number;
            promotionCostCents: number;
            reviewCount: number;
            goodReviewCount: number;
            meituanTicketCount: number;
            electricityCostCents: number;
            smartPlacementCostCents: number;
            refundCount: number;
            cardIssueCount: number;
            cardIssueAmountCents: number;
            designatedSessionCount: number;
            cityLimitedSessionCount: number;
        };
        byStore: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byScript: {
            weightedSessions: number;
            category: string;
            sessionFactor: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
        }[];
        byHost: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byAssistant: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byNpc: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        byDay: ({
            key: string;
            name: string;
        } & {
            sessions: number;
            players: number;
            revenueCents: number;
        })[];
        trend: {
            meituanTicketCount: number;
            refundCount: number;
            refundCents: number;
            reviewCount: number;
            goodReviewCount: number;
            refundRate: number;
            goodReviewRate: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
        }[];
        weeklyTrend: {
            refundRate: number;
            goodReviewRate: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
            meituanTicketCount: number;
            refundCount: number;
            refundCents: number;
            reviewCount: number;
            goodReviewCount: number;
        }[];
        monthlyTrend: {
            refundRate: number;
            goodReviewRate: number;
            key: string;
            name: string;
            sessions: number;
            players: number;
            revenueCents: number;
            meituanTicketCount: number;
            refundCount: number;
            refundCents: number;
            reviewCount: number;
            goodReviewCount: number;
        }[];
        paymentChannels: {
            method: string;
            count: number;
            amountCents: number;
        }[];
        dailyReports: ({
            store: {
                id: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                code: string;
                city: string;
                address: string | null;
                latitude: number | null;
                longitude: number | null;
                attendanceRadiusMeters: number;
                attendanceMaxAccuracyMeters: number;
                attendanceLocationUpdatedAt: Date | null;
            };
        } & {
            id: string;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            notes: string | null;
            reportDate: Date;
            reviewCount: number;
            goodReviewCount: number;
            premiumReviewCount: number;
            qualifiedReviewCount: number;
            clientReviewCount: number;
            csQualityReviewCount: number;
            kdbReviewCount: number;
            kdbPremiumCount: number;
            clientPremiumCount: number;
            meituanTicketCount: number;
            scanTicketCount: number;
            electricityCostCents: number;
            electricityUnits: number;
            promotionCostCents: number;
            smartPlacementCostCents: number;
            promotionLeads: number;
            refundCount: number;
            refundCents: number;
        })[];
        byCardType: {
            cardType: string;
            cardTypeLabel: string;
            count: number;
            amountCents: number;
        }[];
        byCityLimitedTheme: {
            theme: string;
            themeLabel: string;
            sessionCount: number;
            revenueCents: number;
        }[];
    }>;
    revenueDetails(user: UserSession, query: RevenueDetailsQuery): Promise<{
        range: {
            from: string;
            to: string;
        };
        summary: {
            recordCount: number;
            sessionCount: number;
            originalAmountCents: number;
            amountCents: number;
            discountCents: number;
            refundCents: number;
            netAmountCents: number;
        };
        items: {
            id: string;
            playerName: string;
            phone: string | null;
            playerType: string;
            playerStatus: string;
            paymentMethod: string | null;
            activity: string | null;
            remark: string | null;
            amountCents: number;
            discountCents: number;
            refundedCents: number;
            netAmountCents: number;
            originalAmountCents: number;
            member: {
                id: string;
                name: string;
                tier: string;
            } | null;
            session: {
                id: string;
                code: string;
                state: string;
                startAt: Date;
                store: {
                    id: string;
                    name: string;
                };
                script: {
                    id: string;
                    name: string;
                    category: string;
                };
                host: {
                    id: string;
                    name: string;
                };
            };
        }[];
        filters: {
            stores: {
                id: string;
                name: string;
            }[];
            scripts: {
                id: string;
                name: string;
            }[];
            hosts: {
                id: string;
                name: string;
            }[];
            paymentMethods: string[];
            activities: string[];
        };
        pagination: {
            page: number;
            pageSize: number;
            total: number;
            totalPages: number;
        };
    }>;
    exportWorkbook(user: UserSession, query: AnalyticsQuery): Promise<Buffer<ExcelJS.Buffer>>;
    private validateAssignee;
    private audit;
}
export {};
