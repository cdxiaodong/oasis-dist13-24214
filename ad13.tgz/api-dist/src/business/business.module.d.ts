export declare class BusinessModule {
}
