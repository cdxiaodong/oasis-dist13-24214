"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BusinessController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const business_service_1 = require("./business.service");
class TargetDto {
    storeId;
    type;
    periodStart;
    revenueTargetCents;
    sessionTarget;
    playerTarget;
    electricityBudgetCents;
    promotionBudgetCents;
    smartPlacementBudgetCents;
    goodReviewTarget;
    note;
}
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择门店" }),
    __metadata("design:type", String)
], TargetDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["MONTHLY"], { message: "目标类型不正确" }),
    __metadata("design:type", String)
], TargetDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)({}, { message: "请选择月份" }),
    __metadata("design:type", String)
], TargetDto.prototype, "periodStart", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "营业额目标格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "目标不能为负" }),
    __metadata("design:type", Number)
], TargetDto.prototype, "revenueTargetCents", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "车次目标格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "目标不能为负" }),
    __metadata("design:type", Number)
], TargetDto.prototype, "sessionTarget", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], TargetDto.prototype, "playerTarget", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], TargetDto.prototype, "electricityBudgetCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], TargetDto.prototype, "promotionBudgetCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], TargetDto.prototype, "smartPlacementBudgetCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], TargetDto.prototype, "goodReviewTarget", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TargetDto.prototype, "note", void 0);
class DailyReportDto {
    storeId;
    reportDate;
    reviewCount;
    goodReviewCount;
    kdbReviewCount;
    kdbPremiumCount;
    clientPremiumCount;
    meituanTicketCount;
    scanTicketCount;
    premiumReviewCount;
    qualifiedReviewCount;
    clientReviewCount;
    csQualityReviewCount;
    electricityCostCents;
    electricityUnits;
    promotionCostCents;
    smartPlacementCostCents;
    notes;
}
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择门店" }),
    __metadata("design:type", String)
], DailyReportDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)({}, { message: "请选择日期" }),
    __metadata("design:type", String)
], DailyReportDto.prototype, "reportDate", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "好评合计格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "好评数不能为负" }),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "reviewCount", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "好评合计格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "好评数不能为负" }),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "goodReviewCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "kdbReviewCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "kdbPremiumCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "clientPremiumCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "meituanTicketCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "scanTicketCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "premiumReviewCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "qualifiedReviewCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "clientReviewCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "csQualityReviewCount", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "electricityCostCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "electricityUnits", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "promotionCostCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], DailyReportDto.prototype, "smartPlacementCostCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DailyReportDto.prototype, "notes", void 0);
class ChecklistItemDto {
    label;
    checked;
    note;
    imageUrl;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ChecklistItemDto.prototype, "label", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], ChecklistItemDto.prototype, "checked", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ChecklistItemDto.prototype, "note", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ChecklistItemDto.prototype, "imageUrl", void 0);
class CloseChecklistActionDto {
    action;
    comment;
}
__decorate([
    (0, class_validator_1.IsIn)(["APPROVE", "REJECT"]),
    __metadata("design:type", String)
], CloseChecklistActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CloseChecklistActionDto.prototype, "comment", void 0);
class CloseChecklistDto {
    storeId;
    checklistDate;
    items;
    note;
    submit;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CloseChecklistDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)({ strict: true }),
    __metadata("design:type", String)
], CloseChecklistDto.prototype, "checklistDate", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ChecklistItemDto),
    __metadata("design:type", Array)
], CloseChecklistDto.prototype, "items", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CloseChecklistDto.prototype, "note", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CloseChecklistDto.prototype, "submit", void 0);
class CreateTaskDto {
    storeId;
    title;
    description;
    priority;
    dueAt;
    penaltyAmountCents;
    assigneeId;
    taskType;
    evidenceRequired;
    evidenceLabels;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["LOW", "MEDIUM", "HIGH", "URGENT"]),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "priority", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "dueAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateTaskDto.prototype, "penaltyAmountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "assigneeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["GENERAL", "INSPECTION", "CLEANING", "MATERIAL", "CLOSING"]),
    __metadata("design:type", String)
], CreateTaskDto.prototype, "taskType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateTaskDto.prototype, "evidenceRequired", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateTaskDto.prototype, "evidenceLabels", void 0);
class TaskEvidenceItemDto {
    label;
    imageUrl;
    note;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TaskEvidenceItemDto.prototype, "label", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TaskEvidenceItemDto.prototype, "imageUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TaskEvidenceItemDto.prototype, "note", void 0);
class TaskSubmissionDto {
    note;
    completedAt;
    evidences;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TaskSubmissionDto.prototype, "note", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], TaskSubmissionDto.prototype, "completedAt", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => TaskEvidenceItemDto),
    __metadata("design:type", Array)
], TaskSubmissionDto.prototype, "evidences", void 0);
class SubmissionActionDto {
    action;
    comment;
}
__decorate([
    (0, class_validator_1.IsIn)(["APPROVE", "REJECT"]),
    __metadata("design:type", String)
], SubmissionActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], SubmissionActionDto.prototype, "comment", void 0);
class GoalRuleDto {
    storeId;
    dayType;
    revenueTargetCents;
    sessionTarget;
    playerTarget;
    active;
    note;
}
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择门店" }),
    __metadata("design:type", String)
], GoalRuleDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["MON_THU", "FRIDAY", "SATURDAY", "SUNDAY"], { message: "日期类型不正确" }),
    __metadata("design:type", String)
], GoalRuleDto.prototype, "dayType", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "营业额目标格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "目标不能为负" }),
    __metadata("design:type", Number)
], GoalRuleDto.prototype, "revenueTargetCents", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "车次目标格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "目标不能为负" }),
    __metadata("design:type", Number)
], GoalRuleDto.prototype, "sessionTarget", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], GoalRuleDto.prototype, "playerTarget", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], GoalRuleDto.prototype, "active", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], GoalRuleDto.prototype, "note", void 0);
class UpdateTaskDto {
    title;
    description;
    priority;
    status;
    dueAt;
    penaltyAmountCents;
    assigneeId;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateTaskDto.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateTaskDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["LOW", "MEDIUM", "HIGH", "URGENT"]),
    __metadata("design:type", String)
], UpdateTaskDto.prototype, "priority", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["OPEN", "IN_PROGRESS", "DONE", "CANCELLED"]),
    __metadata("design:type", String)
], UpdateTaskDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], UpdateTaskDto.prototype, "dueAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], UpdateTaskDto.prototype, "penaltyAmountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateTaskDto.prototype, "assigneeId", void 0);
let BusinessController = class BusinessController {
    business;
    constructor(business) {
        this.business = business;
    }
    overview(user, storeId) {
        return this.business.overview(user, storeId);
    }
    targets(user, storeId) {
        return this.business.targets(user, storeId);
    }
    goalRules(user, storeId) { return this.business.goalRules(user, storeId); }
    saveGoalRule(user, dto) { return this.business.saveGoalRule(user, dto); }
    saveTarget(user, dto) {
        return this.business.saveTarget(user, dto);
    }
    reports(user, storeId) {
        return this.business.dailyReports(user, storeId);
    }
    saveReport(user, dto) {
        return this.business.saveDailyReport(user, dto);
    }
    closeChecks(user, storeId) {
        return this.business.closeChecklists(user, storeId);
    }
    saveCloseCheck(user, dto) {
        return this.business.saveCloseChecklist(user, dto);
    }
    reviewCloseCheck(user, id, dto) {
        return this.business.reviewCloseChecklist(user, id, dto.action, dto.comment);
    }
    tasks(user, storeId, status) {
        return this.business.tasks(user, { storeId, status });
    }
    createTask(user, dto) {
        return this.business.createTask(user, dto);
    }
    updateTask(user, id, dto) {
        return this.business.updateTask(user, id, dto);
    }
    updateTaskFromMiniProgram(user, id, dto) {
        return this.business.updateTask(user, id, dto);
    }
    submitTask(user, id, dto) {
        return this.business.submitTask(user, id, dto);
    }
    reviewTask(user, id, submissionId, dto) {
        return this.business.reviewTaskSubmission(user, id, submissionId, dto.action, dto.comment);
    }
    analytics(user, storeId, from, to) {
        return this.business.analytics(user, { storeId, from, to });
    }
    revenueDetails(user, storeId, from, to, paymentMethod, scriptId, hostId, activity, refundStatus, keyword, page, pageSize) {
        return this.business.revenueDetails(user, { storeId, from, to, paymentMethod, scriptId, hostId, activity, refundStatus, keyword, page, pageSize });
    }
    async export(user, storeId, from, to) {
        return new common_1.StreamableFile(await this.business.exportWorkbook(user, { storeId, from, to }));
    }
};
exports.BusinessController = BusinessController;
__decorate([
    (0, common_1.Get)("overview"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "overview", null);
__decorate([
    (0, common_1.Get)("targets"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "targets", null);
__decorate([
    (0, common_1.Get)("goal-rules"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "goalRules", null);
__decorate([
    (0, common_1.Post)("goal-rules"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, GoalRuleDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "saveGoalRule", null);
__decorate([
    (0, common_1.Post)("targets"),
    (0, swagger_1.ApiOperation)({ summary: "设置日/月经营目标" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, TargetDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "saveTarget", null);
__decorate([
    (0, common_1.Get)("daily-reports"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "reports", null);
__decorate([
    (0, common_1.Post)("daily-reports"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, DailyReportDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "saveReport", null);
__decorate([
    (0, common_1.Get)("close-checklists"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "closeChecks", null);
__decorate([
    (0, common_1.Post)("close-checklists"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CloseChecklistDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "saveCloseCheck", null);
__decorate([
    (0, common_1.Post)("close-checklists/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, CloseChecklistActionDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "reviewCloseCheck", null);
__decorate([
    (0, common_1.Get)("tasks"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("status")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "tasks", null);
__decorate([
    (0, common_1.Post)("tasks"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateTaskDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "createTask", null);
__decorate([
    (0, common_1.Patch)("tasks/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateTaskDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "updateTask", null);
__decorate([
    (0, common_1.Post)("tasks/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateTaskDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "updateTaskFromMiniProgram", null);
__decorate([
    (0, common_1.Post)("tasks/:id/submissions"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, TaskSubmissionDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "submitTask", null);
__decorate([
    (0, common_1.Post)("tasks/:id/submissions/:submissionId/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Param)("submissionId")),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, SubmissionActionDto]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "reviewTask", null);
__decorate([
    (0, common_1.Get)("analytics"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("from")),
    __param(3, (0, common_1.Query)("to")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "analytics", null);
__decorate([
    (0, common_1.Get)("revenue-details"),
    (0, swagger_1.ApiOperation)({ summary: "查询逐笔营业明细" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("from")),
    __param(3, (0, common_1.Query)("to")),
    __param(4, (0, common_1.Query)("paymentMethod")),
    __param(5, (0, common_1.Query)("scriptId")),
    __param(6, (0, common_1.Query)("hostId")),
    __param(7, (0, common_1.Query)("activity")),
    __param(8, (0, common_1.Query)("refundStatus")),
    __param(9, (0, common_1.Query)("keyword")),
    __param(10, (0, common_1.Query)("page")),
    __param(11, (0, common_1.Query)("pageSize")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], BusinessController.prototype, "revenueDetails", null);
__decorate([
    (0, common_1.Get)("export.xlsx"),
    (0, common_1.Header)("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    (0, common_1.Header)("Content-Disposition", 'attachment; filename="oasis-business-report.xlsx"'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("from")),
    __param(3, (0, common_1.Query)("to")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String]),
    __metadata("design:returntype", Promise)
], BusinessController.prototype, "export", null);
exports.BusinessController = BusinessController = __decorate([
    (0, swagger_1.ApiTags)("经营中心"),
    (0, common_1.Controller)("business"),
    __metadata("design:paramtypes", [business_service_1.BusinessService])
], BusinessController);
//# sourceMappingURL=business.controller.js.map