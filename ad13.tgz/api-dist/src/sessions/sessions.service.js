"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionsService = void 0;
const common_1 = require("@nestjs/common");
const crypto_1 = require("crypto");
const business_rules_1 = require("../common/business-rules");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
const assets_1 = require("../common/assets");
const NEXT_STATE = {
    CONFIRM: "PENDING_CONFIRMATION",
    READY: "READY",
    START: "IN_PROGRESS",
    SETTLE: "PENDING_MATERIALS",
    SUBMIT: "PENDING_APPROVAL",
    APPROVE: "COMPLETED",
    REJECT: "REJECTED",
    CANCEL: "CANCELLED",
    REOPEN: "PENDING_MATERIALS",
};
const ALLOWED_FROM = {
    CONFIRM: ["DRAFT"],
    READY: ["PENDING_CONFIRMATION", "DRAFT"],
    START: ["READY", "PENDING_CONFIRMATION"],
    SETTLE: ["IN_PROGRESS", "PENDING_PAYMENT"],
    SUBMIT: ["PENDING_MATERIALS", "REJECTED"],
    APPROVE: ["PENDING_APPROVAL"],
    REJECT: ["PENDING_APPROVAL"],
    CANCEL: ["DRAFT", "PENDING_CONFIRMATION", "READY"],
    REOPEN: ["REJECTED"],
};
let SessionsService = class SessionsService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    include = {
        store: true,
        room: true,
        script: true,
        host: { select: { id: true, name: true, role: true } },
        assistant: { select: { id: true, name: true, role: true } },
        npc: { select: { id: true, name: true, role: true } },
        players: {
            include: { member: { select: { id: true, name: true, phone: true, balanceCents: true, tier: true } }, adjustments: { include: { operator: { select: { id: true, name: true } } }, orderBy: { createdAt: "desc" } } },
            orderBy: { createdAt: "asc" },
        },
        materials: { orderBy: { createdAt: "asc" } },
        staffAssignments: {
            include: { user: { select: { id: true, name: true, role: true } } },
            orderBy: { createdAt: "asc" },
        },
        designations: {
            include: { staff: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } } },
            orderBy: { createdAt: "asc" },
        },
    };
    scope(user, storeId) {
        if (user.role === "CUSTOMER_SERVICE")
            throw new common_1.ForbiddenException("客服账号无权访问车次明细");
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return storeId;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (storeId && storeId !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    participantWhere(user) {
        if (["HEADQUARTERS", "FINANCE", "MANAGER"].includes(user.role))
            return {};
        if (["DM", "ASSISTANT", "NPC", "STAFF"].includes(user.role)) {
            return { OR: [{ hostId: user.id }, { staffAssignments: { some: { userId: user.id } } }] };
        }
        throw new common_1.ForbiddenException("当前岗位无权访问车次数据");
    }
    assertCanEditSession(user, session) {
        if (["HEADQUARTERS", "MANAGER"].includes(user.role))
            return;
        if (["DM", "ASSISTANT", "NPC", "STAFF"].includes(user.role) && session.hostId === user.id)
            return;
        throw new common_1.ForbiddenException("只有本车主DM、店长或总部可以修改车次");
    }
    minimumPlayers(script) {
        return script.minPlayerCount && script.minPlayerCount > 0 ? script.minPlayerCount : script.playerCount;
    }
    protectedImageList(values, label) {
        return JSON.stringify(values.map((value) => (0, assets_1.protectedImageUrl)(value, label)));
    }
    sanitizeSession(user, session) {
        if (["HEADQUARTERS", "FINANCE", "MANAGER"].includes(user.role) || session.hostId === user.id)
            return session;
        return {
            ...session,
            players: session.players.map((player) => ({ id: player.id, name: player.name, type: player.type, status: player.status, amountCents: 0, discountCents: 0, refundedCents: 0, adjustments: [] })),
            staffAssignments: session.staffAssignments.map((item) => item.userId === user.id ? item : { ...item, feeCents: 0, feeTier: undefined, note: undefined }),
        };
    }
    async list(user, query) {
        const storeId = this.scope(user, query.storeId);
        const sessions = await this.prisma.gameSession.findMany({
            where: { ...(storeId ? { storeId } : {}), ...this.participantWhere(user), ...(query.state ? { state: query.state } : {}) },
            include: this.include,
            orderBy: { startAt: "desc" },
        });
        return sessions.map((session) => this.sanitizeSession(user, session));
    }
    async one(user, id) {
        if (user.role === "CUSTOMER_SERVICE")
            throw new common_1.ForbiddenException("客服账号无权访问车次明细");
        let session = await this.prisma.gameSession.findUnique({ where: { id }, include: this.include });
        if (!session)
            throw new common_1.NotFoundException("车次不存在");
        if (!session.joinToken) {
            session = await this.prisma.gameSession.update({
                where: { id: session.id },
                data: { joinToken: (0, crypto_1.randomBytes)(12).toString("base64url") },
                include: this.include,
            });
        }
        if (!(0, user_session_1.canAccessStore)(user, session.storeId))
            throw new common_1.ForbiddenException("无权查看该车次");
        if (!["HEADQUARTERS", "FINANCE", "MANAGER"].includes(user.role) && session.hostId !== user.id && !session.staffAssignments.some((item) => item.userId === user.id))
            throw new common_1.ForbiddenException("无权查看其他人员车次");
        return this.sanitizeSession(user, session);
    }
    async create(user, data) {
        if (user.role === "FINANCE")
            throw new common_1.ForbiddenException("财务账号不能新建车次");
        if (!["HEADQUARTERS", "MANAGER"].includes(user.role) && data.hostId !== user.id) {
            throw new common_1.ForbiddenException("一线员工只能以本人作为主DM新建车次");
        }
        const storeId = this.scope(user, data.storeId);
        if (!storeId)
            throw new common_1.BadRequestException("请选择门店");
        const startAt = new Date(data.startAt), expectedEndAt = new Date(data.expectedEndAt);
        if (Number.isNaN(startAt.getTime()) || Number.isNaN(expectedEndAt.getTime()) || startAt >= expectedEndAt)
            throw new common_1.BadRequestException("车次开始时间必须早于预计结束时间");
        const chinaNow = new Date(Date.now() + 8 * 60 * 60_000);
        const chinaStart = new Date(startAt.getTime() + 8 * 60 * 60_000);
        const today = Date.UTC(chinaNow.getUTCFullYear(), chinaNow.getUTCMonth(), chinaNow.getUTCDate());
        const sessionDay = Date.UTC(chinaStart.getUTCFullYear(), chinaStart.getUTCMonth(), chinaStart.getUTCDate());
        if (Math.abs(sessionDay - today) > 24 * 60 * 60_000)
            throw new common_1.BadRequestException("车次日期只能选择今天、昨天或明天");
        const assistantDetails = data.assistantAssignments ?? (data.assistantIds ?? []).map((userId) => ({ userId }));
        const npcDetails = data.npcAssignments ?? (data.npcIds ?? []).map((userId) => ({ userId }));
        if (data.assistantId && !assistantDetails.some((item) => item.userId === data.assistantId))
            assistantDetails.push({ userId: data.assistantId });
        if (data.npcId && !npcDetails.some((item) => item.userId === data.npcId))
            npcDetails.push({ userId: data.npcId });
        const assistantIds = [...new Set(assistantDetails.map((item) => item.userId))];
        const npcIds = [...new Set(npcDetails.map((item) => item.userId))];
        const duplicateStaffIds = assistantIds.filter((id) => npcIds.includes(id));
        if (assistantIds.includes(data.hostId) || npcIds.includes(data.hostId))
            throw new common_1.BadRequestException("主DM不能同时担任副D或 NPC");
        if (duplicateStaffIds.length)
            throw new common_1.BadRequestException("同一员工不能在一辆车中同时担任副D和 NPC");
        const participantIds = [...assistantIds, ...npcIds];
        const [room, script, host, participants] = await Promise.all([
            this.prisma.room.findFirst({ where: { id: data.roomId, storeId, active: true } }),
            this.prisma.script.findFirst({ where: { id: data.scriptId, storeId, active: true } }),
            this.prisma.user.findFirst({ where: { id: data.hostId, storeId, active: true } }),
            participantIds.length
                ? this.prisma.user.findMany({ where: { id: { in: participantIds }, storeId, active: true }, select: { id: true, name: true, role: true } })
                : Promise.resolve([]),
        ]);
        if (!room)
            throw new common_1.BadRequestException("房间不属于所选门店或已停用");
        if (!script)
            throw new common_1.BadRequestException("剧本不属于所选门店或已停用");
        if (!host)
            throw new common_1.BadRequestException("主DM不属于所选门店或已停用");
        if (host.role === "FINANCE")
            throw new common_1.BadRequestException("财务不能担任主DM");
        const participantById = new Map(participants.map((item) => [item.id, item]));
        if (assistantIds.some((id) => !participantById.has(id)))
            throw new common_1.BadRequestException("所选副D不属于当前门店或已停用");
        if (npcIds.some((id) => !participantById.has(id)))
            throw new common_1.BadRequestException("所选 NPC 不属于当前门店或已停用");
        if ([...assistantIds, ...npcIds].some((id) => participantById.get(id).role === "FINANCE"))
            throw new common_1.BadRequestException("财务不能参与主持团队");
        const assistantCount = script.assistantCount || (script.needsAssistant ? 1 : 0);
        const npcCount = script.npcCount || (script.needsNpc ? 1 : 0);
        if (assistantIds.length < assistantCount)
            throw new common_1.BadRequestException(`该剧本至少需要 ${assistantCount} 名副D`);
        if (npcIds.length < npcCount)
            throw new common_1.BadRequestException(`该剧本至少需要 ${npcCount} 名 NPC`);
        const staffIds = [data.hostId, ...participantIds];
        const roomConflict = await this.prisma.gameSession.findFirst({
            where: {
                storeId, state: { not: "CANCELLED" }, startAt: { lt: expectedEndAt }, expectedEndAt: { gt: startAt },
                roomId: data.roomId,
            },
            include: { room: true },
        });
        if (roomConflict)
            throw new common_1.BadRequestException(`房间 ${roomConflict.room.name} 在该时段已有车次 ${roomConflict.code}`);
        const conflict = !(data.allowPersonnelOverlap ?? true) ? await this.prisma.gameSession.findFirst({
            where: {
                storeId, state: { not: "CANCELLED" }, startAt: { lt: expectedEndAt }, expectedEndAt: { gt: startAt },
                OR: [
                    { hostId: { in: staffIds } },
                    { assistantId: { in: staffIds } },
                    { npcId: { in: staffIds } },
                    { staffAssignments: { some: { userId: { in: staffIds }, status: { not: "DECLINED" } } } },
                ],
            },
            include: {
                room: true,
                host: { select: { name: true } },
                assistant: { select: { name: true } },
                npc: { select: { name: true } },
                staffAssignments: { where: { status: { not: "DECLINED" } }, include: { user: { select: { name: true } } } },
            },
        }) : null;
        if (conflict) {
            const names = [
                ...[[conflict.hostId, conflict.host], [conflict.assistantId, conflict.assistant], [conflict.npcId, conflict.npc]]
                    .filter(([id, item]) => id && item && staffIds.includes(String(id))).map(([, item]) => item.name),
                ...conflict.staffAssignments.filter((item) => staffIds.includes(item.userId)).map((item) => item.user.name),
            ];
            throw new common_1.BadRequestException(`人员 ${[...new Set(names)].join("、")} 在该时段已有车次 ${conflict.code}；确认属于连续开本后可勾选“允许人员时间重叠”继续`);
        }
        const count = await this.prisma.gameSession.count({ where: { storeId } });
        const store = await this.prisma.store.findFirst({ where: { id: storeId, active: true } });
        if (!store)
            throw new common_1.BadRequestException("所选门店已停用");
        const chinaDate = new Date(startAt.getTime() + 8 * 60 * 60_000);
        const ymd = `${String(chinaDate.getUTCFullYear()).slice(-2)}${String(chinaDate.getUTCMonth() + 1).padStart(2, "0")}${String(chinaDate.getUTCDate()).padStart(2, "0")}`;
        const code = `${store.code}-${ymd}-${String(count + 1).padStart(2, "0")}`;
        const session = await this.prisma.gameSession.create({
            data: {
                code,
                storeId,
                roomId: data.roomId,
                scriptId: data.scriptId,
                hostId: data.hostId,
                assistantId: assistantIds[0] ?? null,
                npcId: npcIds[0] ?? null,
                startAt,
                expectedEndAt,
                notes: data.notes,
                staffAssignments: {
                    create: [
                        ...assistantIds.map((userId) => { const detail = assistantDetails.find((item) => item.userId === userId); return { userId, role: "ASSISTANT", feeTier: detail?.feeTier, feeCents: detail?.feeCents ?? 0, shiftStartAt: startAt, shiftEndAt: expectedEndAt }; }),
                        ...npcIds.map((userId) => { const detail = npcDetails.find((item) => item.userId === userId); return { userId, role: "NPC", feeTier: detail?.feeTier, feeCents: detail?.feeCents ?? 0, shiftStartAt: startAt, shiftEndAt: expectedEndAt }; }),
                    ],
                },
            },
            include: this.include,
        });
        await this.audit(user, "CREATE_SESSION", "GameSession", session.id, { code, assistantIds, npcIds });
        return this.one(user, session.id);
    }
    async update(user, id, data) {
        if (!["MANAGER", "HEADQUARTERS"].includes(user.role)) {
            const isHost = ["DM", "ASSISTANT", "NPC", "STAFF"].includes(user.role) && session.hostId === user.id;
            if (!isHost)
                throw new common_1.ForbiddenException("只有本车主DM、店长或总部可以修改车次");
            if (data.roomId !== undefined || data.scriptId !== undefined || data.hostId !== undefined || data.startAt !== undefined || data.expectedEndAt !== undefined) {
                throw new common_1.ForbiddenException("主DM只能调整本车副D/NPC和备注；改房间、剧本、时间请联系店长");
            }
        }
        const session = await this.one(user, id);
        const startAt = data.startAt ? new Date(data.startAt) : session.startAt;
        const expectedEndAt = data.expectedEndAt ? new Date(data.expectedEndAt) : session.expectedEndAt;
        if (Number.isNaN(startAt.getTime()) || Number.isNaN(expectedEndAt.getTime()) || startAt >= expectedEndAt)
            throw new common_1.BadRequestException("车次开始时间必须早于预计结束时间");
        const roomId = data.roomId ?? session.roomId;
        const scriptId = data.scriptId ?? session.scriptId;
        const hostId = data.hostId ?? session.hostId;
        const existingAssignments = session.staffAssignments.filter((item) => item.status !== "DECLINED");
        const currentAssistantDetails = existingAssignments
            .filter((item) => item.role === "ASSISTANT")
            .map((item) => ({ userId: item.userId, feeTier: item.feeTier || undefined, feeCents: item.feeCents || 0 }));
        const currentNpcDetails = existingAssignments
            .filter((item) => item.role === "NPC")
            .map((item) => ({ userId: item.userId, feeTier: item.feeTier || undefined, feeCents: item.feeCents || 0 }));
        const assistantDetails = data.assistantAssignments ?? currentAssistantDetails;
        const npcDetails = data.npcAssignments ?? currentNpcDetails;
        const assistantIds = [...new Set(assistantDetails.map((item) => item.userId))];
        const npcIds = [...new Set(npcDetails.map((item) => item.userId))];
        const participantIds = [...assistantIds, ...npcIds];
        if (assistantIds.includes(hostId) || npcIds.includes(hostId))
            throw new common_1.BadRequestException("主DM不能同时担任副D或 NPC");
        if (assistantIds.some((assistantId) => npcIds.includes(assistantId)))
            throw new common_1.BadRequestException("同一员工不能在一辆车中同时担任副D和 NPC");
        const [room, script, host, participants, roomConflict, occupiedSeats] = await Promise.all([
            this.prisma.room.findFirst({ where: { id: roomId, storeId: session.storeId, active: true } }),
            this.prisma.script.findFirst({ where: { id: scriptId, storeId: session.storeId, active: true } }),
            this.prisma.user.findFirst({ where: { id: hostId, storeId: session.storeId, active: true } }),
            participantIds.length
                ? this.prisma.user.findMany({ where: { id: { in: participantIds }, storeId: session.storeId, active: true }, select: { id: true, role: true } })
                : Promise.resolve([]),
            this.prisma.gameSession.findFirst({
                where: {
                    id: { not: id },
                    state: { not: "CANCELLED" },
                    startAt: { lt: expectedEndAt },
                    expectedEndAt: { gt: startAt },
                    OR: [
                        { roomId },
                        { hostId },
                        { assistantId: { in: participantIds } },
                        { npcId: { in: participantIds } },
                        { staffAssignments: { some: { userId: { in: participantIds } } } },
                    ],
                },
            }),
            this.prisma.sessionPlayer.count({ where: { sessionId: id, status: "ACTIVE" } }),
        ]);
        if (!room)
            throw new common_1.BadRequestException("房间不属于当前门店或已停用");
        if (!script)
            throw new common_1.BadRequestException("剧本不属于当前门店或已停用");
        if (!host || host.role === "FINANCE")
            throw new common_1.BadRequestException("主DM不属于当前门店或岗位不可用");
        const participantById = new Map(participants.map((item) => [item.id, item]));
        if (participantIds.some((participantId) => !participantById.has(participantId)))
            throw new common_1.BadRequestException("所选副D或NPC不属于当前门店或已停用");
        if (participantIds.some((participantId) => participantById.get(participantId)?.role === "FINANCE"))
            throw new common_1.BadRequestException("财务不能参与主持团队");
        const requiredAssistants = script.assistantCount || (script.needsAssistant ? 1 : 0);
        const requiredNpcs = script.npcCount || (script.needsNpc ? 1 : 0);
        if (assistantIds.length < requiredAssistants)
            throw new common_1.BadRequestException(`该剧本至少需要 ${requiredAssistants} 名副D`);
        if (npcIds.length < requiredNpcs)
            throw new common_1.BadRequestException(`该剧本至少需要 ${requiredNpcs} 名 NPC`);
        if (roomConflict)
            throw new common_1.BadRequestException("所选房间在该时段已有其他车次");
        if (occupiedSeats > script.playerCount)
            throw new common_1.BadRequestException(`当前已有${occupiedSeats}个坑位记录，不能改为${script.playerCount}人本`);
        const statusByKey = new Map(existingAssignments.map((item) => [`${item.role}:${item.userId}`, item]));
        const assignmentCreate = [
            ...assistantIds.map((userId) => {
                const detail = assistantDetails.find((item) => item.userId === userId);
                const existing = statusByKey.get(`ASSISTANT:${userId}`);
                return {
                    sessionId: id, userId, role: "ASSISTANT", status: existing?.status || "PENDING",
                    feeTier: detail?.feeTier, feeCents: detail?.feeCents ?? 0,
                    shiftStartAt: existing?.shiftStartAt || startAt, shiftEndAt: existing?.shiftEndAt || expectedEndAt,
                };
            }),
            ...npcIds.map((userId) => {
                const detail = npcDetails.find((item) => item.userId === userId);
                const existing = statusByKey.get(`NPC:${userId}`);
                return {
                    sessionId: id, userId, role: "NPC", status: existing?.status || "PENDING",
                    feeTier: detail?.feeTier, feeCents: detail?.feeCents ?? 0,
                    shiftStartAt: existing?.shiftStartAt || startAt, shiftEndAt: existing?.shiftEndAt || expectedEndAt,
                };
            }),
        ];
        const updated = await this.prisma.$transaction(async (tx) => {
            await tx.sessionStaffAssignment.deleteMany({ where: { sessionId: id } });
            if (assignmentCreate.length)
                await tx.sessionStaffAssignment.createMany({ data: assignmentCreate });
            return tx.gameSession.update({
                where: { id },
                data: {
                    roomId, scriptId, hostId, startAt, expectedEndAt,
                    notes: data.notes,
                    joinEnabled: data.joinEnabled,
                    assistantId: assistantIds[0] ?? null,
                    npcId: npcIds[0] ?? null,
                },
                include: this.include,
            });
        });
        await this.audit(user, "UPDATE_SUBMITTED_SESSION", "GameSession", id, data);
        return updated;
    }
    async addPlayer(user, sessionId, data) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        if (data.paymentMethod === "MEMBER" && !data.memberId)
            throw new common_1.BadRequestException("会员卡支付必须选择会员");
        const occupiedSeats = await this.prisma.sessionPlayer.count({ where: { sessionId, status: "ACTIVE" } });
        if (occupiedSeats >= session.script.playerCount)
            throw new common_1.BadRequestException(`本车仅有${session.script.playerCount}个坑位，当前已满`);
        const player = await this.prisma.$transaction(async (tx) => {
            const member = data.paymentMethod === "MEMBER" && data.memberId ? await this.paymentMember(tx, data.memberId, session.storeId) : null;
            if (member)
                await this.assertMemberUsageLimit(tx, sessionId, member);
            const { proofUrls, ...playerData } = data;
            if (!playerData.name || !playerData.name.trim())
                playerData.name = member ? member.name : `散客${occupiedSeats + 1}`;
            const uploadedProofs = proofUrls?.length ? proofUrls : data.proofUrl ? [data.proofUrl] : [];
            const created = await tx.sessionPlayer.create({ data: { ...playerData, name: playerData.name, memberId: member?.id ?? null, proofUrl: uploadedProofs.length ? this.protectedImageList(uploadedProofs, "活动证明") : undefined, sessionId }, include: { member: { select: { id: true, name: true, phone: true, balanceCents: true, tier: true } } } });
            if (data.paymentMethod === "MEMBER" && member && (data.amountCents ?? 0) > 0)
                await this.changeMemberBalance(tx, user, member.id, -(data.amountCents ?? 0), "SESSION_CONSUME", `车次 ${session.code} 会员卡扣款`);
            return created;
        });
        await this.audit(user, "ADD_PLAYER", "GameSession", sessionId, { playerId: player.id, type: player.type });
        return player;
    }
    async updatePayment(user, sessionId, playerId, data) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        const player = await this.prisma.sessionPlayer.findFirst({ where: { id: playerId, sessionId } });
        if (!player)
            throw new common_1.NotFoundException("玩家不存在");
        if (data.amountCents < player.refundedCents)
            throw new common_1.BadRequestException("实收金额不能低于已登记退款金额");
        if (data.paymentMethod === "MEMBER" && !data.memberId)
            throw new common_1.BadRequestException("会员卡支付必须选择会员");
        const updated = await this.prisma.$transaction(async (tx) => {
            const nextMember = data.paymentMethod === "MEMBER" && data.memberId ? await this.paymentMember(tx, data.memberId, session.storeId) : null;
            if (nextMember)
                await this.assertMemberUsageLimit(tx, sessionId, nextMember, playerId);
            const oldOutstanding = player.paymentMethod === "MEMBER" && player.memberId ? player.amountCents - player.refundedCents : 0;
            const newOutstanding = data.paymentMethod === "MEMBER" && nextMember ? data.amountCents - player.refundedCents : 0;
            if (player.memberId && player.memberId === nextMember?.id) {
                const balanceDelta = oldOutstanding - newOutstanding;
                if (balanceDelta)
                    await this.changeMemberBalance(tx, user, player.memberId, balanceDelta, "SESSION_PAYMENT_ADJUST", `车次 ${session.code} 扣卡金额调整`);
            }
            else {
                if (player.memberId && oldOutstanding)
                    await this.changeMemberBalance(tx, user, player.memberId, oldOutstanding, "SESSION_PAYMENT_REVERSE", `车次 ${session.code} 原扣卡撤销`);
                if (nextMember && newOutstanding)
                    await this.changeMemberBalance(tx, user, nextMember.id, -newOutstanding, "SESSION_CONSUME", `车次 ${session.code} 会员卡扣款`);
            }
            const { proofUrls, ...playerData } = data;
            const uploadedProofs = proofUrls?.length ? proofUrls : data.proofUrl ? [data.proofUrl] : [];
            return tx.sessionPlayer.update({ where: { id: playerId }, data: { ...playerData, proofUrl: uploadedProofs.length ? this.protectedImageList(uploadedProofs, "活动证明") : null, memberId: nextMember?.id ?? null }, include: { member: { select: { id: true, name: true, phone: true, balanceCents: true, tier: true } } } });
        });
        await this.audit(user, "UPDATE_PAYMENT", "SessionPlayer", playerId, data);
        return updated;
    }
    async updatePlayer(user, sessionId, playerId, data) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        const player = await this.prisma.sessionPlayer.findFirst({ where: { id: playerId, sessionId } });
        if (!player)
            throw new common_1.NotFoundException("玩家不存在");
        if (player.status === "REMOVED")
            throw new common_1.BadRequestException("已移除玩家不能再修改");
        const updated = await this.prisma.sessionPlayer.update({ where: { id: playerId }, data });
        await this.audit(user, "UPDATE_PLAYER", "SessionPlayer", playerId, { before: player, after: updated });
        return updated;
    }
    async removePlayer(user, sessionId, playerId, reason) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        const player = await this.prisma.sessionPlayer.findFirst({ where: { id: playerId, sessionId } });
        if (!player)
            throw new common_1.NotFoundException("玩家不存在");
        if (player.status === "REMOVED")
            throw new common_1.BadRequestException("玩家已被移除");
        const updated = await this.prisma.$transaction(async (tx) => {
            await tx.sessionPlayerAdjustment.create({ data: { playerId, operatorId: user.id, type: "REMOVAL", amountCents: 0, reason } });
            return tx.sessionPlayer.update({ where: { id: playerId }, data: { status: "REMOVED", removedAt: new Date(), removedReason: reason } });
        });
        await this.audit(user, "REMOVE_PLAYER", "SessionPlayer", playerId, { reason });
        return updated;
    }
    async refundPlayer(user, sessionId, playerId, amountCents, reason) {
        if (!["MANAGER", "FINANCE", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只有店长、财务或总部可以登记退款");
        const session = await this.one(user, sessionId);
        const player = await this.prisma.sessionPlayer.findFirst({ where: { id: playerId, sessionId } });
        if (!player)
            throw new common_1.NotFoundException("玩家不存在");
        if (amountCents <= 0)
            throw new common_1.BadRequestException("退款金额必须大于 0");
        if (player.refundedCents + amountCents > player.amountCents)
            throw new common_1.BadRequestException("累计退款不能超过玩家实收");
        const updated = await this.prisma.$transaction(async (tx) => {
            await tx.sessionPlayerAdjustment.create({ data: { playerId, operatorId: user.id, type: "REFUND", amountCents: -amountCents, reason } });
            if (player.paymentMethod === "MEMBER" && player.memberId)
                await this.changeMemberBalance(tx, user, player.memberId, amountCents, "SESSION_REFUND", `车次 ${session.code} 会员卡退款：${reason}`);
            return tx.sessionPlayer.update({ where: { id: playerId }, data: { refundedCents: { increment: amountCents } }, include: { member: { select: { id: true, name: true, phone: true, balanceCents: true } } } });
        });
        await this.audit(user, "REFUND_PLAYER", "SessionPlayer", playerId, { amountCents, reason });
        return updated;
    }
    async respondAssignment(user, sessionId, assignmentId, status, note) {
        await this.one(user, sessionId);
        const assignment = await this.prisma.sessionStaffAssignment.findFirst({ where: { id: assignmentId, sessionId } });
        if (!assignment)
            throw new common_1.NotFoundException("人员邀请不存在");
        if (assignment.status !== "PENDING")
            throw new common_1.BadRequestException("该邀请已经处理");
        if (assignment.userId !== user.id && !["MANAGER", "HEADQUARTERS"].includes(user.role))
            throw new common_1.ForbiddenException("只能处理分配给自己的邀请");
        if (!['ACCEPTED', 'DECLINED'].includes(status))
            throw new common_1.BadRequestException("确认状态不正确");
        const updated = await this.prisma.sessionStaffAssignment.update({
            where: { id: assignmentId }, data: { status, note, respondedAt: new Date() },
            include: { user: { select: { id: true, name: true, role: true } } },
        });
        await this.audit(user, `STAFF_ASSIGNMENT_${status}`, "SessionStaffAssignment", assignmentId, { sessionId, note });
        return updated;
    }
    async addMaterial(user, sessionId, data) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        return this.prisma.sessionMaterial.create({ data: { ...data, imageUrl: (0, assets_1.protectedImageUrl)(data.imageUrl, "车次材料"), sessionId } });
    }
    async transition(user, id, action, note) {
        const session = await this.one(user, id);
        const normalized = action.toUpperCase();
        if (!NEXT_STATE[normalized] || !ALLOWED_FROM[normalized]?.includes(session.state)) {
            throw new common_1.BadRequestException(`车次当前为 ${session.state}，不能执行 ${normalized}`);
        }
        if (["APPROVE", "REJECT", "CANCEL"].includes(normalized) && !["MANAGER", "HEADQUARTERS"].includes(user.role)) {
            throw new common_1.ForbiddenException("只有店长或总部可以审核车次");
        }
        if (normalized === "CANCEL" && !note?.trim())
            throw new common_1.BadRequestException("炸车必须填写取消原因");
        if (!["APPROVE", "REJECT", "CANCEL"].includes(normalized))
            this.assertCanEditSession(user, session);
        if (normalized === "READY") {
            const acceptedAssistantCount = session.staffAssignments.filter((item) => item.status === "ACCEPTED" && item.role === "ASSISTANT").length;
            const acceptedNpcCount = session.staffAssignments.filter((item) => item.status === "ACCEPTED" && item.role === "NPC").length;
            const unresolved = session.staffAssignments.filter((item) => item.status === "PENDING");
            const requiredAssistants = session.script.assistantCount || (session.script.needsAssistant ? 1 : 0);
            const requiredNpcs = session.script.npcCount || (session.script.needsNpc ? 1 : 0);
            if (acceptedAssistantCount < requiredAssistants)
                throw new common_1.BadRequestException(`至少需要 ${requiredAssistants} 名副D接受邀请`);
            if (acceptedNpcCount < requiredNpcs)
                throw new common_1.BadRequestException(`至少需要 ${requiredNpcs} 名 NPC 接受邀请`);
            if (unresolved.length)
                throw new common_1.BadRequestException("仍有人员邀请未接受，不能进入准备完成");
        }
        if (normalized === "SUBMIT") {
            const activePlayers = session.players.filter((item) => item.status === "ACTIVE").length;
            const minimumPlayers = this.minimumPlayers(session.script);
            if (activePlayers < minimumPlayers)
                throw new common_1.BadRequestException(`本车至少需要录入 ${minimumPlayers} 位玩家，当前 ${activePlayers} 位`);
            const designationStatus = session.designationStatus === "UNSET" && session.designations.length ? "DESIGNATED" : session.designationStatus;
            if (designationStatus === "UNSET")
                throw new common_1.BadRequestException("请先确认本车是否为指定车");
            if (designationStatus === "DESIGNATED" && !session.designations.length)
                throw new common_1.BadRequestException("指定车必须选择指定人员并上传凭证");
            const uploaded = new Set(session.materials.filter((item) => item.phase === "END").map((item) => item.label));
            const missing = business_rules_1.REQUIRED_END_MATERIAL_LABELS.filter((label) => !uploaded.has(label));
            if (missing.length)
                throw new common_1.BadRequestException(`缺少结束材料：${missing.join("、")}`);
        }
        const updated = await this.prisma.gameSession.update({
            where: { id },
            data: {
                state: NEXT_STATE[normalized],
                ...(normalized === "CANCEL" ? { notes: [session.notes, `炸车原因：${note.trim()}`].filter(Boolean).join("\n") } : {}),
                ...(normalized === "REJECT" ? { rejectionNote: note || "请补充材料" } : {}),
                ...(normalized === "APPROVE" ? { actualEndAt: new Date(), rejectionNote: null } : {}),
            },
            include: this.include,
        });
        await this.audit(user, `SESSION_${normalized}`, "GameSession", id, { from: session.state, to: updated.state, note });
        return updated;
    }
    async addDesignation(user, sessionId, data) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        const staff = await this.prisma.user.findFirst({ where: { id: data.staffId, storeId: session.storeId, active: true } });
        if (!staff || staff.role === "FINANCE")
            throw new common_1.BadRequestException("指定人员不属于当前门店或岗位不可参与车次");
        const belongsToTeam = session.hostId === data.staffId || session.staffAssignments.some((item) => item.userId === data.staffId);
        if (!belongsToTeam)
            throw new common_1.BadRequestException("指定人员必须属于本车主持团队");
        const proofUrls = data.proofUrls?.length ? data.proofUrls : [data.proofUrl];
        const designation = await this.prisma.$transaction(async (tx) => {
            const created = await tx.sessionDesignation.create({
                data: { sessionId, staffId: data.staffId, staffRole: data.staffRole, proofUrl: this.protectedImageList(proofUrls, "指定车凭证"), note: data.note, createdById: user.id },
                include: { staff: { select: { id: true, name: true, role: true } }, createdBy: { select: { id: true, name: true } } },
            });
            await tx.gameSession.update({ where: { id: sessionId }, data: { designationStatus: "DESIGNATED" } });
            return created;
        });
        await this.audit(user, "CREATE_SESSION_DESIGNATION", "SessionDesignation", designation.id, { sessionId, staffId: data.staffId });
        return designation;
    }
    async setDesignationStatus(user, sessionId, status) {
        const session = await this.one(user, sessionId);
        this.assertCanEditSession(user, session);
        if (status === "NOT_DESIGNATED" && session.designations.length)
            throw new common_1.BadRequestException("本车已有指定记录，不能改为非指定车");
        const updated = await this.prisma.gameSession.update({ where: { id: sessionId }, data: { designationStatus: status }, include: this.include });
        await this.audit(user, "SET_SESSION_DESIGNATION_STATUS", "GameSession", sessionId, { status });
        return updated;
    }
    async paymentMember(tx, memberId, storeId) {
        const member = await tx.member.findFirst({ where: { id: memberId, storeId, status: "ACTIVE" } });
        if (!member)
            throw new common_1.BadRequestException("会员不存在、未激活或不属于当前门店");
        return member;
    }
    async assertMemberUsageLimit(tx, sessionId, member, excludePlayerId) {
        const limits = { SINGLE: 1, DOUBLE: 2, MULTI: null };
        const maxUsers = Object.prototype.hasOwnProperty.call(limits, member.tier) ? limits[member.tier] : 1;
        if (maxUsers === null)
            return;
        const usedUsers = await tx.sessionPlayer.count({
            where: {
                sessionId,
                memberId: member.id,
                paymentMethod: "MEMBER",
                status: "ACTIVE",
                ...(excludePlayerId ? { id: { not: excludePlayerId } } : {}),
            },
        });
        if (usedUsers >= maxUsers) {
            const cardName = member.tier === "DOUBLE" ? "双人卡" : "单人卡";
            throw new common_1.BadRequestException(`${cardName}同一车最多可划 ${maxUsers} 人，本车已达到上限`);
        }
    }
    async changeMemberBalance(tx, user, memberId, deltaCents, type, note) {
        const member = await tx.member.findUnique({ where: { id: memberId } });
        if (!member)
            throw new common_1.NotFoundException("会员不存在");
        const balanceAfterCents = member.balanceCents + deltaCents;
        if (balanceAfterCents < 0)
            throw new common_1.BadRequestException(`会员 ${member.name} 余额不足`);
        await tx.memberLedger.create({ data: { memberId, operatorId: user.id, type, amountCents: deltaCents, balanceAfterCents, note } });
        await tx.member.update({ where: { id: memberId }, data: { balanceCents: balanceAfterCents } });
    }
    audit(user, action, entityType, entityId, payload) {
        return this.prisma.auditLog.create({
            data: { userId: user.id, action, entityType, entityId, payload: payload ? JSON.stringify(payload) : undefined },
        });
    }
};
exports.SessionsService = SessionsService;
exports.SessionsService = SessionsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], SessionsService);
//# sourceMappingURL=sessions.service.js.map