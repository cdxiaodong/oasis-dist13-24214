"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const business_rules_1 = require("../common/business-rules");
const sessions_service_1 = require("./sessions.service");
const PAYMENT_METHODS = ["CASH", "MEITUAN_GROUP", "MEITUAN_RESERVATION", "DOUYIN", "MEMBER", "TRANSFER", "OTHER"];
class CreateSessionDto {
    storeId;
    roomId;
    scriptId;
    hostId;
    assistantId;
    npcId;
    assistantIds;
    npcIds;
    assistantAssignments;
    npcAssignments;
    allowPersonnelOverlap;
    startAt;
    expectedEndAt;
    notes;
}
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择门店" }),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择房间" }),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "roomId", void 0);
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择剧本" }),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "scriptId", void 0);
__decorate([
    (0, class_validator_1.IsString)({ message: "请选择主DM" }),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "hostId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "assistantId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "npcId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], CreateSessionDto.prototype, "assistantIds", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayUnique)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], CreateSessionDto.prototype, "npcIds", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateSessionDto.prototype, "assistantAssignments", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], CreateSessionDto.prototype, "npcAssignments", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateSessionDto.prototype, "allowPersonnelOverlap", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)({}, { message: "请选择开始时间" }),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "startAt", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)({}, { message: "请选择预计结束时间" }),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "expectedEndAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateSessionDto.prototype, "notes", void 0);
class UpdateSessionDto {
    roomId;
    scriptId;
    hostId;
    assistantAssignments;
    npcAssignments;
    startAt;
    expectedEndAt;
    notes;
    joinEnabled;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateSessionDto.prototype, "roomId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateSessionDto.prototype, "scriptId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateSessionDto.prototype, "hostId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], UpdateSessionDto.prototype, "assistantAssignments", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], UpdateSessionDto.prototype, "npcAssignments", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], UpdateSessionDto.prototype, "startAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], UpdateSessionDto.prototype, "expectedEndAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateSessionDto.prototype, "notes", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateSessionDto.prototype, "joinEnabled", void 0);
class AddPlayerDto {
    name;
    phone;
    type;
    paymentMethod;
    amountCents;
    discountCents;
    activity;
    proofUrl;
    proofUrls;
    memberId;
    remark;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["PLAYER", "STAFF_FILL", "FRIEND_FILL", "VIRTUAL_SEAT"], { message: "玩家类型不正确" }),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(PAYMENT_METHODS, { message: "支付方式不正确" }),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "paymentMethod", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: "实收金额格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "实收金额不能为负" }),
    __metadata("design:type", Number)
], AddPlayerDto.prototype, "amountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: "优惠金额格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "优惠金额不能为负" }),
    __metadata("design:type", Number)
], AddPlayerDto.prototype, "discountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "activity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "proofUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], AddPlayerDto.prototype, "proofUrls", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "memberId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AddPlayerDto.prototype, "remark", void 0);
class PaymentDto {
    name;
    phone;
    type;
    paymentMethod;
    amountCents;
    discountCents;
    activity;
    proofUrl;
    proofUrls;
    memberId;
    remark;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PaymentDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PaymentDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["PLAYER", "STAFF_FILL", "FRIEND_FILL", "VIRTUAL_SEAT"], { message: "玩家类型不正确" }),
    __metadata("design:type", String)
], PaymentDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsIn)(PAYMENT_METHODS, { message: "请选择支付方式" }),
    __metadata("design:type", String)
], PaymentDto.prototype, "paymentMethod", void 0);
__decorate([
    (0, class_validator_1.IsInt)({ message: "实收金额格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "实收金额不能为负" }),
    __metadata("design:type", Number)
], PaymentDto.prototype, "amountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)({ message: "优惠金额格式不正确" }),
    (0, class_validator_1.Min)(0, { message: "优惠金额不能为负" }),
    __metadata("design:type", Number)
], PaymentDto.prototype, "discountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PaymentDto.prototype, "activity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PaymentDto.prototype, "proofUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], PaymentDto.prototype, "proofUrls", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PaymentDto.prototype, "memberId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PaymentDto.prototype, "remark", void 0);
class UpdatePlayerDto {
    name;
    phone;
    type;
    remark;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdatePlayerDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdatePlayerDto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(["PLAYER", "STAFF_FILL", "FRIEND_FILL", "VIRTUAL_SEAT"]),
    __metadata("design:type", String)
], UpdatePlayerDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdatePlayerDto.prototype, "remark", void 0);
class ReasonDto {
    reason;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReasonDto.prototype, "reason", void 0);
class RefundDto extends ReasonDto {
    amountCents;
}
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], RefundDto.prototype, "amountCents", void 0);
class AssignmentResponseDto {
    status;
    note;
}
__decorate([
    (0, class_validator_1.IsIn)(["ACCEPTED", "DECLINED"]),
    __metadata("design:type", String)
], AssignmentResponseDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AssignmentResponseDto.prototype, "note", void 0);
class MaterialDto {
    phase;
    label;
    imageUrl;
    note;
}
__decorate([
    (0, class_validator_1.IsIn)(["END"]),
    __metadata("design:type", String)
], MaterialDto.prototype, "phase", void 0);
__decorate([
    (0, class_validator_1.IsIn)(business_rules_1.END_MATERIAL_LABELS),
    __metadata("design:type", String)
], MaterialDto.prototype, "label", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], MaterialDto.prototype, "imageUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], MaterialDto.prototype, "note", void 0);
class DesignationDto {
    staffId;
    staffRole;
    proofUrl;
    proofUrls;
    note;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DesignationDto.prototype, "staffId", void 0);
__decorate([
    (0, class_validator_1.IsIn)(["HOST", "ASSISTANT", "NPC"]),
    __metadata("design:type", String)
], DesignationDto.prototype, "staffRole", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DesignationDto.prototype, "proofUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    __metadata("design:type", Array)
], DesignationDto.prototype, "proofUrls", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], DesignationDto.prototype, "note", void 0);
class DesignationStatusDto {
    status;
}
__decorate([
    (0, class_validator_1.IsIn)(["DESIGNATED", "NOT_DESIGNATED"]),
    __metadata("design:type", String)
], DesignationStatusDto.prototype, "status", void 0);
class TransitionDto {
    action;
    note;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransitionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], TransitionDto.prototype, "note", void 0);
let SessionsController = class SessionsController {
    sessions;
    constructor(sessions) {
        this.sessions = sessions;
    }
    list(user, storeId, state) {
        return this.sessions.list(user, { storeId, state });
    }
    one(user, id) {
        return this.sessions.one(user, id);
    }
    create(user, dto) {
        return this.sessions.create(user, dto);
    }
    update(user, id, dto) {
        return this.sessions.update(user, id, dto);
    }
    addPlayer(user, id, dto) {
        return this.sessions.addPlayer(user, id, dto);
    }
    payment(user, id, playerId, dto) {
        return this.sessions.updatePayment(user, id, playerId, dto);
    }
    updatePlayer(user, id, playerId, dto) {
        return this.sessions.updatePlayer(user, id, playerId, dto);
    }
    removePlayer(user, id, playerId, dto) {
        return this.sessions.removePlayer(user, id, playerId, dto.reason);
    }
    refundPlayer(user, id, playerId, dto) {
        return this.sessions.refundPlayer(user, id, playerId, dto.amountCents, dto.reason);
    }
    respondAssignment(user, id, assignmentId, dto) {
        return this.sessions.respondAssignment(user, id, assignmentId, dto.status, dto.note);
    }
    material(user, id, dto) {
        return this.sessions.addMaterial(user, id, dto);
    }
    designate(user, id, dto) {
        return this.sessions.addDesignation(user, id, dto);
    }
    designationStatus(user, id, dto) {
        return this.sessions.setDesignationStatus(user, id, dto.status);
    }
    transition(user, id, dto) {
        return this.sessions.transition(user, id, dto.action, dto.note);
    }
};
exports.SessionsController = SessionsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("state")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(":id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "one", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: "新建车次" }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateSessionDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(":id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateSessionDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(":id/players"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, AddPlayerDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "addPlayer", null);
__decorate([
    (0, common_1.Patch)(":id/players/:playerId/payment"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Param)("playerId")),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, PaymentDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "payment", null);
__decorate([
    (0, common_1.Patch)(":id/players/:playerId"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Param)("playerId")),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, UpdatePlayerDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "updatePlayer", null);
__decorate([
    (0, common_1.Post)(":id/players/:playerId/remove"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Param)("playerId")),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, ReasonDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "removePlayer", null);
__decorate([
    (0, common_1.Post)(":id/players/:playerId/refund"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Param)("playerId")),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, RefundDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "refundPlayer", null);
__decorate([
    (0, common_1.Post)(":id/staff-assignments/:assignmentId/respond"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Param)("assignmentId")),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, AssignmentResponseDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "respondAssignment", null);
__decorate([
    (0, common_1.Post)(":id/materials"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, MaterialDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "material", null);
__decorate([
    (0, common_1.Post)(":id/designations"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, DesignationDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "designate", null);
__decorate([
    (0, common_1.Post)(":id/designation-status"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, DesignationStatusDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "designationStatus", null);
__decorate([
    (0, common_1.Post)(":id/transition"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, TransitionDto]),
    __metadata("design:returntype", void 0)
], SessionsController.prototype, "transition", null);
exports.SessionsController = SessionsController = __decorate([
    (0, swagger_1.ApiTags)("车次"),
    (0, common_1.Controller)("sessions"),
    __metadata("design:paramtypes", [sessions_service_1.SessionsService])
], SessionsController);
//# sourceMappingURL=sessions.controller.js.map