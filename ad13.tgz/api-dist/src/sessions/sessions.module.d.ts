export declare class SessionsModule {
}
