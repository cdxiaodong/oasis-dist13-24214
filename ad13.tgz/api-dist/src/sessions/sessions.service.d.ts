import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
export declare class SessionsService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private include;
    private scope;
    private participantWhere;
    private assertCanEditSession;
    private minimumPlayers;
    private protectedImageList;
    private sanitizeSession;
    list(user: UserSession, query: {
        storeId?: string;
        state?: string;
    }): Promise<({
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    })[]>;
    one(user: UserSession, id: string): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    create(user: UserSession, data: {
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId?: string;
        npcId?: string;
        assistantIds?: string[];
        npcIds?: string[];
        assistantAssignments?: Array<{
            userId: string;
            feeTier?: string;
            feeCents?: number;
        }>;
        npcAssignments?: Array<{
            userId: string;
            feeTier?: string;
            feeCents?: number;
        }>;
        allowPersonnelOverlap?: boolean;
        startAt: string;
        expectedEndAt: string;
        notes?: string;
    }): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    update(user: UserSession, id: string, data: {
        roomId?: string;
        scriptId?: string;
        hostId?: string;
        assistantAssignments?: Array<{
            userId: string;
            feeTier?: string;
            feeCents?: number;
        }>;
        npcAssignments?: Array<{
            userId: string;
            feeTier?: string;
            feeCents?: number;
        }>;
        startAt?: string;
        expectedEndAt?: string;
        notes?: string;
        joinEnabled?: boolean;
    }): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    addPlayer(user: UserSession, sessionId: string, data: {
        name?: string;
        phone?: string;
        type?: string;
        paymentMethod?: string;
        amountCents?: number;
        discountCents?: number;
        activity?: string;
        proofUrl?: string;
        proofUrls?: string[];
        memberId?: string;
        remark?: string;
    }): Promise<{
        member: {
            id: string;
            name: string;
            phone: string;
            balanceCents: number;
            tier: string;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    updatePayment(user: UserSession, sessionId: string, playerId: string, data: {
        name?: string;
        phone?: string;
        type?: string;
        paymentMethod: string;
        amountCents: number;
        discountCents?: number;
        activity?: string;
        proofUrl?: string;
        proofUrls?: string[];
        memberId?: string;
        remark?: string;
    }): Promise<{
        member: {
            id: string;
            name: string;
            phone: string;
            balanceCents: number;
            tier: string;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    updatePlayer(user: UserSession, sessionId: string, playerId: string, data: {
        name?: string;
        phone?: string;
        type?: string;
        remark?: string;
    }): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    removePlayer(user: UserSession, sessionId: string, playerId: string, reason: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    refundPlayer(user: UserSession, sessionId: string, playerId: string, amountCents: number, reason: string): Promise<{
        member: {
            id: string;
            name: string;
            phone: string;
            balanceCents: number;
        } | null;
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        phone: string | null;
        status: string;
        type: string;
        paymentMethod: string | null;
        amountCents: number;
        discountCents: number;
        activity: string | null;
        proofUrl: string | null;
        remark: string | null;
        refundedCents: number;
        removedAt: Date | null;
        removedReason: string | null;
        guestOpenId: string | null;
        memberId: string | null;
        sessionId: string;
    }>;
    respondAssignment(user: UserSession, sessionId: string, assignmentId: string, status: string, note?: string): Promise<{
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        createdAt: Date;
        updatedAt: Date;
        role: string;
        status: string;
        sessionId: string;
        note: string | null;
        feeTier: string | null;
        feeCents: number;
        shiftStartAt: Date | null;
        shiftEndAt: Date | null;
        respondedAt: Date | null;
        userId: string;
    }>;
    addMaterial(user: UserSession, sessionId: string, data: {
        phase: string;
        label: string;
        imageUrl: string;
        note?: string;
    }): Promise<{
        id: string;
        createdAt: Date;
        sessionId: string;
        note: string | null;
        phase: string;
        label: string;
        imageUrl: string;
    }>;
    transition(user: UserSession, id: string, action: string, note?: string): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    addDesignation(user: UserSession, sessionId: string, data: {
        staffId: string;
        staffRole: string;
        proofUrl: string;
        proofUrls?: string[];
        note?: string;
    }): Promise<{
        staff: {
            id: string;
            name: string;
            role: string;
        };
        createdBy: {
            id: string;
            name: string;
        };
    } & {
        id: string;
        createdAt: Date;
        proofUrl: string;
        sessionId: string;
        note: string | null;
        staffId: string;
        staffRole: string;
        createdById: string;
    }>;
    setDesignationStatus(user: UserSession, sessionId: string, status: string): Promise<{
        store: {
            id: string;
            code: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        room: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        };
        script: {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            version: number;
            category: string;
            theme: string;
            playerCount: number;
            minPlayerCount: number;
            priceCents: number;
            memberPriceCents: number;
            durationMinutes: number;
            sessionFactor: number;
            needsAssistant: boolean;
            needsNpc: boolean;
            assistantCount: number;
            npcCount: number;
            assistantFeeTiers: string;
            npcFeeTiers: string;
            eligibleHostIds: string;
            eligibleAssistantIds: string;
            eligibleNpcIds: string;
            requiredPreparationLabels: string;
            requiredMaterialLabels: string;
            preparationExamples: string;
            materialExamples: string;
        };
        host: {
            id: string;
            name: string;
            role: string;
        };
        assistant: {
            id: string;
            name: string;
            role: string;
        } | null;
        npc: {
            id: string;
            name: string;
            role: string;
        } | null;
        players: ({
            member: {
                id: string;
                name: string;
                phone: string;
                balanceCents: number;
                tier: string;
            } | null;
            adjustments: ({
                operator: {
                    id: string;
                    name: string;
                };
            } & {
                id: string;
                createdAt: Date;
                type: string;
                amountCents: number;
                reason: string;
                playerId: string;
                operatorId: string;
            })[];
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            phone: string | null;
            status: string;
            type: string;
            paymentMethod: string | null;
            amountCents: number;
            discountCents: number;
            activity: string | null;
            proofUrl: string | null;
            remark: string | null;
            refundedCents: number;
            removedAt: Date | null;
            removedReason: string | null;
            guestOpenId: string | null;
            memberId: string | null;
            sessionId: string;
        })[];
        materials: {
            id: string;
            createdAt: Date;
            sessionId: string;
            note: string | null;
            phase: string;
            label: string;
            imageUrl: string;
        }[];
        staffAssignments: ({
            user: {
                id: string;
                name: string;
                role: string;
            };
        } & {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            role: string;
            status: string;
            sessionId: string;
            note: string | null;
            feeTier: string | null;
            feeCents: number;
            shiftStartAt: Date | null;
            shiftEndAt: Date | null;
            respondedAt: Date | null;
            userId: string;
        })[];
        designations: ({
            staff: {
                id: string;
                name: string;
                role: string;
            };
            createdBy: {
                id: string;
                name: string;
            };
        } & {
            id: string;
            createdAt: Date;
            proofUrl: string;
            sessionId: string;
            note: string | null;
            staffId: string;
            staffRole: string;
            createdById: string;
        })[];
    } & {
        id: string;
        code: string;
        state: string;
        startAt: Date;
        expectedEndAt: Date;
        actualEndAt: Date | null;
        notes: string | null;
        rejectionNote: string | null;
        designationStatus: string;
        storeId: string;
        roomId: string;
        scriptId: string;
        hostId: string;
        assistantId: string | null;
        npcId: string | null;
        joinToken: string | null;
        joinEnabled: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
    private paymentMember;
    private assertMemberUsageLimit;
    private changeMemberBalance;
    private audit;
}
