export declare class JoinPlayerDto {
    name?: string;
    phone?: string;
    loginCode: string;
    phoneCode?: string;
}
