"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SessionJoinService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const wechat_auth_service_1 = require("../auth/wechat-auth.service");
const JOINABLE_STATES = ["DRAFT", "PENDING_CONFIRMATION", "READY", "IN_PROGRESS"];
const TOKEN_PATTERN = /^[A-Za-z0-9_-]{10,32}$/;
let SessionJoinService = class SessionJoinService {
    prisma;
    wechat;
    constructor(prisma, wechat) {
        this.prisma = prisma;
        this.wechat = wechat;
    }
    async findByToken(token) {
        if (!TOKEN_PATTERN.test(token))
            throw new common_1.NotFoundException("入场码无效");
        const session = await this.prisma.gameSession.findUnique({
            where: { joinToken: token },
            include: {
                store: { select: { name: true } },
                script: { select: { name: true, playerCount: true } },
                room: { select: { name: true } },
                players: { select: { id: true, phone: true, guestOpenId: true, status: true } },
            },
        });
        if (!session)
            throw new common_1.NotFoundException("入场码无效或已过期");
        return session;
    }
    async summary(token) {
        const session = await this.findByToken(token);
        const activePlayers = session.players.filter((player) => player.status === "ACTIVE");
        const remainingSeats = Math.max(0, session.script.playerCount - activePlayers.length);
        return {
            code: session.code,
            scriptName: session.script.name,
            storeName: session.store.name,
            roomName: session.room.name,
            startAt: session.startAt,
            closed: !JOINABLE_STATES.includes(session.state),
            joinEnabled: session.joinEnabled,
            joinable: JOINABLE_STATES.includes(session.state) && session.joinEnabled && remainingSeats > 0,
            playerCount: activePlayers.length,
            maxPlayerCount: session.script.playerCount,
            remainingSeats,
        };
    }
    async register(token, dto) {
        const session = await this.findByToken(token);
        this.assertJoinable(session);
        if (!dto.loginCode)
            throw new common_1.BadRequestException("请先完成微信登录");
        const identity = dto.phoneCode
            ? await this.wechat.authenticate(dto.loginCode, dto.phoneCode)
            : await this.wechat.getSession(dto.loginCode);
        const phone = identity.phone?.trim() ?? "";
        if (phone && !/^1\d{10}$/.test(phone))
            throw new common_1.BadRequestException("手机号格式不正确");
        const openIdPlayer = session.players.find((player) => player.guestOpenId === identity.openId);
        if (openIdPlayer?.status === "REMOVED")
            throw new common_1.BadRequestException("你已从本车移除，如需重新加入请联系店员");
        if (openIdPlayer)
            return { playerId: openIdPlayer.id, duplicated: true, verified: Boolean(phone) };
        const phonePlayer = phone ? session.players.find((player) => player.phone === phone) : undefined;
        if (phonePlayer)
            return { playerId: phonePlayer.id, duplicated: true, verified: true };
        const player = await this.prisma
            .$transaction(async (tx) => {
            const current = await tx.gameSession.findUnique({
                where: { id: session.id },
                select: {
                    state: true,
                    joinEnabled: true,
                    script: { select: { playerCount: true } },
                    players: { select: { id: true, phone: true, guestOpenId: true, status: true } },
                },
            });
            if (!current)
                throw new common_1.NotFoundException("入场码无效或已过期");
            this.assertJoinable(current);
            const activePlayers = current.players.filter((player) => player.status === "ACTIVE");
            const duplicated = current.players.find((player) => player.guestOpenId === identity.openId || (phone && player.phone === phone));
            if (duplicated?.status === "REMOVED")
                throw new common_1.BadRequestException("你已从本车移除，如需重新加入请联系店员");
            if (duplicated)
                return duplicated;
            return tx.sessionPlayer.create({
                data: {
                    name: dto.name?.trim() || `扫码客人${activePlayers.length + 1}`,
                    phone: phone || null,
                    guestOpenId: identity.openId,
                    type: "PLAYER",
                    remark: phone ? "客人扫码自助登记（微信授权号码）" : "客人扫码自助登记",
                    sessionId: session.id,
                },
            });
        })
            .catch(async (error) => {
            if (!(error instanceof client_1.Prisma.PrismaClientKnownRequestError) || error.code !== "P2002")
                throw error;
            const existing = await this.prisma.sessionPlayer.findFirst({
                where: { sessionId: session.id, guestOpenId: identity.openId },
                select: { id: true, status: true },
            });
            if (existing?.status === "REMOVED")
                throw new common_1.BadRequestException("你已从本车移除，如需重新加入请联系店员");
            if (existing)
                return existing;
            throw new common_1.ConflictException("当前车次登记繁忙，请稍后重试");
        });
        return { playerId: player.id, duplicated: player.status !== "ACTIVE", verified: Boolean(phone) };
    }
    async qrcode(token) {
        const session = await this.findByToken(token);
        this.assertJoinable(session);
        return this.wechat.getWxaCode(token, "pages/join/index");
    }
    assertJoinable(session) {
        if (!JOINABLE_STATES.includes(session.state))
            throw new common_1.BadRequestException("该车次当前不能登记");
        if (!session.joinEnabled)
            throw new common_1.BadRequestException("本车未开放扫码进组");
        if (session.players.filter((player) => player.status === "ACTIVE").length >= session.script.playerCount) {
            throw new common_1.BadRequestException("本车坑位已满");
        }
    }
};
exports.SessionJoinService = SessionJoinService;
exports.SessionJoinService = SessionJoinService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        wechat_auth_service_1.WechatAuthService])
], SessionJoinService);
//# sourceMappingURL=session-join.service.js.map