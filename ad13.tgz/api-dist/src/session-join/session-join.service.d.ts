import { PrismaService } from "../prisma/prisma.service";
import { WechatAuthService } from "../auth/wechat-auth.service";
import { JoinPlayerDto } from "./session-join.dto";
export declare class SessionJoinService {
    private readonly prisma;
    private readonly wechat;
    constructor(prisma: PrismaService, wechat: WechatAuthService);
    private findByToken;
    summary(token: string): Promise<{
        code: string;
        scriptName: string;
        storeName: string;
        roomName: string;
        startAt: Date;
        closed: boolean;
        joinEnabled: boolean;
        joinable: boolean;
        playerCount: number;
        maxPlayerCount: number;
        remainingSeats: number;
    }>;
    register(token: string, dto: JoinPlayerDto): Promise<{
        playerId: string;
        duplicated: boolean;
        verified: boolean;
    }>;
    qrcode(token: string): Promise<Buffer>;
    private assertJoinable;
}
