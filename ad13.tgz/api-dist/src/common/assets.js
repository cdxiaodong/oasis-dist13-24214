"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.protectedImageUrl = protectedImageUrl;
const common_1 = require("@nestjs/common");
function protectedImageUrl(value, label = "图片") {
    const path = value.split("?")[0];
    const normalized = path.startsWith("/uploads/") ? `/api/uploads/files/${path.slice("/uploads/".length)}` : path;
    if (!/^\/api\/uploads\/files\/\d+-[0-9a-f-]+\.(?:jpg|png|webp)$/.test(normalized)) {
        throw new common_1.BadRequestException(`${label}必须通过系统上传`);
    }
    return normalized;
}
//# sourceMappingURL=assets.js.map