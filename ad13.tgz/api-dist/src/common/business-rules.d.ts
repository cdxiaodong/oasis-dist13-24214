export declare const ACTIVITY_TYPE_DEFINITIONS: readonly [{
    readonly name: "大学生活动";
    readonly defaultDiscountCents: 1000;
    readonly sortOrder: 10;
}, {
    readonly name: "夜场活动";
    readonly defaultDiscountCents: 1000;
    readonly sortOrder: 20;
}, {
    readonly name: "好评活动";
    readonly defaultDiscountCents: 0;
    readonly sortOrder: 30;
}, {
    readonly name: "早鸟票";
    readonly defaultDiscountCents: 0;
    readonly sortOrder: 40;
}, {
    readonly name: "其它";
    readonly defaultDiscountCents: 0;
    readonly sortOrder: 50;
}];
export declare const ACTIVITY_TYPE_NAMES: ("大学生活动" | "夜场活动" | "好评活动" | "早鸟票" | "其它")[];
export declare const REQUIRED_END_MATERIAL_LABELS: readonly ["桌面全景照片", "垃圾桶照片", "空调关闭照片", "剧本线索整理照片", "剧本入库照片", "遥控器归位照片", "房间关灯照片", "门牌或门灯还原照片"];
export declare const OPTIONAL_END_MATERIAL_LABELS: readonly ["道具归还照片", "其它"];
export declare const END_MATERIAL_LABELS: ("桌面全景照片" | "垃圾桶照片" | "空调关闭照片" | "剧本线索整理照片" | "剧本入库照片" | "遥控器归位照片" | "房间关灯照片" | "门牌或门灯还原照片" | "其它" | "道具归还照片")[];
