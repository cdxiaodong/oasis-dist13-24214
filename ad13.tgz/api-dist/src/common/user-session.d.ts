export interface UserSession {
    id: string;
    username: string;
    name: string;
    role: string;
    storeId: string | null;
    mustChangePassword?: boolean;
}
export declare const GLOBAL_ROLES: Set<string>;
export declare function canAccessStore(user: UserSession, storeId: string): boolean;
