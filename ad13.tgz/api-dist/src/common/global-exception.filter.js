"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var GlobalExceptionFilter_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.GlobalExceptionFilter = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
let GlobalExceptionFilter = GlobalExceptionFilter_1 = class GlobalExceptionFilter {
    logger = new common_1.Logger(GlobalExceptionFilter_1.name);
    catch(exception, host) {
        const ctx = host.switchToHttp();
        const response = ctx.getResponse();
        let status = common_1.HttpStatus.INTERNAL_SERVER_ERROR;
        let message = "服务器内部错误，请稍后重试";
        let error = "Internal Server Error";
        if (exception instanceof common_1.HttpException) {
            status = exception.getStatus();
            const resp = exception.getResponse();
            if (typeof resp === "string") {
                message = resp;
            }
            else if (typeof resp === "object" && resp !== null) {
                const r = resp;
                message = r.message || exception.message;
                error = r.error || error;
            }
        }
        else if (exception instanceof client_1.Prisma.PrismaClientKnownRequestError) {
            if (exception.code === "P2002") {
                status = common_1.HttpStatus.CONFLICT;
                message = "数据已存在，请检查唯一字段";
                error = "Conflict";
            }
            else if (exception.code === "P2025") {
                status = common_1.HttpStatus.NOT_FOUND;
                message = "记录不存在或已被删除";
                error = "Not Found";
            }
            else {
                this.logger.error(`Prisma error ${exception.code}: ${exception.message}`, exception.stack);
            }
        }
        else {
            this.logger.error(exception instanceof Error ? exception.message : "Unknown error", exception instanceof Error ? exception.stack : undefined);
        }
        const body = {
            statusCode: status,
            message: Array.isArray(message) ? message.join("；") : message,
            error,
            timestamp: new Date().toISOString(),
        };
        if (!response.headersSent) {
            response.status(status).json(body);
        }
    }
};
exports.GlobalExceptionFilter = GlobalExceptionFilter;
exports.GlobalExceptionFilter = GlobalExceptionFilter = GlobalExceptionFilter_1 = __decorate([
    (0, common_1.Catch)()
], GlobalExceptionFilter);
//# sourceMappingURL=global-exception.filter.js.map