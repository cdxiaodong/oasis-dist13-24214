"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkforceController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const workforce_service_1 = require("./workforce.service");
class RangeQueryDto {
    storeId;
    from;
    to;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RangeQueryDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], RangeQueryDto.prototype, "from", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], RangeQueryDto.prototype, "to", void 0);
class CreateShiftDto {
    storeId;
    userId;
    shiftType;
    startAt;
    endAt;
    note;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateShiftDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateShiftDto.prototype, "userId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateShiftDto.prototype, "shiftType", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], CreateShiftDto.prototype, "startAt", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], CreateShiftDto.prototype, "endAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateShiftDto.prototype, "note", void 0);
class UpdateShiftDto {
    shiftType;
    startAt;
    endAt;
    status;
    note;
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShiftDto.prototype, "shiftType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], UpdateShiftDto.prototype, "startAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], UpdateShiftDto.prototype, "endAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShiftDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateShiftDto.prototype, "note", void 0);
class CreateRequestDto {
    shiftId;
    type;
    reason;
    targetUserId;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRequestDto.prototype, "shiftId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRequestDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRequestDto.prototype, "reason", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateRequestDto.prototype, "targetUserId", void 0);
class ActionDto {
    action;
    comment;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ActionDto.prototype, "comment", void 0);
class CreateFeeDto {
    sessionId;
    userId;
    feeType;
    amountCents;
    note;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFeeDto.prototype, "sessionId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFeeDto.prototype, "userId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFeeDto.prototype, "feeType", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateFeeDto.prototype, "amountCents", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateFeeDto.prototype, "note", void 0);
let WorkforceController = class WorkforceController {
    workforce;
    constructor(workforce) {
        this.workforce = workforce;
    }
    availability(user, query) { return this.workforce.availability(user, query); }
    shifts(user, query) { return this.workforce.shifts(user, query); }
    createShift(user, dto) { return this.workforce.createShift(user, dto); }
    updateShift(user, id, dto) { return this.workforce.updateShift(user, id, dto); }
    requests(user, storeId) { return this.workforce.requests(user, storeId); }
    createRequest(user, dto) { return this.workforce.createRequest(user, dto); }
    actionRequest(user, id, dto) { return this.workforce.actionRequest(user, id, dto.action, dto.comment); }
    fees(user, query) { return this.workforce.fees(user, query); }
    createFee(user, dto) { return this.workforce.createFee(user, dto); }
    actionFee(user, id, dto) { return this.workforce.actionFee(user, id, dto.action, dto.comment); }
    feeSummary(user, query) { return this.workforce.feeSummary(user, query); }
};
exports.WorkforceController = WorkforceController;
__decorate([
    (0, common_1.Get)("availability"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, RangeQueryDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "availability", null);
__decorate([
    (0, common_1.Get)("shifts"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, RangeQueryDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "shifts", null);
__decorate([
    (0, common_1.Post)("shifts"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateShiftDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "createShift", null);
__decorate([
    (0, common_1.Patch)("shifts/:id"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, UpdateShiftDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "updateShift", null);
__decorate([
    (0, common_1.Get)("requests"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "requests", null);
__decorate([
    (0, common_1.Post)("requests"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateRequestDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "createRequest", null);
__decorate([
    (0, common_1.Post)("requests/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, ActionDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "actionRequest", null);
__decorate([
    (0, common_1.Get)("session-fees"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, RangeQueryDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "fees", null);
__decorate([
    (0, common_1.Post)("session-fees"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, CreateFeeDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "createFee", null);
__decorate([
    (0, common_1.Post)("session-fees/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, ActionDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "actionFee", null);
__decorate([
    (0, common_1.Get)("fee-summary"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, RangeQueryDto]),
    __metadata("design:returntype", void 0)
], WorkforceController.prototype, "feeSummary", null);
exports.WorkforceController = WorkforceController = __decorate([
    (0, common_1.Controller)("workforce"),
    __metadata("design:paramtypes", [workforce_service_1.WorkforceService])
], WorkforceController);
//# sourceMappingURL=workforce.controller.js.map