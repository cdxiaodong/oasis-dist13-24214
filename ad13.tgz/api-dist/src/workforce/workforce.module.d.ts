export declare class WorkforceModule {
}
