import type { UserSession } from "../common/user-session";
import { WorkforceService } from "./workforce.service";
declare class RangeQueryDto {
    storeId?: string;
    from: string;
    to: string;
}
declare class CreateShiftDto {
    storeId: string;
    userId: string;
    shiftType: string;
    startAt: string;
    endAt: string;
    note?: string;
}
declare class UpdateShiftDto {
    shiftType?: string;
    startAt?: string;
    endAt?: string;
    status?: string;
    note?: string;
}
declare class CreateRequestDto {
    shiftId: string;
    type: string;
    reason: string;
    targetUserId?: string;
}
declare class ActionDto {
    action: string;
    comment?: string;
}
declare class CreateFeeDto {
    sessionId: string;
    userId?: string;
    feeType: string;
    amountCents: number;
    note?: string;
}
export declare class WorkforceController {
    private readonly workforce;
    constructor(workforce: WorkforceService);
    availability(user: UserSession, query: RangeQueryDto): Promise<{
        range: {
            from: Date;
            to: Date;
        };
        rooms: {
            sessions: {
                id: any;
                code: any;
                scriptName: any;
                roomName: any;
                startAt: any;
                endAt: any;
            }[];
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            capacity: number;
        }[];
        users: {
            shifts: {
                id: string;
                note: string | null;
                storeId: string;
                createdById: string;
                createdAt: Date;
                updatedAt: Date;
                startAt: Date;
                status: string;
                userId: string;
                shiftType: string;
                endAt: Date;
            }[];
            sessions: {
                id: any;
                code: any;
                scriptName: any;
                roomName: any;
                startAt: any;
                endAt: any;
            }[];
            id: string;
            name: string;
            role: string;
        }[];
    }>;
    shifts(user: UserSession, query: RangeQueryDto): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        startAt: Date;
        status: string;
        userId: string;
        shiftType: string;
        endAt: Date;
    })[]>;
    createShift(user: UserSession, dto: CreateShiftDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        startAt: Date;
        status: string;
        userId: string;
        shiftType: string;
        endAt: Date;
    }>;
    updateShift(user: UserSession, id: string, dto: UpdateShiftDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        startAt: Date;
        status: string;
        userId: string;
        shiftType: string;
        endAt: Date;
    }>;
    requests(user: UserSession, storeId?: string): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        shift: {
            id: string;
            note: string | null;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            startAt: Date;
            status: string;
            userId: string;
            shiftType: string;
            endAt: Date;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        requester: {
            id: string;
            name: string;
            role: string;
        };
        targetUser: {
            id: string;
            name: string;
            role: string;
        } | null;
    } & {
        id: string;
        type: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewedById: string | null;
        respondedAt: Date | null;
        reason: string;
        reviewerComment: string | null;
        shiftId: string;
        requesterId: string;
        targetUserId: string | null;
    })[]>;
    createRequest(user: UserSession, dto: CreateRequestDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        shift: {
            id: string;
            note: string | null;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            startAt: Date;
            status: string;
            userId: string;
            shiftType: string;
            endAt: Date;
        };
        requester: {
            id: string;
            name: string;
        };
        targetUser: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewedById: string | null;
        respondedAt: Date | null;
        reason: string;
        reviewerComment: string | null;
        shiftId: string;
        requesterId: string;
        targetUserId: string | null;
    }>;
    actionRequest(user: UserSession, id: string, dto: ActionDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        shift: {
            id: string;
            note: string | null;
            storeId: string;
            createdById: string;
            createdAt: Date;
            updatedAt: Date;
            startAt: Date;
            status: string;
            userId: string;
            shiftType: string;
            endAt: Date;
        };
        reviewedBy: {
            id: string;
            name: string;
        } | null;
        requester: {
            id: string;
            name: string;
        };
        targetUser: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        type: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        status: string;
        reviewedById: string | null;
        respondedAt: Date | null;
        reason: string;
        reviewerComment: string | null;
        shiftId: string;
        requesterId: string;
        targetUserId: string | null;
    }>;
    fees(user: UserSession, query: RangeQueryDto): import("@prisma/client").Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        } | null;
        session: {
            script: {
                id: string;
                storeId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                version: number;
                category: string;
                theme: string;
                playerCount: number;
                minPlayerCount: number;
                priceCents: number;
                memberPriceCents: number;
                durationMinutes: number;
                sessionFactor: number;
                needsAssistant: boolean;
                needsNpc: boolean;
                assistantCount: number;
                npcCount: number;
                assistantFeeTiers: string;
                npcFeeTiers: string;
                eligibleHostIds: string;
                eligibleAssistantIds: string;
                eligibleNpcIds: string;
                requiredPreparationLabels: string;
                requiredMaterialLabels: string;
                preparationExamples: string;
                materialExamples: string;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            state: string;
            startAt: Date;
            expectedEndAt: Date;
            actualEndAt: Date | null;
            notes: string | null;
            rejectionNote: string | null;
            designationStatus: string;
            roomId: string;
            scriptId: string;
            hostId: string;
            assistantId: string | null;
            npcId: string | null;
            joinToken: string | null;
            joinEnabled: boolean;
        };
        confirmedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        sessionId: string;
        userId: string | null;
        feeType: string;
        confirmedById: string | null;
        confirmedAt: Date | null;
    })[]>;
    createFee(user: UserSession, dto: CreateFeeDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        } | null;
        session: {
            script: {
                id: string;
                storeId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                version: number;
                category: string;
                theme: string;
                playerCount: number;
                minPlayerCount: number;
                priceCents: number;
                memberPriceCents: number;
                durationMinutes: number;
                sessionFactor: number;
                needsAssistant: boolean;
                needsNpc: boolean;
                assistantCount: number;
                npcCount: number;
                assistantFeeTiers: string;
                npcFeeTiers: string;
                eligibleHostIds: string;
                eligibleAssistantIds: string;
                eligibleNpcIds: string;
                requiredPreparationLabels: string;
                requiredMaterialLabels: string;
                preparationExamples: string;
                materialExamples: string;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            state: string;
            startAt: Date;
            expectedEndAt: Date;
            actualEndAt: Date | null;
            notes: string | null;
            rejectionNote: string | null;
            designationStatus: string;
            roomId: string;
            scriptId: string;
            hostId: string;
            assistantId: string | null;
            npcId: string | null;
            joinToken: string | null;
            joinEnabled: boolean;
        };
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        sessionId: string;
        userId: string | null;
        feeType: string;
        confirmedById: string | null;
        confirmedAt: Date | null;
    }>;
    actionFee(user: UserSession, id: string, dto: ActionDto): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
        createdBy: {
            id: string;
            name: string;
        };
        user: {
            id: string;
            name: string;
            role: string;
        } | null;
        session: {
            script: {
                id: string;
                storeId: string;
                createdAt: Date;
                updatedAt: Date;
                name: string;
                active: boolean;
                version: number;
                category: string;
                theme: string;
                playerCount: number;
                minPlayerCount: number;
                priceCents: number;
                memberPriceCents: number;
                durationMinutes: number;
                sessionFactor: number;
                needsAssistant: boolean;
                needsNpc: boolean;
                assistantCount: number;
                npcCount: number;
                assistantFeeTiers: string;
                npcFeeTiers: string;
                eligibleHostIds: string;
                eligibleAssistantIds: string;
                eligibleNpcIds: string;
                requiredPreparationLabels: string;
                requiredMaterialLabels: string;
                preparationExamples: string;
                materialExamples: string;
            };
        } & {
            id: string;
            storeId: string;
            createdAt: Date;
            updatedAt: Date;
            code: string;
            state: string;
            startAt: Date;
            expectedEndAt: Date;
            actualEndAt: Date | null;
            notes: string | null;
            rejectionNote: string | null;
            designationStatus: string;
            roomId: string;
            scriptId: string;
            hostId: string;
            assistantId: string | null;
            npcId: string | null;
            joinToken: string | null;
            joinEnabled: boolean;
        };
        confirmedBy: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        note: string | null;
        storeId: string;
        createdById: string;
        createdAt: Date;
        updatedAt: Date;
        amountCents: number;
        status: string;
        sessionId: string;
        userId: string | null;
        feeType: string;
        confirmedById: string | null;
        confirmedAt: Date | null;
    }>;
    feeSummary(user: UserSession, query: RangeQueryDto): Promise<{
        totalCents: number;
        pendingCents: number;
        byType: {
            type: string;
            amountCents: number;
        }[];
        byUser: {
            userId: string;
            name: string;
            amountCents: number;
        }[];
    }>;
}
export {};
