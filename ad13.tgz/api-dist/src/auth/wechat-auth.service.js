"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var WechatAuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatAuthService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
let WechatAuthService = WechatAuthService_1 = class WechatAuthService {
    config;
    logger = new common_1.Logger(WechatAuthService_1.name);
    accessToken;
    accessTokenRequest;
    constructor(config) {
        this.config = config;
    }
    async getSession(loginCode) {
        const { appId, appSecret } = this.credentials();
        const session = await this.getJson(`https://api.weixin.qq.com/sns/jscode2session?appid=${encodeURIComponent(appId)}&secret=${encodeURIComponent(appSecret)}&js_code=${encodeURIComponent(loginCode)}&grant_type=authorization_code`);
        if (!session.openid)
            this.throwWechatError("code2Session", session);
        return { openId: session.openid, unionId: session.unionid };
    }
    async authenticate(loginCode, phoneCode) {
        const { appId, appSecret } = this.credentials();
        const session = await this.getSession(loginCode);
        const accessToken = await this.getAccessToken(appId, appSecret);
        const phone = await this.getJson(`https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=${encodeURIComponent(accessToken)}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code: phoneCode }) });
        if (!phone.phone_info?.purePhoneNumber)
            this.throwWechatError("getPhoneNumber", phone);
        if (phone.phone_info.watermark?.appid && phone.phone_info.watermark.appid !== appId) {
            throw new common_1.UnauthorizedException("手机号授权信息与当前小程序不匹配");
        }
        return {
            openId: session.openId,
            unionId: session.unionId,
            phone: phone.phone_info.purePhoneNumber,
        };
    }
    async getWxaCode(scene, page) {
        const { appId, appSecret } = this.credentials();
        const accessToken = await this.getAccessToken(appId, appSecret);
        const envVersion = this.config.get("WECHAT_WXA_ENV", "release").trim() || "release";
        let response;
        try {
            response = await fetch(`https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=${encodeURIComponent(accessToken)}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ scene, page, width: 430, check_path: false, env_version: envVersion }) });
        }
        catch (error) {
            this.logger.error(`Wechat getwxacodeunlimit failed: ${error instanceof Error ? error.message : "network error"}`);
            throw new common_1.ServiceUnavailableException("微信服务暂时不可用，请稍后重试");
        }
        const buffer = Buffer.from(await response.arrayBuffer());
        if (buffer.subarray(0, 80).toString("utf8").trimStart().startsWith("{")) {
            let err = {};
            try {
                err = JSON.parse(buffer.toString("utf8"));
            }
            catch { }
            this.logger.error(`Wechat getwxacodeunlimit error: ${err.errcode ?? "unknown"} ${err.errmsg ?? ""}`);
            throw new common_1.ServiceUnavailableException("小程序码生成失败，请稍后重试");
        }
        return buffer;
    }
    credentials() {
        const appId = this.config.get("WECHAT_APP_ID", "").trim();
        const appSecret = this.config.get("WECHAT_APP_SECRET", "").trim();
        if (!appId || !appSecret)
            throw new common_1.ServiceUnavailableException("微信登录尚未配置");
        return { appId, appSecret };
    }
    async getAccessToken(appId, appSecret) {
        if (this.accessToken && this.accessToken.expiresAt > Date.now())
            return this.accessToken.value;
        if (this.accessTokenRequest)
            return this.accessTokenRequest;
        this.accessTokenRequest = (async () => {
            const result = await this.getJson(`https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${encodeURIComponent(appId)}&secret=${encodeURIComponent(appSecret)}`);
            if (!result.access_token)
                this.throwWechatError("getAccessToken", result);
            const expiresIn = Math.max(300, result.expires_in ?? 7200);
            this.accessToken = { value: result.access_token, expiresAt: Date.now() + (expiresIn - 300) * 1000 };
            return result.access_token;
        })();
        try {
            return await this.accessTokenRequest;
        }
        finally {
            this.accessTokenRequest = undefined;
        }
    }
    async getJson(url, init) {
        let response;
        try {
            response = await fetch(url, init);
        }
        catch (error) {
            this.logger.error(`Wechat request failed: ${error instanceof Error ? error.message : "network error"}`);
            throw new common_1.ServiceUnavailableException("微信服务暂时不可用，请稍后重试");
        }
        if (!response.ok) {
            this.logger.error(`Wechat HTTP error: ${response.status}`);
            throw new common_1.ServiceUnavailableException("微信服务暂时不可用，请稍后重试");
        }
        return response.json();
    }
    throwWechatError(operation, response) {
        this.logger.error(`Wechat ${operation} error: ${response.errcode ?? "unknown"} ${response.errmsg ?? ""}`);
        if ([40029, 40163].includes(response.errcode ?? 0)) {
            throw new common_1.UnauthorizedException("微信授权已失效，请重新点击登录");
        }
        if ([40013, 40125].includes(response.errcode ?? 0)) {
            throw new common_1.ServiceUnavailableException("微信登录配置异常，请联系管理员");
        }
        throw new common_1.ServiceUnavailableException("微信登录失败，请稍后重试");
    }
};
exports.WechatAuthService = WechatAuthService;
exports.WechatAuthService = WechatAuthService = WechatAuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], WechatAuthService);
//# sourceMappingURL=wechat-auth.service.js.map