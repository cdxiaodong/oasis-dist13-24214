import { ConfigService } from "@nestjs/config";
export declare class WechatAuthService {
    private readonly config;
    private readonly logger;
    private accessToken?;
    private accessTokenRequest?;
    constructor(config: ConfigService);
    getSession(loginCode: string): Promise<{
        openId: string;
        unionId: string | undefined;
    }>;
    authenticate(loginCode: string, phoneCode: string): Promise<{
        openId: string;
        unionId: string | undefined;
        phone: string;
    }>;
    getWxaCode(scene: string, page: string): Promise<Buffer>;
    private credentials;
    private getAccessToken;
    private getJson;
    private throwWechatError;
}
