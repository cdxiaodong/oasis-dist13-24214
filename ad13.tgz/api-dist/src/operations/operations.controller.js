"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const current_user_decorator_1 = require("../auth/current-user.decorator");
const operations_service_1 = require("./operations.service");
class AttendanceDto {
    type;
    latitude;
    longitude;
    accuracyMeters;
    capturedAt;
    photoUrl;
    exceptionReason;
    note;
}
__decorate([
    (0, class_validator_1.IsIn)(["CLOCK_IN", "CLOCK_OUT"]),
    __metadata("design:type", String)
], AttendanceDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-90),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], AttendanceDto.prototype, "latitude", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-180),
    (0, class_validator_1.Max)(180),
    __metadata("design:type", Number)
], AttendanceDto.prototype, "longitude", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], AttendanceDto.prototype, "accuracyMeters", void 0);
__decorate([
    (0, class_validator_1.IsISO8601)(),
    __metadata("design:type", String)
], AttendanceDto.prototype, "capturedAt", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AttendanceDto.prototype, "photoUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AttendanceDto.prototype, "exceptionReason", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AttendanceDto.prototype, "note", void 0);
class AttendanceLocationDto {
    latitude;
    longitude;
    accuracyMeters;
}
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-90),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], AttendanceLocationDto.prototype, "latitude", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-180),
    (0, class_validator_1.Max)(180),
    __metadata("design:type", Number)
], AttendanceLocationDto.prototype, "longitude", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], AttendanceLocationDto.prototype, "accuracyMeters", void 0);
class AttendanceSettingsDto {
    storeId;
    latitude;
    longitude;
    accuracyMeters;
    radiusMeters;
    maxAccuracyMeters;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AttendanceSettingsDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-90),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], AttendanceSettingsDto.prototype, "latitude", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-180),
    (0, class_validator_1.Max)(180),
    __metadata("design:type", Number)
], AttendanceSettingsDto.prototype, "longitude", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], AttendanceSettingsDto.prototype, "accuracyMeters", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(50),
    (0, class_validator_1.Max)(1000),
    __metadata("design:type", Number)
], AttendanceSettingsDto.prototype, "radiusMeters", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(20),
    (0, class_validator_1.Max)(500),
    __metadata("design:type", Number)
], AttendanceSettingsDto.prototype, "maxAccuracyMeters", void 0);
class AttendanceActionDto {
    action;
    comment;
}
__decorate([
    (0, class_validator_1.IsIn)(["APPROVE", "REJECT"]),
    __metadata("design:type", String)
], AttendanceActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AttendanceActionDto.prototype, "comment", void 0);
class ReimbursementDto {
    category;
    amountCents;
    description;
    receiptUrl;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementDto.prototype, "category", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ReimbursementDto.prototype, "amountCents", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementDto.prototype, "receiptUrl", void 0);
class ReimbursementActionDto {
    action;
    comment;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementActionDto.prototype, "action", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementActionDto.prototype, "comment", void 0);
class ReimbursementRuleDto {
    storeId;
    category;
    maxAmountCents;
    enabled;
    note;
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementRuleDto.prototype, "storeId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementRuleDto.prototype, "category", void 0);
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ReimbursementRuleDto.prototype, "maxAmountCents", void 0);
__decorate([
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], ReimbursementRuleDto.prototype, "enabled", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReimbursementRuleDto.prototype, "note", void 0);
let OperationsController = class OperationsController {
    operations;
    constructor(operations) {
        this.operations = operations;
    }
    attendance(user, storeId) {
        return this.operations.attendance(user, storeId);
    }
    createAttendance(user, dto) {
        return this.operations.createAttendance(user, dto);
    }
    checkAttendanceLocation(user, dto) {
        return this.operations.checkAttendanceLocation(user, dto);
    }
    attendanceSettings(user, storeId) {
        return this.operations.attendanceSettings(user, storeId);
    }
    saveAttendanceSettings(user, dto) {
        return this.operations.saveAttendanceSettings(user, dto);
    }
    actionAttendance(user, id, dto) {
        return this.operations.actionAttendance(user, id, dto.action, dto.comment);
    }
    reimbursements(user, storeId, category, from, to, userId, search) {
        return this.operations.reimbursements(user, { storeId, category, from, to, userId, search });
    }
    createReimbursement(user, dto) {
        return this.operations.createReimbursement(user, dto);
    }
    action(user, id, dto) {
        return this.operations.actionReimbursement(user, id, dto.action, dto.comment);
    }
    rules(user, storeId) { return this.operations.reimbursementRules(user, storeId); }
    saveRule(user, dto) { return this.operations.saveReimbursementRule(user, dto); }
};
exports.OperationsController = OperationsController;
__decorate([
    (0, common_1.Get)("attendance"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "attendance", null);
__decorate([
    (0, common_1.Post)("attendance"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, AttendanceDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "createAttendance", null);
__decorate([
    (0, common_1.Post)("attendance/check-location"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, AttendanceLocationDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "checkAttendanceLocation", null);
__decorate([
    (0, common_1.Get)("attendance-settings"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "attendanceSettings", null);
__decorate([
    (0, common_1.Post)("attendance-settings"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, AttendanceSettingsDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "saveAttendanceSettings", null);
__decorate([
    (0, common_1.Post)("attendance/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, AttendanceActionDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "actionAttendance", null);
__decorate([
    (0, common_1.Get)("reimbursements"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __param(2, (0, common_1.Query)("category")),
    __param(3, (0, common_1.Query)("from")),
    __param(4, (0, common_1.Query)("to")),
    __param(5, (0, common_1.Query)("userId")),
    __param(6, (0, common_1.Query)("search")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "reimbursements", null);
__decorate([
    (0, common_1.Post)("reimbursements"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, ReimbursementDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "createReimbursement", null);
__decorate([
    (0, common_1.Post)("reimbursements/:id/action"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)("id")),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, ReimbursementActionDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "action", null);
__decorate([
    (0, common_1.Get)("reimbursement-rules"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)("storeId")),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "rules", null);
__decorate([
    (0, common_1.Post)("reimbursement-rules"),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, ReimbursementRuleDto]),
    __metadata("design:returntype", void 0)
], OperationsController.prototype, "saveRule", null);
exports.OperationsController = OperationsController = __decorate([
    (0, swagger_1.ApiTags)("门店运营"),
    (0, common_1.Controller)("operations"),
    __metadata("design:paramtypes", [operations_service_1.OperationsService])
], OperationsController);
//# sourceMappingURL=operations.controller.js.map