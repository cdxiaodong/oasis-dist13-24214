import type { Prisma } from "@prisma/client";
import { type UserSession } from "../common/user-session";
import { PrismaService } from "../prisma/prisma.service";
export declare class CatalogService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private scopedStore;
    private requireManager;
    private requireHeadquarters;
    private requireStore;
    stores(user: UserSession): Prisma.PrismaPromise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        code: string;
        city: string;
        address: string | null;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }[]>;
    rooms(user: UserSession, storeId?: string): Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        capacity: number;
    })[]>;
    users(user: UserSession, storeId?: string): never[] | Prisma.PrismaPromise<{
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        name: string;
        role: string;
        active: boolean;
    }[]> | Promise<{
        wechatBound: boolean;
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        username: string;
        name: string;
        role: string;
        phone: string | null;
        lastWechatLoginAt: Date | null;
        active: boolean;
    }[]>;
    scripts(user: UserSession, storeId?: string): Prisma.PrismaPromise<({
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        version: number;
        category: string;
        theme: string;
        playerCount: number;
        minPlayerCount: number;
        priceCents: number;
        memberPriceCents: number;
        durationMinutes: number;
        sessionFactor: number;
        needsAssistant: boolean;
        needsNpc: boolean;
        assistantCount: number;
        npcCount: number;
        assistantFeeTiers: string;
        npcFeeTiers: string;
        eligibleHostIds: string;
        eligibleAssistantIds: string;
        eligibleNpcIds: string;
        requiredPreparationLabels: string;
        requiredMaterialLabels: string;
        preparationExamples: string;
        materialExamples: string;
    })[]>;
    createStore(user: UserSession, data: {
        code: string;
        name: string;
        city: string;
        address?: string;
    }): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        code: string;
        city: string;
        address: string | null;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }>;
    updateStore(user: UserSession, id: string, data: {
        code?: string;
        name?: string;
        city?: string;
        address?: string;
        active?: boolean;
    }): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        code: string;
        city: string;
        address: string | null;
        latitude: number | null;
        longitude: number | null;
        attendanceRadiusMeters: number;
        attendanceMaxAccuracyMeters: number;
        attendanceLocationUpdatedAt: Date | null;
    }>;
    createRoom(user: UserSession, data: {
        storeId: string;
        name: string;
        capacity: number;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        capacity: number;
    }>;
    updateRoom(user: UserSession, id: string, data: {
        name?: string;
        capacity?: number;
        active?: boolean;
    }): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        capacity: number;
    }>;
    createUser(user: UserSession, data: {
        username: string;
        password: string;
        name: string;
        role: string;
        phone?: string | null;
        storeId?: string;
    }): Promise<{
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        username: string;
        name: string;
        role: string;
        phone: string | null;
        lastWechatLoginAt: Date | null;
        active: boolean;
    }>;
    updateUser(user: UserSession, id: string, data: {
        name?: string;
        phone?: string | null;
        role?: string;
        active?: boolean;
    }): Promise<{
        id: string;
        storeId: string | null;
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        } | null;
        username: string;
        name: string;
        role: string;
        phone: string | null;
        lastWechatLoginAt: Date | null;
        active: boolean;
    }>;
    unbindWechat(user: UserSession, id: string): Promise<{
        success: boolean;
    }>;
    private normalizePhone;
    private ensurePhoneAvailable;
    createScript(user: UserSession, data: Prisma.ScriptUncheckedCreateInput): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        version: number;
        category: string;
        theme: string;
        playerCount: number;
        minPlayerCount: number;
        priceCents: number;
        memberPriceCents: number;
        durationMinutes: number;
        sessionFactor: number;
        needsAssistant: boolean;
        needsNpc: boolean;
        assistantCount: number;
        npcCount: number;
        assistantFeeTiers: string;
        npcFeeTiers: string;
        eligibleHostIds: string;
        eligibleAssistantIds: string;
        eligibleNpcIds: string;
        requiredPreparationLabels: string;
        requiredMaterialLabels: string;
        preparationExamples: string;
        materialExamples: string;
    }>;
    updateScript(user: UserSession, id: string, data: Prisma.ScriptUncheckedUpdateInput): Promise<{
        store: {
            id: string;
            createdAt: Date;
            updatedAt: Date;
            name: string;
            active: boolean;
            code: string;
            city: string;
            address: string | null;
            latitude: number | null;
            longitude: number | null;
            attendanceRadiusMeters: number;
            attendanceMaxAccuracyMeters: number;
            attendanceLocationUpdatedAt: Date | null;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        version: number;
        category: string;
        theme: string;
        playerCount: number;
        minPlayerCount: number;
        priceCents: number;
        memberPriceCents: number;
        durationMinutes: number;
        sessionFactor: number;
        needsAssistant: boolean;
        needsNpc: boolean;
        assistantCount: number;
        npcCount: number;
        assistantFeeTiers: string;
        npcFeeTiers: string;
        eligibleHostIds: string;
        eligibleAssistantIds: string;
        eligibleNpcIds: string;
        requiredPreparationLabels: string;
        requiredMaterialLabels: string;
        preparationExamples: string;
        materialExamples: string;
    }>;
    vipRules(user: UserSession, storeId?: string): Prisma.PrismaPromise<({
        store: {
            id: string;
            name: string;
            city: string;
        };
    } & {
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        cardType: string;
        rechargeCents: number;
        receiveCents: number;
        boxDiscount: number | null;
        cityDiscount: number | null;
        unifiedDiscount: number | null;
        maxUsers: number | null;
        cardTitle: string;
    })[]>;
    createVipRule(user: UserSession, data: Prisma.VipCardRuleUncheckedCreateInput): Promise<{
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        cardType: string;
        rechargeCents: number;
        receiveCents: number;
        boxDiscount: number | null;
        cityDiscount: number | null;
        unifiedDiscount: number | null;
        maxUsers: number | null;
        cardTitle: string;
    }>;
    updateVipRule(user: UserSession, id: string, data: Prisma.VipCardRuleUncheckedUpdateInput): Promise<{
        id: string;
        storeId: string;
        createdAt: Date;
        updatedAt: Date;
        active: boolean;
        cardType: string;
        rechargeCents: number;
        receiveCents: number;
        boxDiscount: number | null;
        cityDiscount: number | null;
        unifiedDiscount: number | null;
        maxUsers: number | null;
        cardTitle: string;
    }>;
    activityTypes(user: UserSession, storeId?: string): Prisma.PrismaPromise<({
        store: {
            id: string;
            name: string;
        } | null;
    } & {
        id: string;
        storeId: string | null;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        defaultDiscountCents: number;
        sortOrder: number;
    })[]>;
    createActivityType(user: UserSession, data: {
        name: string;
        storeId?: string;
        defaultDiscountCents?: number;
        sortOrder?: number;
    }): Promise<{
        id: string;
        storeId: string | null;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        defaultDiscountCents: number;
        sortOrder: number;
    }>;
    updateActivityType(user: UserSession, id: string, data: {
        name?: string;
        defaultDiscountCents?: number;
        active?: boolean;
        sortOrder?: number;
    }): Promise<{
        id: string;
        storeId: string | null;
        createdAt: Date;
        updatedAt: Date;
        name: string;
        active: boolean;
        defaultDiscountCents: number;
        sortOrder: number;
    }>;
    deleteActivityType(user: UserSession, id: string): Promise<{
        success: boolean;
    }>;
    private audit;
}
