export declare class CatalogModule {
}
