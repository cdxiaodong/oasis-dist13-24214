"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CatalogService = void 0;
const common_1 = require("@nestjs/common");
const bcryptjs_1 = require("bcryptjs");
const business_rules_1 = require("../common/business-rules");
const user_session_1 = require("../common/user-session");
const prisma_service_1 = require("../prisma/prisma.service");
const STORE_MANAGERS = new Set(["HEADQUARTERS", "MANAGER"]);
const STORE_ROLES = new Set(["MANAGER", "DM", "ASSISTANT", "NPC", "STAFF", "CUSTOMER_SERVICE"]);
const ACTIVITY_TYPE_NAME_SET = new Set(business_rules_1.ACTIVITY_TYPE_NAMES);
let CatalogService = class CatalogService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    scopedStore(user, requested) {
        if (user_session_1.GLOBAL_ROLES.has(user.role))
            return requested;
        if (!user.storeId)
            throw new common_1.ForbiddenException("账号未绑定门店");
        if (requested && requested !== user.storeId)
            throw new common_1.ForbiddenException("无权访问其他门店");
        return user.storeId;
    }
    requireManager(user) {
        if (!STORE_MANAGERS.has(user.role))
            throw new common_1.ForbiddenException("只有店长或总部可以维护基础资料");
    }
    requireHeadquarters(user) {
        if (user.role !== "HEADQUARTERS")
            throw new common_1.ForbiddenException("只有总部可以维护门店资料");
    }
    async requireStore(user, storeId) {
        this.requireManager(user);
        const scoped = this.scopedStore(user, storeId);
        if (!scoped)
            throw new common_1.BadRequestException("请选择门店");
        const store = await this.prisma.store.findUnique({ where: { id: scoped } });
        if (!store)
            throw new common_1.NotFoundException("门店不存在");
        return scoped;
    }
    stores(user) {
        const storeId = this.scopedStore(user);
        return this.prisma.store.findMany({ where: storeId ? { id: storeId } : {}, orderBy: { name: "asc" } });
    }
    rooms(user, storeId) {
        const scoped = this.scopedStore(user, storeId);
        return this.prisma.room.findMany({ where: scoped ? { storeId: scoped } : {}, include: { store: true }, orderBy: [{ active: "desc" }, { name: "asc" }] });
    }
    users(user, storeId) {
        const scoped = this.scopedStore(user, storeId);
        if (!["HEADQUARTERS", "FINANCE", "MANAGER", "DM", "ASSISTANT", "NPC", "STAFF"].includes(user.role))
            return [];
        if (!["HEADQUARTERS", "FINANCE", "MANAGER"].includes(user.role)) {
            return this.prisma.user.findMany({
                where: { ...(scoped ? { storeId: scoped } : {}), active: true },
                select: { id: true, name: true, role: true, active: true, storeId: true, store: true },
                orderBy: { name: "asc" },
            });
        }
        return this.prisma.user.findMany({
            where: scoped ? { storeId: scoped } : {},
            select: { id: true, name: true, username: true, phone: true, role: true, active: true, storeId: true, store: true, wechatOpenId: true, lastWechatLoginAt: true },
            orderBy: [{ active: "desc" }, { name: "asc" }],
        }).then((items) => items.map(({ wechatOpenId, ...item }) => ({ ...item, wechatBound: Boolean(wechatOpenId) })));
    }
    scripts(user, storeId) {
        const scoped = this.scopedStore(user, storeId);
        return this.prisma.script.findMany({ where: scoped ? { storeId: scoped } : {}, include: { store: true }, orderBy: [{ active: "desc" }, { name: "asc" }, { version: "desc" }] });
    }
    async createStore(user, data) {
        this.requireHeadquarters(user);
        const store = await this.prisma.$transaction(async (tx) => {
            const created = await tx.store.create({ data });
            await tx.activityType.createMany({ data: business_rules_1.ACTIVITY_TYPE_DEFINITIONS.map((activity) => ({ ...activity, storeId: created.id })) });
            return created;
        });
        await this.audit(user, "CREATE_STORE", "Store", store.id, data);
        return store;
    }
    async updateStore(user, id, data) {
        this.requireHeadquarters(user);
        const existing = await this.prisma.store.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("门店不存在");
        const store = await this.prisma.store.update({ where: { id }, data });
        await this.audit(user, "UPDATE_STORE", "Store", id, data);
        return store;
    }
    async createRoom(user, data) {
        const storeId = await this.requireStore(user, data.storeId);
        const room = await this.prisma.room.create({ data: { ...data, storeId }, include: { store: true } });
        await this.audit(user, "CREATE_ROOM", "Room", room.id, data);
        return room;
    }
    async updateRoom(user, id, data) {
        const existing = await this.prisma.room.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("房间不存在");
        await this.requireStore(user, existing.storeId);
        const room = await this.prisma.room.update({ where: { id }, data, include: { store: true } });
        await this.audit(user, "UPDATE_ROOM", "Room", id, data);
        return room;
    }
    async createUser(user, data) {
        this.requireManager(user);
        if (user.role !== "HEADQUARTERS" && !STORE_ROLES.has(data.role))
            throw new common_1.ForbiddenException("店长不能创建总部或财务账号");
        const storeId = user_session_1.GLOBAL_ROLES.has(data.role) ? null : await this.requireStore(user, data.storeId || "");
        const phone = this.normalizePhone(data.phone);
        await this.ensurePhoneAvailable(phone);
        const created = await this.prisma.user.create({
            data: { username: data.username, passwordHash: await (0, bcryptjs_1.hash)(data.password, 10), name: data.name, role: data.role, phone, storeId },
            select: { id: true, name: true, username: true, phone: true, role: true, active: true, storeId: true, store: true, lastWechatLoginAt: true },
        });
        await this.audit(user, "CREATE_USER", "User", created.id, { username: data.username, name: data.name, role: data.role, storeId });
        return created;
    }
    async updateUser(user, id, data) {
        this.requireManager(user);
        const existing = await this.prisma.user.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("员工不存在");
        if (existing.id === user.id && data.active === false)
            throw new common_1.BadRequestException("不能停用当前登录账号");
        if (existing.storeId && !(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权维护其他门店员工");
        const nextRole = data.role ?? existing.role;
        if (user_session_1.GLOBAL_ROLES.has(nextRole) !== user_session_1.GLOBAL_ROLES.has(existing.role))
            throw new common_1.BadRequestException("总部账号与门店账号不能直接互转，请新建账号或使用员工调店流程");
        if (user.role !== "HEADQUARTERS" && !STORE_ROLES.has(nextRole))
            throw new common_1.ForbiddenException("店长不能设置总部或财务角色");
        const hasPhone = Object.prototype.hasOwnProperty.call(data, "phone");
        const phone = hasPhone ? this.normalizePhone(data.phone) : undefined;
        if (hasPhone)
            await this.ensurePhoneAvailable(phone ?? null, id);
        const updated = await this.prisma.user.update({
            where: { id }, data: { ...data, ...(hasPhone ? { phone } : {}) },
            select: { id: true, name: true, username: true, phone: true, role: true, active: true, storeId: true, store: true, lastWechatLoginAt: true },
        });
        await this.audit(user, "UPDATE_USER", "User", id, data);
        return updated;
    }
    async unbindWechat(user, id) {
        this.requireManager(user);
        const existing = await this.prisma.user.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("员工不存在");
        if (existing.storeId && !(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权维护其他门店员工");
        await this.prisma.user.update({
            where: { id },
            data: { wechatOpenId: null, wechatUnionId: null, lastWechatLoginAt: null },
        });
        await this.audit(user, "UNBIND_WECHAT", "User", id);
        return { success: true };
    }
    normalizePhone(value) {
        if (!value?.trim())
            return null;
        const phone = value.trim();
        if (!/^1\d{10}$/.test(phone))
            throw new common_1.BadRequestException("手机号格式不正确");
        return phone;
    }
    async ensurePhoneAvailable(phone, excludeId) {
        if (!phone)
            return;
        const existing = await this.prisma.user.findUnique({ where: { phone } });
        if (existing && existing.id !== excludeId)
            throw new common_1.BadRequestException("该手机号已关联其他员工账号");
    }
    async createScript(user, data) {
        const storeId = await this.requireStore(user, data.storeId);
        const maximum = Number(data.playerCount);
        const minimum = Number(data.minPlayerCount || maximum);
        if (minimum > maximum)
            throw new common_1.BadRequestException("最少玩家人数不能大于最多玩家人数");
        const script = await this.prisma.script.create({ data: { ...data, minPlayerCount: minimum, storeId, requiredMaterialLabels: JSON.stringify(business_rules_1.REQUIRED_END_MATERIAL_LABELS) }, include: { store: true } });
        await this.audit(user, "CREATE_SCRIPT_VERSION", "Script", script.id, { name: script.name, version: script.version, storeId });
        return script;
    }
    async updateScript(user, id, data) {
        const existing = await this.prisma.script.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("剧本版本不存在");
        await this.requireStore(user, existing.storeId);
        const maximum = Number(data.playerCount ?? existing.playerCount);
        const minimum = Number(data.minPlayerCount ?? (existing.minPlayerCount || maximum));
        if (minimum > maximum)
            throw new common_1.BadRequestException("最少玩家人数不能大于最多玩家人数");
        const coreFields = ["name", "category", "theme", "playerCount", "minPlayerCount", "priceCents", "durationMinutes", "sessionFactor", "needsAssistant", "needsNpc", "assistantCount", "npcCount", "assistantFeeTiers", "npcFeeTiers", "requiredPreparationLabels", "requiredMaterialLabels", "preparationExamples", "materialExamples"];
        if (coreFields.some((field) => data[field] !== undefined)) {
            const sessionCount = await this.prisma.gameSession.count({ where: { scriptId: id } });
            if (sessionCount)
                throw new common_1.BadRequestException("该剧本版本已有历史车次，只能停用；规则或价格变化请新建版本");
        }
        const script = await this.prisma.script.update({ where: { id }, data, include: { store: true } });
        await this.audit(user, "UPDATE_SCRIPT_VERSION", "Script", id, data);
        return script;
    }
    vipRules(user, storeId) {
        const scoped = this.scopedStore(user, storeId);
        return this.prisma.vipCardRule.findMany({
            where: { ...(scoped ? { storeId: scoped } : {}), active: true },
            include: { store: { select: { id: true, name: true, city: true } } },
            orderBy: [{ store: { code: "asc" } }, { cardType: "asc" }],
        });
    }
    async createVipRule(user, data) {
        const storeId = await this.requireStore(user, data.storeId);
        return this.prisma.vipCardRule.create({ data: { ...data, storeId } });
    }
    async updateVipRule(user, id, data) {
        this.requireManager(user);
        const existing = await this.prisma.vipCardRule.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("VIP卡规则不存在");
        if (!(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权维护其他门店VIP规则");
        return this.prisma.vipCardRule.update({ where: { id }, data });
    }
    activityTypes(user, storeId) {
        const scoped = this.scopedStore(user, storeId);
        return this.prisma.activityType.findMany({
            where: scoped ? { OR: [{ storeId: scoped }, { storeId: null }] } : {},
            include: { store: { select: { id: true, name: true } } },
            orderBy: [{ active: "desc" }, { sortOrder: "asc" }, { createdAt: "asc" }],
        });
    }
    async createActivityType(user, data) {
        this.requireManager(user);
        if (!ACTIVITY_TYPE_NAME_SET.has(data.name))
            throw new common_1.BadRequestException("活动类型不在正式清单中");
        const storeId = data.storeId ? await this.requireStore(user, data.storeId) : null;
        return this.prisma.activityType.create({ data: { ...data, storeId } });
    }
    async updateActivityType(user, id, data) {
        this.requireManager(user);
        if (data.name && !ACTIVITY_TYPE_NAME_SET.has(data.name))
            throw new common_1.BadRequestException("活动类型不在正式清单中");
        const existing = await this.prisma.activityType.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("活动类型不存在");
        if (existing.storeId && !(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权维护其他门店活动");
        return this.prisma.activityType.update({ where: { id }, data });
    }
    async deleteActivityType(user, id) {
        this.requireManager(user);
        const existing = await this.prisma.activityType.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException("活动类型不存在");
        if (existing.storeId && !(0, user_session_1.canAccessStore)(user, existing.storeId))
            throw new common_1.ForbiddenException("无权维护其他门店活动");
        if (ACTIVITY_TYPE_NAME_SET.has(existing.name))
            throw new common_1.BadRequestException("正式活动类型不能删除，可以停用或调整默认金额");
        await this.prisma.activityType.delete({ where: { id } });
        return { success: true };
    }
    audit(user, action, entityType, entityId, payload) {
        return this.prisma.auditLog.create({ data: { userId: user.id, action, entityType, entityId, payload: payload ? JSON.stringify(payload) : undefined } });
    }
};
exports.CatalogService = CatalogService;
exports.CatalogService = CatalogService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CatalogService);
//# sourceMappingURL=catalog.service.js.map